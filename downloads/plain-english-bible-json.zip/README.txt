The Open Plain English Translation as JSON, one file per book: for each chapter its status and
verses, each [number, English with [^note] markers, Hebrew or Greek, {p: paragraph end, e: English
verse number}], and its notes. The format is described in scripts/reader.py.

The Open Plain English Translation (draft), CC BY 4.0, https://bibledata.org. Source texts: the Unicode/XML Leningrad Codex (UXLC 2.6) and the SBL Greek New Testament (CC BY 4.0).
