# Jeremiah

> **Text:** Open Plain English Translation. License: CC BY 4.0. New Testament translated from the SBL Greek New Testament (CC BY 4.0, © 2010 Society of Biblical Literature and Logos Bible Software); Old Testament from the Unicode/XML Leningrad Codex (UXLC 2.6, Tanach.us).  
> Chapters show their review status: *draft*, *checked*, *reviewed* or *approved*. See TRANSLATION.md.

## Chapter 1

*Status: draft*

**1** The words of Jeremiah son of Hilkiah, one of the priests in Anathoth[^1-1] in the land of Benjamin.

**2** The word of the LORD[^1-2] came to him in the days of Josiah son of Amon king of Judah, in the thirteenth year of his reign.[^1-3]

**3** It came also in the days of Jehoiakim son of Josiah king of Judah, until the end of the eleventh year of Zedekiah son of Josiah king of Judah, until Jerusalem went into exile in the fifth month.[^1-4]

**4** The word of the LORD came to me:

**5** "Before I formed you in the womb I knew you, and before you came out of the womb I set you apart.[^1-5] I appointed you a prophet to the nations."

**6** I said, "Ah, Lord GOD![^1-6] I don't know how to speak, for I am only a boy."[^1-7]

**7** But the LORD said to me, "Do not say, 'I am only a boy.' You will go to everyone I send you to, and you will say whatever I command you.

**8** Do not be afraid of them, for I am with you to rescue you, declares the LORD."[^1-8]

**9** Then the LORD stretched out his hand and touched my mouth, and the LORD said to me, "Look, I have put my words in your mouth.

**10** See, today I appoint you over nations and over kingdoms, to uproot and to tear down, to destroy and to overthrow, to build and to plant."[^1-9]

**11** The word of the LORD came to me: "What do you see, Jeremiah?" I said, "I see a branch of an almond tree."[^1-10]

**12** The LORD said to me, "You have seen well, for I am watching over my word to carry it out."

**13** The word of the LORD came to me a second time: "What do you see?" I said, "I see a boiling pot, and it is tipped away from the north."[^1-11]

**14** The LORD said to me, "From the north disaster will be let loose on all who live in the land.

**15** For I am about to summon all the clans of the kingdoms of the north, declares the LORD. They will come, and each of them will set up his throne at the entrance of the gates of Jerusalem, against all its walls around it, and against all the cities of Judah.

**16** I will pronounce my judgments on my people[^1-12] for all their evil, because they have abandoned me. They have burned incense[^1-13] to other gods and bowed down to the works of their own hands.

**17** But you, get ready for action.[^1-14] Stand up and tell them everything I command you. Do not be shattered with fear before them, or I will shatter you before them.[^1-15]

**18** And I, look, today I have made you a fortified city, an iron pillar and bronze walls against the whole land: against the kings of Judah, its officials, its priests and the people of the land.[^1-16]

**19** They will fight against you, but they will not overcome you, for I am with you, declares the LORD, to rescue you."

[^1-1]: A town of priests about 3 miles (5 km) northeast of Jerusalem (Joshua 21:18; 1 Kings 2:26).
[^1-2]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^1-3]: In 627 BC.
[^1-4]: In the summer of 587 or 586 BC (2 Kings 25:8–11; Jeremiah 52:12–15).
[^1-5]: Or "consecrated you". Literally "made you holy".
[^1-6]: Hebrew *Adonai YHWH*, "my Lord YHWH". After "Lord", God's personal name is written GOD in capitals, as in most English Bibles.
[^1-7]: Hebrew *na'ar*, a word used of a child, a youth or a young man.
[^1-8]: Hebrew *ne'um YHWH*, "the declaration of the LORD", a formula that marks a prophet's words as the LORD's own solemn statement. It is frequent in Jeremiah.
[^1-9]: These verbs recur through the book as a summary of Jeremiah's message (18:7–9; 24:6; 31:28; 42:10; 45:4).
[^1-10]: A wordplay. Hebrew *shaqed*, "almond tree", sounds like *shoqed*, "watching", in verse 12. The almond is the first tree to blossom in late winter, as though it were awake while the others sleep.
[^1-11]: Literally "and its face is from the face of the north". The pot's mouth faces south, so its contents will pour out from the north over Judah (verse 14).
[^1-12]: Literally "on them".
[^1-13]: Or "burned offerings". The Hebrew verb *qatar* means to make something go up in smoke.
[^1-14]: Literally "gird up your loins", that is, tuck the long robe into the belt, ready for action.
[^1-15]: The Hebrew uses the same verb, *chatat*, "to be shattered, dismayed", in both lines.
[^1-16]: Hebrew *am ha-arets*, the landowning citizens of Judah.

## Chapter 2

*Status: draft*

**1** The word of the LORD[^2-1] came to me:

**2** Go and proclaim in the hearing of Jerusalem:[^2-2] This is what the LORD says: I remember the faithful love[^2-3] of your youth, your love as a bride, how you followed me in the wilderness, in a land not sown.

**3** Israel was holy to the LORD, the firstfruits of his harvest.[^2-4] All who ate of it were held guilty; disaster came on them, declares the LORD.

**4** Hear the word of the LORD, house of Jacob, and all the clans of the house of Israel.

**5** This is what the LORD says: What wrong did your ancestors find in me, that they went far from me? They followed what is worthless and became worthless themselves.[^2-5]

**6** They did not say, "Where is the LORD, who brought us up from the land of Egypt, who led us through the wilderness, through a land of deserts and pits, through a land of drought and deep darkness,[^2-6] a land that no one travels through, where no human being lives?"

**7** I brought you into a fruitful land,[^2-7] to eat its fruit and its good things. But you came in and defiled my land, and made my inheritance detestable.

**8** The priests did not say, "Where is the LORD?" Those who handle the law did not know me. The shepherds[^2-8] rebelled against me. The prophets prophesied by Baal and followed things that do not profit.[^2-9]

**9** Therefore I will still bring charges against you,[^2-10] declares the LORD, and against your children's children I will bring charges.

**10** Cross over to the coasts of Kittim and look; send to Kedar and consider carefully;[^2-11] see if there has ever been anything like this.

**11** Has a nation ever exchanged its gods, even though they are not gods? But my people have exchanged their Glory[^2-12] for what does not profit.

**12** Be appalled at this, you heavens; shudder and be utterly desolate, declares the LORD.

**13** For my people have done two evils: they have abandoned me, the spring of living water,[^2-13] to dig out cisterns for themselves, cracked cisterns that cannot hold water.

**14** Is Israel a slave? Was he born a slave in the household?[^2-14] Then why has he become plunder?

**15** Young lions have roared over him; they have raised their voices. They have made his land a desolation; his cities are burned,[^2-15] with no one living in them.

**16** The people of Memphis and Tahpanhes[^2-16] have also shaved your head.[^2-17]

**17** Have you not brought this on yourself by abandoning the LORD your God, when he was leading you on the way?

**18** So now, what good is it for you to take the road to Egypt, to drink the waters of the Shihor?[^2-18] What good is it for you to take the road to Assyria, to drink the waters of the River?

**19** Your own evil will discipline you, and your faithlessness[^2-19] will rebuke you. Know and see how evil and bitter it is for you to abandon the LORD your God, and to have no fear of me,[^2-20] declares the Lord GOD of Armies.[^2-21]

**20** For long ago I broke your yoke[^2-22] and tore off your bonds, and you said, "I will not transgress."[^2-23] Yet on every high hill and under every leafy tree you lay down as a prostitute.

**21** I had planted you as a choice vine, wholly of true seed. How then have you turned against me into the wild shoots of a foreign vine?

**22** Even if you wash yourself with lye and use much soap,[^2-24] the stain of your guilt is still before me, declares the Lord GOD.[^2-25]

**23** How can you say, "I am not defiled; I have not gone after the Baals"?[^2-26] Look at your way in the valley;[^2-27] know what you have done, you swift young camel running here and there,[^2-28]

**24** a wild donkey used to the wilderness, sniffing the wind in her desire![^2-29] In her season of heat, who can turn her back? None who look for her need to tire themselves; in her month they will find her.

**25** Keep your feet from going bare and your throat from thirst![^2-30] But you said, "It's hopeless! No! For I love strangers,[^2-31] and I will go after them."

**26** As a thief is put to shame when he is caught, so the house of Israel is put to shame: they, their kings, their officials, their priests and their prophets.

**27** They say to a tree, "You are my father," and to a stone, "You gave birth to us."[^2-32] For they have turned their backs to me, not their faces. Yet in the time of their trouble they say, "Get up and save us!"

**28** But where are your gods that you made for yourself? Let them get up, if they can save you in the time of your trouble! For you have as many gods as you have cities, Judah.

**29** Why do you bring charges against me? All of you have rebelled against me, declares the LORD.

**30** In vain I have struck your children; they accepted no discipline. Your own sword has devoured your prophets like a ravaging lion.

**31** You people of this generation, consider the word of the LORD![^2-33] Have I been a wilderness to Israel, or a land of thick darkness? Why do my people say, "We roam free;[^2-34] we will not come to you again"?

**32** Does a young woman forget her jewelry, or a bride her sash? Yet my people have forgotten me for days without number.

**33** How well you set your course to seek love! So you have even taught your ways to wicked women.[^2-35]

**34** Even on your skirts[^2-36] is found the lifeblood of the innocent poor. You did not catch them breaking in.[^2-37] Yet in spite of all this[^2-38]

**35** you say, "I am innocent; surely his anger has turned away from me." Look, I will bring you to judgment because you say, "I have not sinned."

**36** How lightly you go about changing your way! You will be put to shame by Egypt, as you were put to shame by Assyria.

**37** From there too you will go out with your hands on your head,[^2-39] for the LORD has rejected those you trust, and you will not prosper with them.

[^2-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^2-2]: Jerusalem, and in much of this chapter Israel, is addressed as a woman. In the oracles of this book, the words of the LORD and of the prophet are not put in quotation marks, because the speaker often changes without being marked. Quotation marks are kept for conversations, and for words quoted within an oracle.
[^2-3]: Hebrew *chesed*: loyal, faithful love. Here it is the bride's devotion.
[^2-4]: The firstfruits of a harvest belonged to the LORD, and anyone else who ate them was guilty (Leviticus 22:10–16).
[^2-5]: Hebrew *hevel*, "breath, vapor", a word for what is empty and worthless, often used of idols. "Became worthless" is the verb from the same word: literally "they went after vapor and became vapor".
[^2-6]: Hebrew *tsalmavet*, "deep darkness", traditionally read as "the shadow of death".
[^2-7]: Hebrew *erets ha-karmel*, "the land of the orchard, garden land".
[^2-8]: That is, the rulers.
[^2-9]: Hebrew *lo yo'ilu*, "what does not profit", perhaps a play on the sound of *Baal*. Also in verse 11.
[^2-10]: Hebrew *riv*, to bring a case against someone, as in a court of law. Also in verse 29.
[^2-11]: Kittim (Cyprus) lay to the west, and Kedar, the tribes of the Arabian desert, to the east: search the world from one side to the other.
[^2-12]: Literally "his glory", meaning the glorious God who was theirs (compare Psalm 106:20). Jewish scribal tradition counts this among the places where the scribes changed the wording out of reverence, and says that it once read "my glory".
[^2-13]: Fresh, flowing water from a spring, as opposed to water stored in a cistern.
[^2-14]: A slave born in the master's house belonged to him for life.
[^2-15]: Or "laid in ruins".
[^2-16]: Hebrew *Noph*: Memphis, the old capital of Lower Egypt. Tahpanhes was a fortress city in the eastern Nile delta (43:7–9). The Hebrew text is written "Tahpanes" but read "Tahpanhes".
[^2-17]: Literally "will graze the crown of your head". Or "have cracked your skull".
[^2-18]: A branch of the Nile in the eastern delta; here, the Nile. "The River" is the Euphrates.
[^2-19]: Hebrew *meshuvah*, "turning away", from *shuv*, "turn, return". Jeremiah plays on this word often, especially in chapter 3.
[^2-20]: Literally "and my dread is not on you".
[^2-21]: Hebrew *Adonai YHWH tseva'ot*, "my Lord YHWH of Armies". *The LORD of Armies* is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel.
[^2-22]: Or "you broke your yoke". The Hebrew is pointed "I broke", referring to the LORD's freeing Israel from Egypt, but the ending can be an old form of "you" (compare verse 33), and the Septuagint reads "you broke".
[^2-23]: The Hebrew text is written "I will not serve" but read "I will not transgress".
[^2-24]: Hebrew *neter* (natron, a mineral used for washing) and *borit* (a soap made from plant ash).
[^2-25]: Hebrew *Adonai YHWH*, "my Lord YHWH". After "Lord", God's personal name is written GOD in capitals, as in most English Bibles.
[^2-26]: Local forms of the Canaanite god Baal.
[^2-27]: Probably the Valley of Ben-hinnom, outside Jerusalem, where children were sacrificed (7:31).
[^2-28]: Literally "crisscrossing her ways".
[^2-29]: The Hebrew text is written "his desire" but read "her desire".
[^2-30]: That is, don't wear out your sandals and parch your throat running after your lovers.
[^2-31]: That is, foreign gods.
[^2-32]: The tree and the stone are probably the wooden pole of Asherah and the standing stone of Canaanite worship. The Hebrew text is written "You gave birth to me" but read "You gave birth to us".
[^2-33]: The Hebrew is unusual. Literally "The generation, you, see the word of the LORD".
[^2-34]: Hebrew *radnu*, a rare verb, perhaps "we roam freely" or "we are free".
[^2-35]: Or "you have trained your ways in wickedness". The Hebrew text is written "I have taught" but read "you have taught". The written form may be an old spelling of "you have taught" (compare verse 20).
[^2-36]: Literally "on your wings", the edges of a robe.
[^2-37]: A householder who killed a burglar caught breaking in was not guilty of murder (Exodus 22:1; 22:2 in most English Bibles). These victims had done nothing of the kind.
[^2-38]: The Hebrew of this line is obscure. Literally "for on all these".
[^2-39]: A gesture of grief and shame (2 Samuel 13:19).

## Chapter 3

*Status: draft*

**1** If a man sends his wife away,[^3-1] and she leaves him and becomes another man's wife, will he go back to her again? Would that land not be utterly defiled?[^3-2] But you have prostituted yourself with many lovers, and would you return to me?[^3-3] declares the LORD.[^3-4]

**2** Lift up your eyes to the bare heights and look: where have you not been lain with?[^3-5] You sat by the roads waiting for them, like a nomad[^3-6] in the desert. You have defiled the land with your prostitution and your wickedness.

**3** So the showers have been held back, and the spring rain[^3-7] has not come. Yet you have the brazen look of a prostitute;[^3-8] you refuse to be ashamed.

**4** Have you not just now called to me,[^3-9] "My father, you are the companion of my youth!

**5** Will he stay angry forever? Will he keep his anger to the end?" Look, that is how you have spoken, yet you have done all the evil you could.

**6** The LORD said to me in the days of King Josiah: Have you seen what Faithless Israel[^3-10] has done? She went up on every high mountain and under every leafy tree, and prostituted herself there.

**7** I thought, "After she has done all this, she will return to me." But she did not return, and her treacherous sister Judah saw it.

**8** I saw that, though I had sent Faithless Israel away and given her a certificate of divorce for all her adulteries, her treacherous sister Judah had no fear. She too went and prostituted herself.

**9** Because her prostitution meant so little to her,[^3-11] she defiled the land, committing adultery with stone and tree.[^3-12]

**10** Yet for all this her treacherous sister Judah did not return to me with all her heart, but only in pretense, declares the LORD.

**11** The LORD said to me: Faithless Israel has shown herself more righteous than treacherous Judah.

**12** Go and proclaim these words toward the north, and say: Return, Faithless Israel,[^3-13] declares the LORD. I will not look on you in anger,[^3-14] for I am faithful,[^3-15] declares the LORD; I will not stay angry forever.

**13** Only acknowledge your guilt, that you have rebelled against the LORD your God. You have spread your favors[^3-16] to strangers under every leafy tree, and you have not listened to my voice, declares the LORD.

**14** Return, faithless children,[^3-17] declares the LORD, for I am your master.[^3-18] I will take you, one from a city and two from a clan, and bring you to Zion.

**15** I will give you shepherds after my own heart, and they will feed you with knowledge and understanding.

**16** When you have multiplied and become fruitful in the land in those days, declares the LORD, people will no longer say, "The ark of the covenant of the LORD." It will not come to mind. They will not remember it or miss it, and another will not be made.

**17** At that time they will call Jerusalem "The Throne of the LORD," and all the nations will gather to it, to the name of the LORD, to Jerusalem. They will no longer follow the stubbornness of their evil hearts.

**18** In those days the house of Judah will join the house of Israel, and together they will come from the land of the north to the land I gave your ancestors as an inheritance.

**19** I myself said: How I would set you among my sons,[^3-19] and give you a pleasant land, the most beautiful inheritance among the nations![^3-20] I thought you would call me "My father," and would not turn back from following me.

**20** But as a woman is unfaithful to her lover, so you have been unfaithful to me, house of Israel, declares the LORD.

**21** A voice is heard on the bare heights, the weeping and pleading of the Israelites, because they have twisted their way; they have forgotten the LORD their God.

**22** Return, faithless children; I will heal your faithlessness. "Here we are;[^3-21] we come to you, for you are the LORD our God.

**23** Surely the hills are a delusion, the uproar on the mountains.[^3-22] Surely in the LORD our God is the salvation of Israel.

**24** But the Shameful Thing[^3-23] has devoured what our ancestors worked for since our youth: their flocks and their herds, their sons and their daughters.

**25** Let us lie down in our shame, and let our disgrace cover us. For we have sinned against the LORD our God, we and our ancestors, from our youth until this day, and we have not listened to the voice of the LORD our God."

[^3-1]: The Hebrew begins with *lemor*, "saying", perhaps left from an introduction like the one in 2:1. The law in view is Deuteronomy 24:1–4, which forbids a man to take back a wife he has divorced after she has married another man.
[^3-2]: Literally "Would that land not be greatly polluted?"
[^3-3]: Or "yet return to me!"
[^3-4]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^3-5]: The Hebrew text is written with a coarser verb, *shagal*, "been ravished", but read "been lain with".
[^3-6]: Hebrew *aravi*, "an Arab", a desert nomad, who waits by the road for travelers.
[^3-7]: Hebrew *malqosh*, the "latter rain" of March and April, which the crops need before harvest.
[^3-8]: Literally "the forehead of a prostitute".
[^3-9]: The Hebrew text is written "I have called" but read "you have called", and in verse 5 is written "I have spoken" but read "you have spoken". The written forms are probably an old spelling of "you" (compare 2:20, 33).
[^3-10]: Hebrew *meshuvah yisra'el*, "Turning-away Israel", as though it were her name. The northern kingdom of Israel had been destroyed by Assyria about a century before (2 Kings 17).
[^3-11]: Literally "from the lightness of her prostitution".
[^3-12]: That is, with idols of stone and wood (2:27).
[^3-13]: A wordplay on *shuv*, "turn, return": *shuvah meshuvah yisra'el*, "Turn back, Turning-away Israel". Verses 14 and 22 play on the same root.
[^3-14]: Literally "I will not make my face fall on you".
[^3-15]: Hebrew *chasid*, related to *chesed*, "faithful love".
[^3-16]: Literally "you have scattered your ways".
[^3-17]: Literally "Return, turning-away sons" (Hebrew *shuvu banim shovavim*). Also in verse 22.
[^3-18]: Or "your husband". Hebrew *ba'alti*, from *ba'al*, "lord, owner, husband", the same word as the name of the god Baal.
[^3-19]: Israel, pictured as a daughter, is given a son's share of the inheritance.
[^3-20]: Hebrew *nachalat tsevi tsiv'ot goyim*, literally "an inheritance of beauty, of the beauties of the nations".
[^3-21]: The people's answer, to the end of verse 25.
[^3-22]: The Hebrew is difficult. Literally "Surely for a lie from the hills, the tumult of the mountains". The hills and mountains were places of worship of other gods (verse 6).
[^3-23]: Hebrew *ha-boshet*, "the shame", a scornful name for Baal (11:13).

## Chapter 4

*Status: draft*

**1** If you return, Israel, declares the LORD,[^4-1] return to me. If you put your detestable idols[^4-2] out of my sight and do not stray,

**2** and if you swear, "As surely as the LORD lives," in truth, in justice and in righteousness, then the nations will bless themselves by him, and in him they will glory.[^4-3]

**3** For this is what the LORD says to the people of Judah and to Jerusalem: Break up your unplowed ground,[^4-4] and do not sow among thorns.

**4** Circumcise yourselves to the LORD; remove the foreskins of your hearts,[^4-5] people of Judah and inhabitants of Jerusalem, or my wrath will break out like fire and burn with no one to put it out, because of the evil of your deeds.

**5** Declare it in Judah, proclaim it in Jerusalem, and say: Blow the ram's horn[^4-6] throughout the land! Shout aloud[^4-7] and say, "Gather together, and let us go into the fortified cities!"

**6** Raise a signal flag toward Zion! Run for safety; do not stand still! For I am bringing disaster from the north, and great destruction.[^4-8]

**7** A lion has come up from its thicket; a destroyer of nations has set out. He has left his place to make your land a desolation. Your cities will be ruined, with no one living in them.

**8** So put on sackcloth, mourn and wail, for the fierce anger of the LORD has not turned away from us.

**9** On that day, declares the LORD, the king and the officials will lose heart.[^4-9] The priests will be appalled, and the prophets will be astounded.

**10** Then I said, "Ah, Lord GOD![^4-10] Surely you have utterly deceived this people and Jerusalem, saying, 'You will have peace,' when the sword is at our throat!"[^4-11]

**11** At that time it will be said to this people and to Jerusalem: A scorching wind from the bare heights in the wilderness is coming toward my dear people,[^4-12] not to winnow and not to cleanse,

**12** a wind too strong for that,[^4-13] coming at my command. Now I myself will pronounce judgments against them.

**13** Look, he comes up like clouds, his chariots like the whirlwind; his horses are swifter than eagles. Woe to us, for we are ruined!

**14** Wash the evil from your heart, Jerusalem, so that you may be saved. How long will your wicked thoughts lodge within you?

**15** For a voice is declaring from Dan, and proclaiming disaster from the hill country of Ephraim.[^4-14]

**16** Tell the nations, "Look!"[^4-15] Proclaim against Jerusalem: Besiegers[^4-16] are coming from a distant land; they raise their voices against the cities of Judah.

**17** Like men guarding a field, they surround her on every side, because she has rebelled against me, declares the LORD.

**18** Your own way and your deeds have brought this on you. This is your evil. How bitter it is! How it reaches your heart!

**19** My insides,[^4-17] my insides! I writhe in pain! The walls of my heart! My heart pounds within me; I cannot keep silent. For you have heard, my soul,[^4-18] the sound of the ram's horn, the battle cry.

**20** Disaster follows disaster;[^4-19] the whole land is devastated. Suddenly my tents are devastated, my tent curtains in a moment.

**21** How long must I see the signal flag and hear the sound of the ram's horn?

**22** For my people are foolish; they do not know me. They are senseless children; they have no understanding. They are skilled at doing evil, but they do not know how to do good.

**23** I looked at the earth, and it was formless and empty;[^4-20] at the heavens, and their light was gone.

**24** I looked at the mountains, and they were quaking; all the hills were swaying.

**25** I looked, and there were no human beings, and all the birds of the sky had fled.

**26** I looked, and the fruitful land[^4-21] was a wilderness, and all its cities were torn down before the LORD, before his fierce anger.

**27** For this is what the LORD says: The whole land will be a desolation, yet I will not make a full end of it.

**28** Because of this the earth will mourn, and the heavens above will grow dark, because I have spoken, I have purposed, and I have not relented, nor will I turn back from it.

**29** At the noise of horsemen and archers the whole city flees. They go into the thickets and climb up among the rocks. Every city is abandoned; no one lives in them.

**30** And you, devastated one, what are you doing? Though you dress in scarlet, though you put on gold jewelry, though you enlarge your eyes with paint,[^4-22] you make yourself beautiful in vain. Your lovers despise you; they seek your life.

**31** For I hear a cry like that of a woman in labor, the anguish of one bearing her first child, the cry of Daughter Zion[^4-23] gasping for breath, stretching out her hands: "Woe is me! My life is fainting before the killers!"

[^4-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^4-2]: Hebrew *shiqqutsim*, "detestable things", a contemptuous word for idols.
[^4-3]: Or "will be blessed by him". Compare Genesis 12:3; 22:18.
[^4-4]: Hebrew *nir*, ground left unplowed, which has to be broken up before it can be sown.
[^4-5]: Compare Deuteronomy 10:16; 30:6.
[^4-6]: Hebrew *shofar*, a trumpet made from a ram's horn, sounded as an alarm in war. The Hebrew text is written "and blow" but read "Blow".
[^4-7]: Literally "Call out, fill", that is, cry out with a full voice.
[^4-8]: Hebrew *shever*, "breaking". Also in verse 20.
[^4-9]: Literally "the heart of the king and the heart of the officials will perish".
[^4-10]: Hebrew *Adonai YHWH*, "my Lord YHWH". After "Lord", God's personal name is written GOD in capitals, as in most English Bibles.
[^4-11]: Literally "and the sword has reached to the life".
[^4-12]: Literally "the daughter of my people", a tender, poetic name for the nation.
[^4-13]: Literally "a wind fuller than these". Winnowing needed a gentle breeze to carry off the chaff; this wind will blow everything away.
[^4-14]: Dan was in the far north of the land, and the hill country of Ephraim just north of Judah: the news comes nearer and nearer to Jerusalem.
[^4-15]: Or "Remind the nations: Look!" The Hebrew is difficult.
[^4-16]: Literally "watchers" or "guards", here those who keep watch around a besieged city.
[^4-17]: Hebrew *me'ai*, "my bowels", thought of as the seat of the emotions.
[^4-18]: The Hebrew text is written "For I have heard, my soul," but read "For you have heard, my soul".
[^4-19]: Literally "Breaking upon breaking is proclaimed".
[^4-20]: Hebrew *tohu va-vohu*, the phrase used of the earth before creation in Genesis 1:2. Verses 23–26 picture creation undone.
[^4-21]: Hebrew *karmel*, "orchard, garden land".
[^4-22]: Literally "tear open your eyes with antimony", a dark eye paint (2 Kings 9:30).
[^4-23]: A poetic name for Jerusalem and its people, pictured as a young woman.

## Chapter 5

*Status: draft*

**1** Roam through the streets of Jerusalem; look around and take note. Search her squares to see if you can find one person,[^5-1] anyone who does justice and seeks to be faithful, so that I may forgive her.

**2** Though they say, "As surely as the LORD[^5-2] lives," they are still swearing falsely.

**3** LORD, do your eyes not look for faithfulness? You struck them, but they felt no pain; you crushed them, but they refused to accept discipline. They made their faces harder than rock; they refused to turn back.

**4** I thought, "These are only the poor. They are foolish, for they do not know the way of the LORD, what their God requires.[^5-3]

**5** I will go to the great men and speak to them, for surely they know the way of the LORD, what their God requires." But they too, all of them, had broken the yoke and torn off the bonds.

**6** So a lion from the forest will strike them down, a wolf from the desert[^5-4] will destroy them, and a leopard is watching[^5-5] their cities. Everyone who goes out of them will be torn to pieces, for their rebellions are many, their acts of faithlessness[^5-6] are numerous.

**7** How can I forgive you for this? Your children have abandoned me and sworn by gods that are not gods. I fed them until they were full, and they committed adultery and thronged[^5-7] to the house of a prostitute.

**8** They are well-fed, lusty stallions;[^5-8] each one neighs for his neighbor's wife.

**9** Should I not punish them for these things? declares the LORD. Should I not avenge myself[^5-9] on a nation like this?

**10** Go up through her vineyard rows and destroy, but do not make a full end. Strip away her branches, for they do not belong to the LORD.

**11** For the house of Israel and the house of Judah have been utterly unfaithful to me, declares the LORD.

**12** They have denied the LORD and said, "He will do nothing![^5-10] No disaster will come on us; we will not see sword or famine.

**13** The prophets are only wind;[^5-11] the word is not in them. So may it be done to them!"[^5-12]

**14** Therefore this is what the LORD, the God of Armies,[^5-13] says: Because you people have spoken this word, I am going to make my words in your mouth[^5-14] a fire, and this people wood, and it will consume them.

**15** I am going to bring against you a nation from far away, house of Israel, declares the LORD. It is an enduring nation, an ancient nation, a nation whose language you do not know, and you will not understand what they say.[^5-15]

**16** Their quiver is like an open grave; all of them are warriors.

**17** They will devour your harvest and your food; they will devour your sons and your daughters. They will devour your flocks and your herds; they will devour your vines and your fig trees. With the sword they will shatter the fortified cities you trust in.

**18** Yet even in those days, declares the LORD, I will not make a full end of you.

**19** And when you ask, "Why has the LORD our God done all these things to us?" you[^5-16] are to say to them, "As you have abandoned me and served foreign gods in your land, so you will serve strangers in a land that is not yours."

**20** Declare this in the house of Jacob, and proclaim it in Judah:

**21** Hear this, you foolish and senseless people,[^5-17] who have eyes but do not see, who have ears but do not hear.

**22** Do you not fear me? declares the LORD. Do you not tremble before me? I placed the sand as a boundary for the sea, a permanent limit that it cannot cross. Its waves toss, but they cannot prevail; they roar, but they cannot cross it.

**23** But this people has a stubborn and rebellious heart; they have turned aside and gone away.

**24** They do not say in their hearts, "Let us fear the LORD our God, who gives the rain, the autumn rain and the spring rain,[^5-18] in its season, who keeps for us the weeks appointed for the harvest."

**25** Your wrongdoings have turned these away; your sins have kept good things from you.

**26** For among my people are found wicked men. They watch like fowlers lying in wait;[^5-19] they set a trap; they catch human beings.

**27** Like a cage full of birds, their houses are full of deceit. That is how they have become great and rich.

**28** They have grown fat and sleek. They have even gone beyond all bounds in evil.[^5-20] They do not plead the cause, the cause of the fatherless, yet they prosper; they do not defend the rights of the needy.

**29** Should I not punish them for these things? declares the LORD. Should I not avenge myself on a nation like this?

**30** An appalling and horrible thing has happened in the land:

**31** the prophets prophesy falsely, and the priests rule as they direct,[^5-21] and my people love it so. But what will you do when the end comes?

[^5-1]: Literally "a man".
[^5-2]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^5-3]: Hebrew *mishpat*, "justice, ruling". Literally "the justice of their God". Also in verse 5.
[^5-4]: Or "a wolf of the evening".
[^5-5]: Hebrew *shoqed*, the word used in 1:12.
[^5-6]: Hebrew *meshuvot*, "turnings away": see 2:19.
[^5-7]: Or "gashed themselves", as in rites of mourning or worship (16:6; 1 Kings 18:28).
[^5-8]: The meaning of the Hebrew words is uncertain.
[^5-9]: Literally "Should my soul not avenge itself". Also in verse 29.
[^5-10]: Literally "Not he!", that is, he does not count, or he will not act.
[^5-11]: Hebrew *ruach*, "wind, spirit". The prophets claim to speak by the spirit, but they are only wind.
[^5-12]: The people's words may end before this sentence, which would then be the LORD's answer: "So it will be done to them."
[^5-13]: Hebrew *YHWH Elohei tseva'ot*, traditionally "the LORD God of hosts". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel.
[^5-14]: *You people* is plural, the people of Judah; *your mouth* is singular, the prophet's.
[^5-15]: Compare Deuteronomy 28:49.
[^5-16]: Singular, the prophet. The first "you" in the verse is plural, the people.
[^5-17]: Literally "without heart". In Hebrew the heart is the seat of thought and understanding.
[^5-18]: Hebrew *yoreh* and *malqosh*, the rains of autumn (October–November), which soften the ground for sowing, and of spring (March–April), which ripen the crops.
[^5-19]: The Hebrew is difficult. Literally "He watches like the crouching of fowlers".
[^5-20]: Literally "they have passed over the matters of evil". Or "they have overlooked evil deeds".
[^5-21]: Literally "rule on their hands". Or "rule by their own authority".

## Chapter 6

*Status: draft*

**1** Run for safety, people of Benjamin, out of the midst of Jerusalem! Blow the ram's horn in Tekoa,[^6-1] and raise a signal fire over Beth-hakkerem![^6-2] For disaster looms from the north, and great destruction.

**2** Daughter Zion,[^6-3] so lovely and delicate, I will destroy.[^6-4]

**3** Shepherds with their flocks will come to her. They will pitch their tents against her all around; each will graze his own part.

**4** "Prepare for war against her![^6-5] Up, let us attack at noon! Woe to us, for the day is fading; the evening shadows are lengthening.

**5** Up, let us attack by night and destroy her fortresses!"

**6** For this is what the LORD of Armies[^6-6] says: Cut down her trees and pile up a siege ramp against Jerusalem. This is the city that must be punished;[^6-7] there is nothing but oppression within her.

**7** As a well keeps its water fresh, so she keeps her wickedness fresh. Violence and destruction are heard in her; sickness and wounds are always before me.

**8** Take warning, Jerusalem, or I will turn from you in disgust[^6-8] and make you a desolation, a land where no one lives.

**9** This is what the LORD of Armies says: They will glean the remnant of Israel as thoroughly as a vine. Pass your hand over the branches again, like a grape picker.

**10** To whom can I speak and give warning, so that they will listen? Look, their ears are uncircumcised,[^6-9] and they cannot pay attention. Look, the word of the LORD has become an object of scorn to them; they take no pleasure in it.

**11** But I am full of the wrath of the LORD; I am weary of holding it in. Pour it out on the children in the street, and on the young men gathered together. For husband and wife alike will be caught, the old and those full of years.

**12** Their houses will be turned over to others, their fields and their wives together, for I will stretch out my hand against those who live in the land, declares the LORD.

**13** For from the least of them to the greatest, every one is greedy for unjust gain; from prophet to priest, every one deals falsely.

**14** They have treated the wound[^6-10] of my people as though it were nothing, saying, "Peace, peace,"[^6-11] when there is no peace.

**15** They acted shamefully, for they did detestable things,[^6-12] yet they were not at all ashamed; they did not even know how to blush. So they will fall among those who fall; when I punish them, they will stumble, says the LORD.

**16** This is what the LORD says: Stand by the roads and look, and ask for the ancient paths, where the good way is, and walk in it, and you will find rest for yourselves.[^6-13] But they said, "We will not walk in it."

**17** I appointed watchmen over you: "Listen to the sound of the ram's horn!" But they said, "We will not listen."

**18** Therefore hear, you nations, and know, you assembly,[^6-14] what will happen to them.

**19** Hear, you earth: I am going to bring disaster on this people, the fruit of their own schemes, because they have not paid attention to my words, and they have rejected my instruction.[^6-15]

**20** What use to me is frankincense that comes from Sheba, or sweet cane[^6-16] from a distant land? Your burnt offerings are not acceptable, and your sacrifices do not please me.

**21** Therefore this is what the LORD says: I am going to put obstacles before this people. Fathers and sons together will stumble over them; neighbor and friend will perish.

**22** This is what the LORD says: Look, a people is coming from the land of the north; a great nation is being stirred up from the farthest parts of the earth.

**23** They grasp bow and javelin; they are cruel and show no mercy. Their sound is like the roaring sea; they ride on horses, drawn up like warriors for battle against you, Daughter Zion.

**24** We have heard the report of them; our hands hang limp. Anguish has gripped us, pain like that of a woman in labor.

**25** Do not go out into the field or walk on the road, for the enemy has a sword. Terror is on every side.[^6-17]

**26** My dear people,[^6-18] put on sackcloth and roll in ashes. Mourn as for an only son, with bitter wailing, for suddenly the destroyer will come upon us.

**27** I have made you a tester of metals among my people, a fortress,[^6-19] so that you may know and test their ways.

**28** They are all the most stubborn of rebels, going about with slander. They are bronze and iron; all of them act corruptly.

**29** The bellows blow fiercely; the lead is consumed by the fire.[^6-20] The refining goes on in vain; the wicked are not drawn off.

**30** They are called rejected silver, for the LORD has rejected them.

[^6-1]: A wordplay: *bi-teqoa tiq'u*, "in Tekoa blow". Tekoa was a town about 10 miles (16 km) south of Jerusalem, the home of Amos (Amos 1:1).
[^6-2]: A town near Jerusalem, probably to the south. The name means "house of the vineyard".
[^6-3]: A poetic name for Jerusalem and its people, pictured as a young woman. Also in verse 23.
[^6-4]: Or "I will silence". The same consonants can be read "I have compared Daughter Zion to a lovely pasture", which would lead into the picture of shepherds in verse 3.
[^6-5]: Literally "Consecrate war against her", from the religious rites that opened a campaign. The enemy is speaking in verses 4–5.
[^6-6]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles. *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. Also in verse 9.
[^6-7]: The Hebrew is difficult. Literally "She is the city; it has been punished".
[^6-8]: Literally "or my soul will be wrenched from you".
[^6-9]: That is, closed, unable to hear.
[^6-10]: Hebrew *shever*, "breaking, fracture".
[^6-11]: Hebrew *shalom*, "peace, well-being": "All is well".
[^6-12]: Or "Were they ashamed when they did detestable things?"
[^6-13]: Hebrew *nephesh*, "soul, self". Literally "for your souls".
[^6-14]: Hebrew *edah*, a gathered community. The meaning of the line is uncertain.
[^6-15]: Hebrew *torah*, "instruction, law".
[^6-16]: An aromatic reed used in incense and anointing oil (Exodus 30:23).
[^6-17]: Hebrew *magor missaviv*, a phrase Jeremiah uses often (20:3, 10; 46:5; 49:29).
[^6-18]: Literally "Daughter of my people", a tender, poetic name for the nation.
[^6-19]: Hebrew *mivtsar* usually means "fortress" (compare 1:18). Some scholars connect it here with *betser*, "ore". Jeremiah is to test the people as metal is tested.
[^6-20]: The Hebrew text is written as one word, perhaps "from their fire", but read as two, "by the fire is consumed". In refining silver, lead was added to carry away the impurities. Here the lead burns away, but the impurities remain.

## Chapter 7

*Status: draft*

**1** The word that came to Jeremiah from the LORD:[^7-1]

**2** Stand in the gate of the LORD's house and proclaim this word there. Say: Hear the word of the LORD, all you people of Judah who come in through these gates to worship the LORD.[^7-2]

**3** This is what the LORD of Armies,[^7-3] the God of Israel, says: Make your ways and your deeds good, and I will let you live in this place.[^7-4]

**4** Do not trust in deceptive words: "This is the temple of the LORD, the temple of the LORD, the temple of the LORD!"[^7-5]

**5** For if you truly make your ways and your deeds good, if you truly do justice between one person and another,

**6** if you do not oppress the foreigner, the fatherless and the widow, and do not shed innocent blood in this place, and do not follow other gods to your own harm,

**7** then I will let you live in this place, in the land I gave your ancestors, for all time.[^7-6]

**8** But look, you are trusting in deceptive words that are worthless.

**9** Will you steal, murder, commit adultery, swear falsely, burn incense[^7-7] to Baal and follow other gods you have not known,

**10** and then come and stand before me in this house, which bears my name,[^7-8] and say, "We are safe!", only to go on doing all these detestable things?

**11** Has this house, which bears my name, become a den of robbers in your eyes?[^7-9] But I, look, I have seen it, declares the LORD.

**12** Go now to my place that was in Shiloh, where I first made my name dwell, and see what I did to it because of the wickedness of my people Israel.[^7-10]

**13** And now, because you have done all these things, declares the LORD, and though I spoke to you again and again,[^7-11] you did not listen, and when I called you, you did not answer,

**14** I will do to the house that bears my name, the house you trust in, the place I gave to you and your ancestors, just what I did to Shiloh.

**15** I will throw you out of my sight, just as I threw out all your relatives, all the descendants of Ephraim.[^7-12]

**16** As for you, do not pray for this people. Do not raise a cry or a prayer for them, and do not plead with me, for I will not listen to you.

**17** Do you not see what they are doing in the cities of Judah and in the streets of Jerusalem?

**18** The children gather wood, the fathers light the fire, and the women knead dough to make cakes for the Queen of Heaven.[^7-13] They pour out drink offerings to other gods to provoke me to anger.

**19** But is it I they are provoking? declares the LORD. Is it not themselves, to their own shame?[^7-14]

**20** Therefore this is what the Lord GOD[^7-15] says: My anger and my wrath will be poured out on this place, on human beings and animals, on the trees of the field and the produce of the ground. It will burn and not be put out.

**21** This is what the LORD of Armies, the God of Israel, says: Add your burnt offerings to your sacrifices, and eat the meat yourselves![^7-16]

**22** For when I brought your ancestors out of the land of Egypt, I did not speak to them or command them about burnt offerings and sacrifices.

**23** But this is what I commanded them: "Listen to my voice, and I will be your God, and you will be my people. Walk in all the way that I command you, so that it may go well with you."

**24** But they did not listen or pay attention.[^7-17] They followed their own plans, in the stubbornness of their evil hearts. They went backward and not forward.

**25** From the day your ancestors came out of the land of Egypt until this day, I have sent you all my servants the prophets, sending them again and again, day after day.

**26** But they did not listen to me or pay attention. They stiffened their necks;[^7-18] they did more evil than their ancestors.

**27** When you tell them all these things, they will not listen to you. When you call to them, they will not answer you.

**28** So say to them: This is the nation that has not listened to the voice of the LORD its God and has not accepted discipline. Truth[^7-19] has perished; it has been cut off from their mouths.

**29** Cut off your hair[^7-20] and throw it away; raise a lament on the bare heights, for the LORD has rejected and abandoned the generation that has roused his fury.

**30** For the people of Judah have done what is evil in my eyes, declares the LORD. They have set up their detestable idols in the house that bears my name, and defiled it.

**31** They have built the high places[^7-21] of Topheth in the Valley of Ben-hinnom,[^7-22] to burn their sons and their daughters in the fire, something I did not command, nor did it ever enter my mind.

**32** Therefore, look, the days are coming, declares the LORD, when it will no longer be called Topheth or the Valley of Ben-hinnom, but the Valley of Slaughter. They will bury the dead in Topheth until there is no room left.[^7-23]

**33** The corpses of this people will be food for the birds of the sky and the animals of the earth, with no one to frighten them away.

**34** I will put an end to the sound of joy and the sound of gladness, the voice of the bridegroom and the voice of the bride, in the cities of Judah and the streets of Jerusalem, for the land will become a ruin.

[^7-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles. "The LORD's house" and "this house" in this chapter are the temple. Chapter 26 tells what happened when Jeremiah gave this message.
[^7-2]: The message Jeremiah is to proclaim runs to verse 15, and verses 16–34 continue the LORD's words to him.
[^7-3]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. Also in verse 21.
[^7-4]: The same consonants can be read "and I will live with you in this place". Also in verse 7.
[^7-5]: Literally "the temple of the LORD, the temple of the LORD, the temple of the LORD are these". The words are a slogan: The LORD would never let his own temple fall.
[^7-6]: Literally "from long ago and to forever".
[^7-7]: Or "burn offerings". The Hebrew verb *qatar* means to make something go up in smoke.
[^7-8]: Literally "over which my name is called", that is, which belongs to me. Also in verses 11, 14 and 30.
[^7-9]: Jesus quotes this line in Mark 11:17.
[^7-10]: The tabernacle stood at Shiloh in the time of Eli (1 Samuel 1–4). The town seems to have been destroyed after the Philistines captured the ark (Psalm 78:60).
[^7-11]: Literally "rising early and speaking", a phrase Jeremiah uses often for the LORD's persistent warnings. Also in verse 25.
[^7-12]: That is, the people of the northern kingdom, taken into exile by Assyria (2 Kings 17:6, 18–23).
[^7-13]: Probably the Mesopotamian goddess Ishtar, or the Canaanite Astarte, worshiped as a goddess of love and of the sky (44:17–19, 25).
[^7-14]: Literally "to the shame of their faces".
[^7-15]: Hebrew *Adonai YHWH*, "my Lord YHWH". After "Lord", God's personal name is written GOD in capitals, as in most English Bibles.
[^7-16]: A burnt offering was burned whole on the altar, while the meat of most other sacrifices was eaten by the worshipers. The LORD scornfully tells them to eat it all.
[^7-17]: Literally "did not incline their ear". Also in verse 26.
[^7-18]: That is, they were stubborn, like an ox that will not bend its neck to the yoke.
[^7-19]: Or "Faithfulness". Hebrew *emunah*.
[^7-20]: Literally "Shear your crown". The word *nezer* is used of the uncut hair of a Nazirite, consecrated to God (Numbers 6:5–7). *Your* is feminine: Jerusalem is addressed.
[^7-21]: Hebrew *bamot*: places of worship, often on hilltops.
[^7-22]: Hebrew *tofet*, perhaps "fireplace, hearth", a place where children were burned as sacrifices (2 Kings 23:10). Ben-hinnom, "the Son of Hinnom", was a valley south and west of Jerusalem.
[^7-23]: Or "because there will be no other place".

## Chapter 8

*Status: draft*

**1** At that time, declares the LORD,[^8-1] the bones of the kings of Judah, the bones of its officials, the bones of the priests, the bones of the prophets and the bones of the inhabitants of Jerusalem will be brought out of their graves.

**2** They will be spread out before the sun and the moon and all the host of heaven,[^8-2] which they have loved and served, which they have followed, consulted and worshiped. They will not be gathered up or buried; they will be like dung on the surface of the ground.

**3** Death will be chosen rather than life by all the remnant that is left of this evil family, in all the places where I have driven them,[^8-3] declares the LORD of Armies.[^8-4]

**4** Say to them: This is what the LORD says: When people fall, do they not get up? When someone turns away, does he not turn back?[^8-5]

**5** Why then has this people, Jerusalem, turned away in endless faithlessness? They hold fast to deceit; they refuse to turn back.

**6** I have listened carefully, but they do not speak what is right. No one repents of his wickedness, saying, "What have I done?" Each of them turns to his own course, like a horse charging into battle.

**7** Even the stork in the sky knows her seasons, and the dove, the swift[^8-6] and the thrush keep the time of their coming. But my people do not know what the LORD requires.[^8-7]

**8** How can you say, "We are wise, and the law of the LORD is with us"? But look, the lying pen of the scribes has turned it into a lie.[^8-8]

**9** The wise will be put to shame; they will be dismayed and caught. Look, they have rejected the word of the LORD, so what wisdom do they have?

**10** Therefore I will give their wives to others and their fields to new owners.[^8-9] For from the least to the greatest, every one is greedy for unjust gain; from prophet to priest, every one deals falsely.

**11** They have treated the wound of my dear people[^8-10] as though it were nothing, saying, "Peace, peace," when there is no peace.

**12** They acted shamefully, for they did detestable things, yet they were not at all ashamed; they did not know how to blush. So they will fall among those who fall; at the time of their punishment they will stumble, says the LORD.

**13** I will gather them and make an end of them,[^8-11] declares the LORD. There will be no grapes on the vine, no figs on the fig tree, and even the leaves will wither. What I gave them will pass away from them.[^8-12]

**14** "Why are we sitting here?[^8-13] Gather together! Let us go into the fortified cities and perish there. For the LORD our God has doomed us to perish and given us poisoned water to drink, because we have sinned against the LORD.

**15** We hoped for peace, but no good has come; for a time of healing, but there is only terror."

**16** From Dan the snorting of his horses is heard; at the sound of the neighing of his stallions the whole land quakes. They come and devour the land and everything in it, the city and those who live in it.

**17** For I am sending snakes among you, vipers that no charm can stop, and they will bite you, declares the LORD.

**18** My joy is gone; grief has come upon me;[^8-14] my heart is sick within me.

**19** Listen! The cry of my dear people from a land far and wide:[^8-15] "Is the LORD not in Zion? Is her King not in her?" Why have they provoked me to anger with their carved images, with their worthless foreign idols?[^8-16]

**20** "The harvest is past, the summer has ended, and we are not saved."

**21** Because my dear people are broken, I am broken. I go about in mourning; horror has gripped me.

**22** Is there no balm in Gilead?[^8-17] Is there no physician there? Why then has no new skin grown over the wound of my dear people?[^8-18]

**23** Oh, that my head were water and my eyes a fountain of tears, so that I could weep day and night for the slain of my dear people![^8-19]

[^8-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^8-2]: The sun, moon and stars, worshiped as gods (2 Kings 21:3–5; 23:4–5).
[^8-3]: Literally "in all the remaining places where I have driven them".
[^8-4]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel.
[^8-5]: Verses 4–5 play on the verb *shuv*, "turn, return", which can mean both turning away from the LORD and turning back to him (see 2:19; 3:12).
[^8-6]: The Hebrew text is written *sus*, "horse", but read *sis*, "swift". The names of some of these birds are uncertain.
[^8-7]: Hebrew *mishpat*, "justice, ruling". Literally "the justice of the LORD".
[^8-8]: Or "has worked for a lie". The scribes copied and taught the law, and Jeremiah says they have falsified it.
[^8-9]: The Septuagint has only the first part of this verse. Verses 10b–12, which repeat 6:13–15 with small differences, are not in it.
[^8-10]: Literally "the daughter of my people", a tender, poetic name for the nation. Also in verses 19, 21, 22 and 23.
[^8-11]: The Hebrew is a wordplay. Literally "Gathering, I will make an end of them", combining *asaf*, "gather, harvest", and *suf*, "come to an end". The picture is a harvest that finds nothing.
[^8-12]: The Hebrew of this line is obscure. Literally "and I gave to them, they pass over them".
[^8-13]: The people speak in verses 14–15.
[^8-14]: The Hebrew of this line is obscure. Literally "My brightening up, on me is grief". The prophet speaks in verses 18–23, quoting the people's cry and the LORD's reply (verse 19).
[^8-15]: Or "from a distant land", as if from exile.
[^8-16]: Hebrew *hevel*, "vapor, breath": see 2:5. Literally "with the vapors of a foreign land".
[^8-17]: Hebrew *tsori*, a healing resin for which Gilead, east of the Jordan, was famous (Genesis 37:25).
[^8-18]: Literally "Why has the new flesh of the daughter of my people not come up?"
[^8-19]: This verse is 9:1 in most English Bibles, which begin chapter 9 here, so that their verse numbers in chapter 9 are one higher than the Hebrew.

## Chapter 9

*Status: draft*

**1** Oh, that I had in the wilderness a travelers' shelter,[^9-1] so that I could leave my people and go away from them! For they are all adulterers, a crowd of traitors.

**2** They bend their tongues like bows to shoot lies.[^9-2] It is not by faithfulness that they have grown strong in the land, for they go from evil to evil, and they do not know me, declares the LORD.[^9-3]

**3** Let everyone be on guard against his neighbor, and do not trust any brother. For every brother is a cheat like Jacob,[^9-4] and every neighbor goes about slandering.

**4** Each one deceives his neighbor, and no one speaks the truth. They have taught their tongues to speak lies; they wear themselves out doing wrong.

**5** You live in the midst of deceit; in their deceit they refuse to know me, declares the LORD.

**6** Therefore this is what the LORD of Armies[^9-5] says: I am going to refine them and test them, for what else can I do because of my dear people?[^9-6]

**7** Their tongue is a sharpened arrow;[^9-7] it speaks deceit. With his mouth each one speaks peace to his neighbor, but in his heart he sets an ambush for him.

**8** Should I not punish them for these things? declares the LORD. Should I not avenge myself[^9-8] on a nation like this?

**9** For the mountains I will take up weeping and wailing, and a lament for the pastures of the wilderness, because they are laid waste, with no one passing through, and the lowing of cattle is not heard. Both the birds of the sky and the animals have fled; they are gone.

**10** I will make Jerusalem a heap of ruins, a haunt of jackals. I will make the cities of Judah a desolation, with no one living there.

**11** Who is wise enough to understand this? To whom has the mouth of the LORD spoken, so that he can explain it? Why has the land perished and been laid waste like a wilderness, with no one passing through?

**12** The LORD said: Because they have abandoned my instruction,[^9-9] which I set before them, and have not listened to my voice or walked by it,

**13** but have followed the stubbornness of their hearts and gone after the Baals, as their ancestors taught them,

**14** therefore this is what the LORD of Armies, the God of Israel, says: I am going to feed this people with wormwood[^9-10] and give them poisoned water to drink.

**15** I will scatter them among nations that neither they nor their ancestors have known, and I will send the sword after them until I have made an end of them.

**16** This is what the LORD of Armies says: Consider, and call for the mourning women to come; send for the most skilled of them[^9-11] to come.

**17** Let them hurry and raise a lament over us, so that our eyes may run with tears and our eyelids flow with water.

**18** For a sound of wailing is heard from Zion: "How we are ruined! We are utterly put to shame, for we have left the land, because they have torn down our homes."[^9-12]

**19** Now hear the word of the LORD, you women; let your ears receive the word of his mouth. Teach your daughters a lament, and each woman her neighbor a funeral song.

**20** For death has climbed in through our windows; it has entered our fortresses, to cut off the children from the streets and the young men from the squares.

**21** Speak:[^9-13] This is what the LORD declares: Human corpses will fall like dung on the open field, like sheaves behind the reaper, with no one to gather them.

**22** This is what the LORD says: Let not the wise boast of their wisdom, or the strong boast of their strength, or the rich boast of their riches.

**23** But let the one who boasts boast of this: that he understands and knows me, that I am the LORD, who acts with faithful love,[^9-14] justice and righteousness on the earth, for in these I delight, declares the LORD.[^9-15]

**24** Look, the days are coming, declares the LORD, when I will punish all who are circumcised only in the flesh:[^9-16]

**25** Egypt, Judah, Edom, the Ammonites, Moab, and all who clip the hair on their temples[^9-17] and live in the desert. For all the nations are uncircumcised, and the whole house of Israel is uncircumcised in heart.[^9-18]

[^9-1]: Verses 1–25 are 9:2–26 in most English Bibles (see 8:23). Literally "a lodging place of travelers".
[^9-2]: Literally "They bend their tongue, their bow, falsehood".
[^9-3]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^9-4]: A wordplay. Hebrew *aqov ya'qov*, "cheats as a cheat", plays on the name Jacob, *Ya'aqov* (Genesis 27:36).
[^9-5]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. Also in verses 14 and 16.
[^9-6]: Literally "because of the daughter of my people", a tender, poetic name for the nation.
[^9-7]: The Hebrew text is written "a slaughtering arrow" but read "a sharpened arrow".
[^9-8]: Literally "Should my soul not avenge itself".
[^9-9]: Hebrew *torah*, "instruction, law".
[^9-10]: Hebrew *la'anah*, a plant with a very bitter taste.
[^9-11]: Literally "the wise women", the women skilled in singing laments for the dead.
[^9-12]: Or "because our homes have cast us out".
[^9-13]: The Hebrew word *dabber*, "Speak", is unexpected here.
[^9-14]: Hebrew *chesed*: loyal, faithful love.
[^9-15]: Paul draws on this verse in 1 Corinthians 1:31 and 2 Corinthians 10:17.
[^9-16]: Literally "all circumcised in foreskin".
[^9-17]: Literally "all who are cut at the corners", probably desert tribes who cut their hair short at the sides (25:23; 49:32; compare Leviticus 19:27).
[^9-18]: Several of the peoples named practiced circumcision. The point seems to be that the outward rite counts for nothing without a changed heart (4:4).

## Chapter 10

*Status: draft*

**1** Hear the word that the LORD[^10-1] speaks to you, house of Israel.

**2** This is what the LORD says: Do not learn the way of the nations, and do not be terrified by the signs in the heavens, though the nations are terrified by them.

**3** For the customs[^10-2] of the peoples are worthless.[^10-3] A tree is cut from the forest and shaped with a chisel by a craftsman's hands.

**4** They adorn it with silver and gold; they fasten it with nails and hammers so that it will not totter.

**5** Like a scarecrow in a cucumber field,[^10-4] they cannot speak. They have to be carried, because they cannot walk. Do not be afraid of them, for they can do no harm, and they cannot do any good either.[^10-5]

**6** There is no one like you, LORD. You are great, and your name is great in might.

**7** Who would not fear you, King of the nations? It is your due. For among all the wise of the nations and in all their kingdoms there is no one like you.

**8** They are all stupid and foolish alike; the teaching of worthless idols[^10-6] is only wood!

**9** Hammered silver is brought from Tarshish,[^10-7] and gold from Uphaz,[^10-8] the work of a craftsman and of a goldsmith's hands. Their clothing is violet and purple;[^10-9] they are all the work of skilled workers.

**10** But the LORD is the true God; he is the living God and the everlasting King. At his wrath the earth quakes, and the nations cannot endure his fury.

**11** This is what you are to say to them:[^10-10] The gods who did not make the heavens and the earth will perish from the earth and from under these heavens.

**12** He made the earth by his power; he established the world by his wisdom, and by his understanding he stretched out the heavens.[^10-11]

**13** When he thunders,[^10-12] there is a roar of waters in the heavens; he makes the clouds rise from the ends of the earth. He makes lightning for the rain, and brings out the wind from his storehouses.

**14** Every human being is stupid and without knowledge; every goldsmith is put to shame by his idol. For his cast images are a lie; there is no breath[^10-13] in them.

**15** They are worthless, a work of mockery. At the time of their punishment they will perish.

**16** The Portion of Jacob[^10-14] is not like these, for he is the maker of all things, and Israel is the tribe of his inheritance. The LORD of Armies[^10-15] is his name.

**17** Gather up your bundle from the ground,[^10-16] you who live under siege!

**18** For this is what the LORD says: This time I am going to sling out the inhabitants of the land. I will bring distress on them, so that they will feel it.[^10-17]

**19** Woe is me because of my injury! My wound is incurable. But I said, "Surely this is my sickness, and I must bear it."[^10-18]

**20** My tent is destroyed, and all my tent ropes are snapped. My children have gone from me and are no more. There is no one left to pitch my tent again or to set up my tent curtains.

**21** For the shepherds are stupid; they have not sought the LORD. So they have not prospered,[^10-19] and all their flock is scattered.

**22** Listen! A report is coming, a great commotion from the land of the north, to make the cities of Judah a desolation, a haunt of jackals.

**23** I know, LORD, that a human being's way is not in his own control;[^10-20] it is not for anyone who walks to direct his own steps.

**24** Correct me, LORD, but only with justice, not in your anger, or you will reduce me to nothing.

**25** Pour out your wrath on the nations that do not know you, and on the clans that do not call on your name. For they have devoured Jacob; they have devoured him and consumed him, and laid waste his homeland.[^10-21]

[^10-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^10-2]: Hebrew *chuqqot*, "decrees, customs".
[^10-3]: Hebrew *hevel*, "breath, vapor": see 2:5. Also in verses 8 and 15.
[^10-4]: Hebrew *tomer miqshah*, perhaps "a palm post in a cucumber field". Compare the Letter of Jeremiah, verse 70 (Baruch 6:70), which uses the same picture.
[^10-5]: The Septuagint does not have verses 6–8 and 10, and it places verse 9 within verse 5. A Hebrew manuscript of Jeremiah from Qumran (4QJer-b) has the same shorter text.
[^10-6]: Literally "the instruction of vapors".
[^10-7]: A distant land rich in metals, probably in the far west of the Mediterranean.
[^10-8]: An unknown place, perhaps Ophir, the land of gold (1 Kings 9:28).
[^10-9]: Hebrew *tekhelet* and *argaman*, costly dyed wool, violet-blue and red-purple.
[^10-10]: This verse is in Aramaic, the international language of the time, not in Hebrew; Hebrew resumes in verse 12. It is the only Aramaic in Jeremiah. It contains a wordplay: the gods who did not *avadu*, "make", the heavens will *ye'vadu*, "perish".
[^10-11]: Verses 12–16 are repeated in 51:15–19.
[^10-12]: Literally "At the sound of his giving".
[^10-13]: Hebrew *ruach*, "breath, spirit".
[^10-14]: A title of God (51:19; Psalm 16:5): the one who belongs to Jacob as his share, as the land belongs to the other tribes.
[^10-15]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel.
[^10-16]: Or "from the land". The meaning of the Hebrew word *kin'ah*, "bundle", is uncertain. Jerusalem, pictured as a woman, is told to get ready for exile.
[^10-17]: The Hebrew is difficult. Literally "so that they may find".
[^10-18]: Jerusalem, pictured as a mother, speaks in verses 19–20.
[^10-19]: Or "they have not acted wisely". The Hebrew verb can mean either.
[^10-20]: Literally "is not to him", that is, it does not belong to him to decide.
[^10-21]: Verse 25 is nearly the same as Psalm 79:6–7.

## Chapter 11

*Status: draft*

**1** The word that came to Jeremiah from the LORD:[^11-1]

**2** Hear the words of this covenant, and speak them to the people of Judah and the inhabitants of Jerusalem.[^11-2]

**3** Say to them: This is what the LORD, the God of Israel, says: Cursed is anyone who does not listen to the words of this covenant,

**4** which I commanded your ancestors when I brought them out of the land of Egypt, out of the iron-smelting furnace: "Listen to my voice and do them, everything I command you. Then you will be my people, and I will be your God,"

**5** so that I may keep the oath I swore to your ancestors, to give them a land flowing with milk and honey, as it is today. I answered, "Amen,[^11-3] LORD."

**6** The LORD said to me: Proclaim all these words in the cities of Judah and in the streets of Jerusalem: Hear the words of this covenant and do them.

**7** For I solemnly warned your ancestors when I brought them up from the land of Egypt, and I have warned them again and again[^11-4] until this day, saying, "Listen to my voice."

**8** But they did not listen or pay attention; each of them followed the stubbornness of his evil heart. So I brought on them all the words of this covenant, which I had commanded them to do, but they did not do them.[^11-5]

**9** The LORD said to me: A conspiracy has been found among the people of Judah and the inhabitants of Jerusalem.

**10** They have gone back to the wrongdoings of their ancestors of old, who refused to listen to my words. They too have followed other gods to serve them. The house of Israel and the house of Judah have broken my covenant that I made with their ancestors.

**11** Therefore this is what the LORD says: I am going to bring on them a disaster they cannot escape. They will cry out to me, but I will not listen to them.

**12** Then the cities of Judah and the inhabitants of Jerusalem will go and cry out to the gods they burn incense to,[^11-6] but these will not save them at all in the time of their trouble.

**13** For you have as many gods as you have cities, Judah, and as many altars as Jerusalem has streets you have set up to the Shameful Thing,[^11-7] altars to burn incense to Baal.

**14** As for you, do not pray for this people, or raise a cry or a prayer for them, for I will not listen when they call to me because of their trouble.

**15** What right does my beloved have in my house, when she has carried out so many evil schemes? Can sacred meat take away your disaster from you? Then you could rejoice.[^11-8]

**16** The LORD once named you "A leafy olive tree, beautiful with well-formed fruit." But with the roar of a great storm he will set fire to it, and its branches will be broken.[^11-9]

**17** The LORD of Armies,[^11-10] who planted you, has pronounced disaster against you, because of the evil that the house of Israel and the house of Judah have done, provoking me to anger by burning incense to Baal.

**18** The LORD made it known to me, and I knew it.[^11-11] Then you showed me what they were doing.

**19** But I was like a trusting lamb led to the slaughter. I did not know it was against me they had made their plans: "Let us destroy the tree with its fruit;[^11-12] let us cut him off from the land of the living, so that his name will be remembered no more."

**20** But the LORD of Armies, who judges righteously, who tests the heart and mind,[^11-13] let me see your vengeance on them, for to you I have committed my cause.

**21** Therefore this is what the LORD says about the people of Anathoth, who seek your life and say, "Do not prophesy in the name of the LORD, or you will die by our hand":

**22** therefore this is what the LORD of Armies says: I am going to punish them. The young men will die by the sword; their sons and their daughters will die by famine.

**23** Not even a remnant will be left to them, for I will bring disaster on the people of Anathoth, the year of their punishment.

[^11-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^11-2]: The commands in this verse are plural.
[^11-3]: Hebrew *amen*, "So be it", the people's answer to the curses of the covenant in Deuteronomy 27:15–26.
[^11-4]: Literally "rising early and warning".
[^11-5]: The Septuagint does not have verse 7 and most of verse 8. It reads only "but they did not do them".
[^11-6]: Or "burn offerings to". The Hebrew verb *qatar* means to make something go up in smoke. Also in verses 13 and 17.
[^11-7]: Hebrew *ha-boshet*, "the shame", a scornful name for Baal.
[^11-8]: The Hebrew of this verse is very difficult, and the Septuagint differs from it. The translation is uncertain.
[^11-9]: Or "will be ruined".
[^11-10]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. Also in verses 20 and 22.
[^11-11]: Here begins the first of Jeremiah's personal laments, often called his "confessions" (11:18–12:6; 15:10–21; 17:14–18; 18:18–23; 20:7–18). Jeremiah speaks to the LORD about the plot against him by the people of his own town, Anathoth (verse 21).
[^11-12]: Literally "with its bread".
[^11-13]: Literally "the kidneys and the heart". In Hebrew thought the kidneys were the seat of the emotions and the heart of thought and will.

## Chapter 12

*Status: draft*

**1** You are always in the right, LORD,[^12-1] when I bring a case against you.[^12-2] Yet I would speak with you about justice: Why does the way of the wicked prosper? Why do all the treacherous live at ease?

**2** You planted them, and they have taken root; they grow and bear fruit. You are near in their mouths but far from their hearts.[^12-3]

**3** But you, LORD, know me; you see me and test my heart toward you. Drag them off like sheep to be slaughtered; set them apart for the day of killing.

**4** How long will the land mourn and the grass of every field wither? Because of the wickedness of those who live in it, the animals and the birds are swept away. For they have said, "He will not see what becomes of us."

**5** If you have raced with men on foot and they have worn you out, how will you compete with horses?[^12-4] If you feel secure only in a peaceful land, how will you manage in the thickets of the Jordan?[^12-5]

**6** For even your brothers and your own family,[^12-6] even they have betrayed you; even they are shouting loudly after you. Do not trust them, even when they speak kindly to you.

**7** I have abandoned my house; I have deserted my inheritance.[^12-7] I have given the one I dearly love[^12-8] into the hands of her enemies.

**8** My inheritance has become to me like a lion in the forest. She has roared at me; therefore I hate her.

**9** Has my inheritance become to me like a speckled bird of prey, with birds of prey all around her? Go, gather all the wild animals; bring them to devour.

**10** Many shepherds have ruined my vineyard; they have trampled down my portion. They have turned my pleasant portion into a desolate wilderness.

**11** They have made it a desolation; desolate, it mourns before me. The whole land has been made desolate, but no one takes it to heart.

**12** Over all the bare heights in the wilderness destroyers have come, for the sword of the LORD devours from one end of the land to the other. No living thing[^12-9] has peace.

**13** They have sown wheat but reaped thorns; they have worn themselves out but gained nothing. Be ashamed of your harvests,[^12-10] because of the fierce anger of the LORD.

**14** This is what the LORD says about all my evil neighbors who strike at the inheritance I gave my people Israel: I am going to uproot them from their land, and I will uproot the house of Judah from among them.

**15** But after I have uprooted them, I will again have compassion on them, and I will bring them back, each one to his inheritance and each one to his land.

**16** And if they diligently learn the ways of my people, to swear by my name, "As surely as the LORD lives," just as they taught my people to swear by Baal, then they will be built up among my people.

**17** But if any nation will not listen, I will completely uproot that nation and destroy it, declares the LORD.

[^12-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^12-2]: Hebrew *riv*, to bring a case against someone, as in a court of law. Jeremiah's lament, which began in 11:18, continues to verse 4.
[^12-3]: Literally "far from their kidneys", thought of as the seat of the emotions.
[^12-4]: The LORD answers Jeremiah in verses 5–6: worse is still to come.
[^12-5]: Literally "in the pride of the Jordan", the dense thickets along the river, where lions lived (49:19).
[^12-6]: Literally "your father's house".
[^12-7]: The LORD speaks in verses 7–13. His *inheritance* is his land and his people.
[^12-8]: Literally "the beloved of my soul".
[^12-9]: Literally "No flesh".
[^12-10]: Or "They will be ashamed of their harvests". The Hebrew moves from "they" to "your".

## Chapter 13

*Status: draft*

**1** This is what the LORD[^13-1] said to me: "Go and buy yourself a linen loincloth[^13-2] and put it around your waist, but do not put it in water."

**2** So I bought a loincloth, as the LORD had told me, and put it around my waist.

**3** The word of the LORD came to me a second time:

**4** "Take the loincloth you bought, the one around your waist, and set out for Perath.[^13-3] Hide it there in a crevice in the rock."

**5** So I went and hid it at Perath, as the LORD had commanded me.

**6** After many days the LORD said to me, "Set out for Perath, and take from there the loincloth I commanded you to hide there."

**7** So I went to Perath and dug, and I took the loincloth from the place where I had hidden it. And look, the loincloth was ruined; it was good for nothing.

**8** Then the word of the LORD came to me:

**9** "This is what the LORD says: In the same way I will ruin the pride of Judah and the great pride of Jerusalem.

**10** This evil people, who refuse to listen to my words, who follow the stubbornness of their hearts and have gone after other gods to serve them and worship them, will be like this loincloth, which is good for nothing.

**11** For as a loincloth clings to a man's waist, so I made the whole house of Israel and the whole house of Judah cling to me, declares the LORD, to be my people, for my renown, my praise and my glory. But they did not listen."

**12** Say this word to them: This is what the LORD, the God of Israel, says: Every jar should be filled with wine.[^13-4] And when they say to you, "Don't we know very well that every jar should be filled with wine?"

**13** then say to them: This is what the LORD says: I am going to fill all the inhabitants of this land with drunkenness: the kings who sit on David's throne, the priests, the prophets and all the inhabitants of Jerusalem.

**14** I will smash them one against another, fathers and sons together, declares the LORD. I will not show pity or spare them or have compassion; nothing will keep me from destroying them.

**15** Hear and pay attention; do not be proud, for the LORD has spoken.

**16** Give glory to the LORD your God before he brings darkness, before your feet stumble on the mountains at dusk. You will look for light, but he will turn it into deep darkness[^13-5] and make it thick gloom.

**17** But if you will not listen, I will weep in secret[^13-6] because of your pride. My eyes will weep bitterly and run with tears, because the flock of the LORD has been taken captive.

**18** Say to the king and to the queen mother,[^13-7] "Take a lowly seat, for your glorious crowns have come down from your heads."

**19** The cities of the Negev[^13-8] are shut up, and there is no one to open them. All Judah has been carried into exile, carried into exile completely.

**20** Lift up your eyes and see those coming from the north. Where is the flock that was given to you, your beautiful flock?

**21** What will you say when he sets over you as rulers those you yourself trained to be your friends?[^13-9] Will not pains seize you like a woman in labor?

**22** And if you say in your heart, "Why have these things happened to me?" it is because of your many sins that your skirts have been stripped off and your body violated.[^13-10]

**23** Can a Cushite[^13-11] change his skin, or a leopard its spots? Then you also can do good, you who are trained to do evil.

**24** I will scatter them like chaff blown away by the desert wind.

**25** This is your lot, the portion I have measured out to you, declares the LORD, because you have forgotten me and trusted in the Lie.[^13-12]

**26** I myself will pull your skirts up over your face, and your shame will be seen.

**27** Your adulteries and your lustful neighing, your shameless prostitution on the hills in the countryside: I have seen your detestable acts. Woe to you, Jerusalem! You will not be made clean. How long will it still be?[^13-13]

[^13-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^13-2]: Hebrew *ezor*, a cloth wrapped around the waist and hips, worn next to the skin.
[^13-3]: Hebrew *Perat*, the usual name of the Euphrates River, about 350 miles (560 km) away. Some think instead of Parah, a village near Anathoth (Joshua 18:23), whose name is similar. Also in verses 5–7.
[^13-4]: Apparently a common saying. Hebrew *nevel*, "jar", is a large clay jar for storing wine.
[^13-5]: Hebrew *tsalmavet*, "deep darkness", traditionally read as "the shadow of death".
[^13-6]: Literally "my soul will weep in secret places".
[^13-7]: Hebrew *gevirah*, "great lady", the king's mother, who held a position of honor at court. These are probably Jehoiachin and his mother Nehushta, taken into exile in 597 BC (2 Kings 24:8–15; Jeremiah 22:26).
[^13-8]: The dry region in the south of Judah.
[^13-9]: Hebrew *allufim*, "close friends" or "chiefs". The meaning of the verse is uncertain.
[^13-10]: Literally "your heels have suffered violence", a polite way of speaking of sexual violence.
[^13-11]: A person from Cush, the land on the upper Nile, south of Egypt.
[^13-12]: Hebrew *sheqer*, "falsehood", here probably the false gods.
[^13-13]: Literally "after when yet?"

## Chapter 14

*Status: draft*

**1** The word of the LORD[^14-1] that came to Jeremiah about the drought:

**2** Judah mourns, and her gates languish; her people sit in black on the ground,[^14-2] and the cry of Jerusalem goes up.

**3** Their nobles send their servants for water. They come to the cisterns but find no water; they return with their jars empty. They are ashamed and dismayed, and they cover their heads.

**4** Because the ground is cracked, for there has been no rain in the land, the farmers are ashamed; they cover their heads.

**5** Even the doe in the field gives birth and abandons her fawn, because there is no grass.

**6** Wild donkeys stand on the bare heights and pant for air like jackals; their eyes fail because there is no vegetation.

**7** Though our wrongdoings testify against us, LORD, act for the sake of your name.[^14-3] For our acts of faithlessness are many; we have sinned against you.

**8** Hope of Israel, its Savior in time of trouble, why are you like a stranger in the land, like a traveler who stops only for a night?

**9** Why are you like a man taken by surprise, like a warrior who cannot save? Yet you are among us, LORD, and we bear your name.[^14-4] Do not abandon us!

**10** This is what the LORD says about this people: How they love to wander! They do not restrain their feet. So the LORD does not accept them; now he will remember their wrongdoing and punish their sins.[^14-5]

**11** The LORD said to me: Do not pray for the good of this people.

**12** Though they fast, I will not listen to their cry; though they offer burnt offerings and grain offerings, I will not accept them. Instead I will make an end of them by sword, famine and plague.

**13** Then I said, "Ah, Lord GOD![^14-6] Look, the prophets keep telling them, 'You will not see the sword, and you will not have famine. I will give you lasting peace[^14-7] in this place.'"

**14** The LORD said to me: The prophets are prophesying lies in my name. I did not send them or command them or speak to them. They are prophesying to you false visions, divination, worthless things and the delusions of their own minds.[^14-8]

**15** Therefore this is what the LORD says about the prophets who prophesy in my name, though I did not send them, and who say, "Sword and famine will not come on this land": By sword and famine those prophets will meet their end.

**16** And the people they are prophesying to will be thrown out into the streets of Jerusalem because of famine and sword, with no one to bury them, them, their wives, their sons and their daughters. I will pour out on them their own wickedness.

**17** Say this word to them: Let my eyes run with tears night and day, and let them not stop, for the virgin daughter of my people[^14-9] has been struck a crushing blow, a very grievous wound.

**18** If I go out into the field, look, those killed by the sword! If I enter the city, look, those sick with famine! For both prophet and priest wander through a land they do not know.[^14-10]

**19** Have you utterly rejected Judah? Do you loathe Zion?[^14-11] Why have you struck us so that there is no healing for us? We hoped for peace, but no good has come; for a time of healing, but there is only terror.

**20** We acknowledge our wickedness, LORD, the wrongdoing of our ancestors, for we have sinned against you.

**21** For the sake of your name, do not spurn us; do not dishonor your glorious throne.[^14-12] Remember your covenant with us, and do not break it.

**22** Can any of the worthless idols[^14-13] of the nations bring rain? Can the heavens give showers by themselves? Is it not you, LORD our God? So we hope in you, for you are the one who does all these things.

[^14-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^14-2]: Literally "they are dark to the ground", that is, dressed in mourning and sitting on the ground.
[^14-3]: Verses 7–9 are a prayer of lament, in the voice of the people or of the prophet praying for them. Another follows in verses 19–22.
[^14-4]: Literally "your name is called over us", that is, we belong to you.
[^14-5]: The second half of this verse is nearly the same as Hosea 8:13.
[^14-6]: Hebrew *Adonai YHWH*, "my Lord YHWH". After "Lord", God's personal name is written GOD in capitals, as in most English Bibles.
[^14-7]: Literally "peace of truth".
[^14-8]: Literally "the deceit of their heart".
[^14-9]: A tender, poetic name for the nation, pictured as a young woman.
[^14-10]: Or "go about their business in the land, and have no knowledge". The meaning of the Hebrew is uncertain.
[^14-11]: Literally "Does your soul loathe Zion?"
[^14-12]: That is, Jerusalem and its temple, where the LORD was enthroned (3:17).
[^14-13]: Literally "the vapors": see 2:5.

## Chapter 15

*Status: draft*

**1** Then the LORD[^15-1] said to me: Even if Moses and Samuel stood before me,[^15-2] my heart would not turn toward this people.[^15-3] Send them away from my presence, and let them go!

**2** And if they ask you, "Where shall we go?" tell them: This is what the LORD says: Those destined for death, to death; those destined for the sword, to the sword; those destined for famine, to famine; and those destined for captivity, to captivity.

**3** I will appoint over them four kinds of destroyers,[^15-4] declares the LORD: the sword to kill, the dogs to drag away, and the birds of the sky and the animals of the earth to devour and destroy.

**4** I will make them a horror to all the kingdoms of the earth, because of what Manasseh son of Hezekiah king of Judah did in Jerusalem.[^15-5]

**5** Who will have pity on you, Jerusalem? Who will grieve for you? Who will turn aside to ask how you are?

**6** You have rejected me, declares the LORD; you keep going backward. So I have stretched out my hand against you and destroyed you; I am tired of relenting.

**7** I have winnowed them with a winnowing fork in the gates of the land. I have bereaved them, I have destroyed my people, for they did not turn back from their ways.

**8** Their widows have become more numerous before me than the sand of the seas. At noon I have brought a destroyer against the mothers of young men;[^15-6] I have suddenly brought down on them anguish and terror.

**9** The mother of seven grows faint; she breathes out her life. Her sun has set while it is still day; she is shamed and humiliated. And the rest of them I will give to the sword before their enemies, declares the LORD.

**10** Woe is me, my mother, that you gave birth to me, a man of strife and contention to the whole land![^15-7] I have not lent, and no one has lent to me, yet all of them curse me.

**11** The LORD said: Surely I will set you free for good.[^15-8] Surely I will make the enemy plead with you in the time of disaster and the time of distress.

**12** Can anyone break iron, iron from the north, and bronze?

**13** Your wealth and your treasures I will give away as plunder, without price, because of all your sins throughout all your territory.[^15-9]

**14** I will make you go with your enemies[^15-10] into a land you do not know, for a fire has been kindled by my anger; it will burn against you.

**15** You know, LORD. Remember me and take care of me, and take vengeance for me on my persecutors. Do not let your patience with them sweep me away.[^15-11] Know that for your sake I bear insult.

**16** When your words were found, I ate them, and your word[^15-12] became a joy to me and the delight of my heart, for I bear your name,[^15-13] LORD, God of Armies.[^15-14]

**17** I did not sit in the company of those who make merry, or celebrate with them. Because your hand was on me I sat alone, for you had filled me with indignation.

**18** Why is my pain unending, and my wound incurable, refusing to be healed? Will you truly be to me like a deceptive brook, like waters that cannot be relied on?[^15-15]

**19** Therefore this is what the LORD says: If you turn back, I will bring you back,[^15-16] and you will stand before me. If you bring out what is precious and not what is worthless, you will be my mouth. Let them turn to you, but you must not turn to them.

**20** I will make you to this people a fortified wall of bronze. They will fight against you, but they will not overcome you, for I am with you to save you and rescue you, declares the LORD.

**21** I will rescue you from the hand of the wicked and redeem you from the grasp of the ruthless.

[^15-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^15-2]: Moses and Samuel were remembered for praying for the people (Exodus 32:11–14; Numbers 14:13–20; 1 Samuel 7:5–9; 12:19–23; Psalm 99:6).
[^15-3]: Literally "my soul would not be toward this people".
[^15-4]: Literally "four families".
[^15-5]: See 2 Kings 21:1–16; 23:26; 24:3–4.
[^15-6]: Literally "against the mother, the young man". The meaning is uncertain.
[^15-7]: Here begins another of Jeremiah's personal laments (15:10–21; see 11:18).
[^15-8]: The Hebrew of this verse is difficult, and the written and read forms of the verb differ slightly. It may mean "I will strengthen you for good".
[^15-9]: Verses 13–14 are repeated, with small differences, in 17:3–4.
[^15-10]: Literally "I will make pass your enemies". Some Hebrew manuscripts read "I will make you serve your enemies", as in 17:4.
[^15-11]: Literally "Do not, in the length of your anger, take me away", that is, do not wait so long to act against them that I am lost.
[^15-12]: The Hebrew text is written "your words" but read "your word".
[^15-13]: Literally "your name is called over me", that is, I belong to you.
[^15-14]: Hebrew *YHWH Elohei tseva'ot*, traditionally "the LORD God of hosts". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel.
[^15-15]: Hebrew *akhzav*, a stream that runs dry in the summer, failing the traveler who counts on it. Compare 2:13.
[^15-16]: A wordplay on *shuv*, "turn, return" (see 3:12): Jeremiah too must turn back to the LORD.

## Chapter 16

*Status: draft*

**1** The word of the LORD[^16-1] came to me:

**2** You must not take a wife, or have sons or daughters in this place.

**3** For this is what the LORD says about the sons and daughters born in this place, and about the mothers who bear them and the fathers who father them in this land:

**4** They will die of deadly diseases. They will not be mourned or buried; they will be like dung on the surface of the ground. They will perish by sword and famine, and their corpses will be food for the birds of the sky and the animals of the earth.

**5** For this is what the LORD says: Do not enter a house where there is a funeral feast,[^16-2] and do not go to mourn or to grieve for them, for I have withdrawn my peace from this people, declares the LORD, my faithful love[^16-3] and my compassion.

**6** Both great and small will die in this land. They will not be buried, and no one will mourn for them; no one will gash himself or shave his head for them.[^16-4]

**7** No one will break bread for the mourner, to comfort him for the dead, and no one will give them a cup of consolation to drink for a father or a mother.

**8** Do not enter a house where there is feasting, to sit with them and eat and drink.

**9** For this is what the LORD of Armies,[^16-5] the God of Israel, says: I am going to put an end in this place, before your eyes and in your days, to the sound of joy and the sound of gladness, the voice of the bridegroom and the voice of the bride.

**10** When you tell this people all these things, and they ask you, "Why has the LORD pronounced all this great disaster against us? What is our wrongdoing? What is the sin we have committed against the LORD our God?"

**11** then say to them: It is because your ancestors abandoned me, declares the LORD, and followed other gods and served them and worshiped them. They abandoned me and did not keep my law.

**12** And you have done worse than your ancestors. Look, each of you is following the stubbornness of his evil heart instead of listening to me.

**13** So I will hurl you out of this land into a land that neither you nor your ancestors have known, and there you will serve other gods day and night, for I will show you no favor.

**14** Therefore, look, the days are coming, declares the LORD, when people will no longer say, "As surely as the LORD lives, who brought the Israelites up out of the land of Egypt,"

**15** but, "As surely as the LORD lives, who brought the Israelites up out of the land of the north and out of all the lands where he had driven them." For I will bring them back to their land, which I gave to their ancestors.[^16-6]

**16** I am going to send for many fishermen, declares the LORD, and they will catch them. After that I will send for many hunters, and they will hunt them down on every mountain and every hill, and in the crevices of the rocks.

**17** For my eyes are on all their ways. They are not hidden from me, and their wrongdoing is not concealed from my eyes.

**18** First I will repay them double for their wrongdoing and their sin, because they have defiled my land with the corpses of their detestable idols,[^16-7] and filled my inheritance with their detestable things.

**19** LORD, my strength and my stronghold, my refuge in the day of trouble, to you the nations will come from the ends of the earth and say, "Our ancestors inherited nothing but lies, worthless things[^16-8] that did them no good.

**20** Can human beings make gods for themselves? Such things are not gods!"

**21** Therefore, look, I will teach them. This time I will make them know my power and my might, and they will know that my name is the LORD.

[^16-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^16-2]: Hebrew *beit marzeach*, a house where a ritual feast was held, here a feast for mourners (compare Amos 6:7).
[^16-3]: Hebrew *chesed*: loyal, faithful love.
[^16-4]: Mourning rites forbidden in the law (Leviticus 19:28; Deuteronomy 14:1), but evidently still practiced (41:5; 47:5).
[^16-5]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel.
[^16-6]: Verses 14–15 are repeated, with small differences, in 23:7–8.
[^16-7]: Lifeless idols are scornfully called corpses (compare Leviticus 26:30).
[^16-8]: Hebrew *hevel*, "breath, vapor": see 2:5.

## Chapter 17

*Status: draft*

**1** The sin of Judah is written with an iron pen; with a diamond point[^17-1] it is engraved on the tablet of their hearts and on the horns of their altars.[^17-2]

**2** Their children remember their altars and their Asherah poles[^17-3] beside the leafy trees, on the high hills,

**3** my mountain in the open country.[^17-4] Your wealth and all your treasures I will give away as plunder, along with your high places,[^17-5] because of sin throughout all your territory.

**4** Through your own fault you will lose your hold on the inheritance I gave you.[^17-6] I will make you serve your enemies in a land you do not know, for you have kindled a fire in my anger that will burn forever.

**5** This is what the LORD[^17-7] says: Cursed is the one who trusts in human beings, who makes mere flesh his strength,[^17-8] and whose heart turns away from the LORD.

**6** He will be like a shrub in the desert;[^17-9] he will not see when good comes. He will live in the parched places of the wilderness, in a salt land where no one lives.

**7** Blessed is the one who trusts in the LORD, whose trust is the LORD.

**8** He will be like a tree planted by water, that sends out its roots by a stream. It does not see when heat comes;[^17-10] its leaves stay green. In a year of drought it is not anxious, and it does not stop bearing fruit.[^17-11]

**9** The heart is more deceitful than anything,[^17-12] and desperately sick. Who can understand it?

**10** I, the LORD, search the heart and test the mind,[^17-13] to give each one according to his ways,[^17-14] according to the fruit of his deeds.

**11** Like a partridge that hatches eggs it did not lay[^17-15] is the one who gains riches unjustly. In the middle of his life his riches will leave him, and at his end he will be a fool.

**12** A glorious throne, exalted from the beginning, is the place of our sanctuary.

**13** LORD, the hope of Israel, all who abandon you will be put to shame. Those who turn away from me[^17-16] will be written in the dust, for they have abandoned the LORD, the spring of living water.

**14** Heal me, LORD, and I will be healed; save me, and I will be saved, for you are my praise.[^17-17]

**15** Look, they keep saying to me, "Where is the word of the LORD? Let it come now!"

**16** But I have not run away from being a shepherd who follows you,[^17-18] nor have I longed for the day of disaster. You know what came from my lips; it was before you.

**17** Do not become a terror to me; you are my refuge in the day of disaster.

**18** Let my persecutors be put to shame, but do not let me be put to shame. Let them be terrified, but do not let me be terrified. Bring on them the day of disaster; shatter them with double destruction.

**19** This is what the LORD said to me: Go and stand in the People's Gate,[^17-19] through which the kings of Judah come in and go out, and in all the gates of Jerusalem.

**20** Say to them: Hear the word of the LORD, you kings of Judah, all Judah and all the inhabitants of Jerusalem who come in through these gates.

**21** This is what the LORD says: For your lives' sake, be careful not to carry a load on the Sabbath day or bring it in through the gates of Jerusalem.

**22** Do not carry a load out of your houses on the Sabbath day or do any work, but keep the Sabbath day holy, as I commanded your ancestors.[^17-20]

**23** Yet they did not listen or pay attention. They stiffened their necks so as not to listen or accept discipline.

**24** But if you listen carefully to me, declares the LORD, and bring no load in through the gates of this city on the Sabbath day, but keep the Sabbath day holy and do no work on it,

**25** then kings and officials who sit on David's throne will come in through the gates of this city, riding in chariots and on horses, they and their officials, the people of Judah and the inhabitants of Jerusalem. And this city will be inhabited forever.

**26** People will come from the cities of Judah and the area around Jerusalem, from the land of Benjamin, from the Shephelah,[^17-21] from the hill country and from the Negev, bringing burnt offerings and sacrifices, grain offerings and frankincense, and bringing thanksgiving sacrifices[^17-22] to the house of the LORD.

**27** But if you do not listen to me, to keep the Sabbath day holy and not carry a load as you come in through the gates of Jerusalem on the Sabbath day, then I will kindle a fire in its gates that will consume the fortresses of Jerusalem, and it will not be put out.

[^17-1]: Hebrew *shamir*, a very hard stone, perhaps emery or diamond, used for engraving.
[^17-2]: The Septuagint does not have verses 1–4.
[^17-3]: Hebrew *asherim*: wooden poles or trees that were symbols of the goddess Asherah.
[^17-4]: Literally "my mountain in the field", perhaps Jerusalem, or one of the hills of verse 2. The meaning is uncertain. Verses 3–4 repeat 15:13–14 with small differences.
[^17-5]: Hebrew *bamot*: places of worship, often on hilltops.
[^17-6]: The Hebrew is difficult. Literally "And you will let drop, and in you, from your inheritance that I gave you". The verb *shamat* is used of the release of debts and of land left unsown in the seventh year (Exodus 23:11; Deuteronomy 15:1–3).
[^17-7]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^17-8]: Literally "who makes flesh his arm".
[^17-9]: Hebrew *ar'ar*, perhaps a juniper, in the Arabah, the dry rift valley of the Jordan and the Dead Sea.
[^17-10]: The Hebrew text is written "It does not fear when heat comes" but read "It does not see when heat comes".
[^17-11]: Compare Psalm 1:3.
[^17-12]: Hebrew *aqov*, "crooked, deceitful", the word that plays on the name Jacob in 9:3 (9:4 in most English Bibles).
[^17-13]: Literally "the kidneys", thought of as the seat of the emotions.
[^17-14]: The Hebrew text is written "his way" but read "his ways".
[^17-15]: The partridge was thought to sit on eggs it had not laid, and to lose the young when they hatched.
[^17-16]: The Hebrew changes from "you" to "me", as if the LORD were speaking.
[^17-17]: Here begins another of Jeremiah's personal laments (17:14–18; see 11:18).
[^17-18]: The meaning of the Hebrew is uncertain.
[^17-19]: Literally "the gate of the sons of the people", a gate of Jerusalem not mentioned elsewhere.
[^17-20]: Exodus 20:8–10; Deuteronomy 5:12–14.
[^17-21]: The low hills between the coastal plain and the hill country of Judah.
[^17-22]: Hebrew *todah*, "thanksgiving, praise" (Leviticus 7:12).

## Chapter 18

*Status: draft*

**1** The word that came to Jeremiah from the LORD:[^18-1]

**2** "Get up and go down to the potter's house, and there I will let you hear my words."

**3** So I went down to the potter's house, and there he was, working at the wheel.[^18-2]

**4** Whenever the vessel he was making from the clay was spoiled in the potter's hand, he would make it again into another vessel, as seemed right to the potter.

**5** Then the word of the LORD came to me:

**6** "House of Israel, can I not do with you as this potter does? declares the LORD. Look, like the clay in the potter's hand, so are you in my hand, house of Israel.

**7** At one moment I may speak about a nation or a kingdom, to uproot it, tear it down and destroy it.

**8** But if that nation I have spoken against turns from its evil, I will relent of the disaster I intended to bring on it.

**9** At another moment I may speak about a nation or a kingdom, to build it and to plant it.

**10** But if it does evil in my eyes and does not listen to my voice, I will relent of the good I had said I would do for it.

**11** So now, say to the people of Judah and the inhabitants of Jerusalem: 'This is what the LORD says: Look, I am shaping[^18-3] disaster against you and devising a plan against you. Turn back, each of you, from his evil way, and make your ways and your deeds good.'

**12** But they will say, 'It's hopeless! We will follow our own plans; each of us will act according to the stubbornness of his evil heart.'"

**13** Therefore this is what the LORD says: Ask among the nations: Who has ever heard anything like this? The virgin Israel has done a most horrible thing.

**14** Does the snow of Lebanon ever vanish from the rocks of the field? Do the cold waters flowing from afar ever run dry?[^18-4]

**15** Yet my people have forgotten me; they burn incense[^18-5] to what is worthless. They have stumbled in their ways, the ancient paths, to walk in bypaths, on a road not built up.

**16** Their land will become a horror, a thing to hiss at[^18-6] forever. All who pass by it will be appalled and shake their heads.

**17** Like the east wind I will scatter them before the enemy. I will show them my back and not my face in the day of their disaster.

**18** Then they said, "Come, let us make plans against Jeremiah, for instruction[^18-7] will not be lost from the priest, nor counsel from the wise, nor the word from the prophet. Come, let us strike at him with our tongues,[^18-8] and pay no attention to anything he says."

**19** Pay attention to me, LORD,[^18-9] and hear what my accusers are saying.

**20** Should good be repaid with evil? Yet they have dug a pit for me. Remember how I stood before you to speak good on their behalf, to turn your wrath away from them.

**21** So hand their children over to famine, and give them over to the power of the sword.[^18-10] Let their wives be made childless and widowed; let their men be killed by plague,[^18-11] their young men struck down by the sword in battle.

**22** Let a cry be heard from their houses when you suddenly bring raiders against them, for they have dug a pit to capture me and hidden snares for my feet.

**23** But you, LORD, know all their plotting to kill me. Do not forgive their wrongdoing, or blot out their sin from your sight. Let them be overthrown before you; deal with them in the time of your anger.

[^18-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^18-2]: Literally "on the two stones", the potter's wheel, with an upper disc on which the clay was shaped and a lower one turned by the feet.
[^18-3]: Hebrew *yotser*, the word for "potter" in verses 2–6.
[^18-4]: The Hebrew of this verse is difficult. Literally "Does it leave the rock of the field, the snow of Lebanon? Are they plucked up, the strange, cold, flowing waters?" Nature keeps its course, but Israel has abandoned the LORD.
[^18-5]: Or "burn offerings". The Hebrew verb *qatar* means to make something go up in smoke.
[^18-6]: A gesture of horror and scorn.
[^18-7]: Hebrew *torah*, "instruction, law", which the priests taught (Deuteronomy 33:10; Malachi 2:7).
[^18-8]: Literally "strike him with the tongue", that is, bring charges against him.
[^18-9]: Here begins another of Jeremiah's personal laments (18:19–23; see 11:18).
[^18-10]: Literally "pour them out on the hands of the sword".
[^18-11]: Literally "slain of death". Hebrew *mavet*, "death", can mean a deadly disease (15:2).

## Chapter 19

*Status: draft*

**1** This is what the LORD[^19-1] says: Go and buy a potter's clay jar.[^19-2] Take with you[^19-3] some of the elders of the people and some of the senior priests,

**2** and go out to the Valley of Ben-hinnom,[^19-4] at the entrance of the Potsherd Gate.[^19-5] There proclaim the words I tell you.

**3** Say: Hear the word of the LORD, you kings of Judah and inhabitants of Jerusalem. This is what the LORD of Armies,[^19-6] the God of Israel, says: I am going to bring such a disaster on this place that the ears of everyone who hears of it will tingle.

**4** For they have abandoned me and made this place a foreign place, burning incense[^19-7] in it to other gods that neither they nor their ancestors nor the kings of Judah ever knew, and they have filled this place with the blood of the innocent.

**5** They have built the high places[^19-8] of Baal to burn their sons in the fire as burnt offerings to Baal, something I did not command or speak of, nor did it ever enter my mind.

**6** Therefore, look, the days are coming, declares the LORD, when this place will no longer be called Topheth[^19-9] or the Valley of Ben-hinnom, but the Valley of Slaughter.

**7** In this place I will empty out[^19-10] the plans of Judah and Jerusalem. I will make them fall by the sword before their enemies, by the hand of those who seek their lives, and I will give their corpses as food to the birds of the sky and the animals of the earth.

**8** I will make this city a horror and a thing to hiss at; everyone who passes by it will be appalled and hiss at all its wounds.

**9** I will make them eat the flesh of their sons and the flesh of their daughters, and they will eat one another's flesh, in the siege and the distress with which their enemies and those who seek their lives will press them hard.[^19-11]

**10** Then break the jar in the sight of the men who go with you,

**11** and say to them: This is what the LORD of Armies says: So I will break this people and this city, as one breaks a potter's vessel so that it can never be mended. They will bury the dead in Topheth until there is no room left to bury.

**12** This is what I will do to this place and to its inhabitants, declares the LORD: I will make this city like Topheth.

**13** The houses of Jerusalem and the houses of the kings of Judah will be defiled like the place of Topheth, all the houses on whose roofs they burned incense to all the host of heaven[^19-12] and poured out drink offerings to other gods.

**14** Then Jeremiah came from Topheth, where the LORD had sent him to prophesy, and he stood in the court of the LORD's house and said to all the people,

**15** "This is what the LORD of Armies, the God of Israel, says: I am going to bring on this city and on all its towns all the disaster I have pronounced against it, because they have stiffened their necks so as not to listen to my words."

[^19-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles. "The LORD's house" in verse 14 is the temple.
[^19-2]: Hebrew *baqbuq*, a narrow-necked jar, a name that imitates the gurgling sound of liquid poured from it.
[^19-3]: The Hebrew has no verb here; "take with you" is supplied.
[^19-4]: Ben-hinnom, "the Son of Hinnom", was a valley south and west of Jerusalem (7:31).
[^19-5]: The name probably means "Potsherd Gate", from *cheres*, a piece of broken pottery.
[^19-6]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. Also in verses 11 and 15.
[^19-7]: Or "burning offerings". The Hebrew verb *qatar* means to make something go up in smoke. Also in verse 13.
[^19-8]: Hebrew *bamot*: places of worship, often on hilltops.
[^19-9]: Hebrew *tofet*, perhaps "fireplace, hearth", a place where children were burned as sacrifices (7:31–32; 2 Kings 23:10).
[^19-10]: A wordplay. Hebrew *u-vaqqoti*, "I will empty out", sounds like *baqbuq*, "jar" (verse 1).
[^19-11]: Compare Deuteronomy 28:53–57.
[^19-12]: The sun, moon and stars, worshiped as gods (8:2).

## Chapter 20

*Status: draft*

**1** When the priest Pashhur son of Immer, who was chief officer in the house of the LORD,[^20-1] heard Jeremiah prophesying these things,

**2** Pashhur struck Jeremiah the prophet and put him in the stocks[^20-2] at the Upper Gate of Benjamin in the house of the LORD.

**3** The next day, when Pashhur released Jeremiah from the stocks, Jeremiah said to him, "The LORD has not named you Pashhur, but Terror-on-Every-Side.[^20-3]

**4** For this is what the LORD says: I am going to make you a terror to yourself and to all your friends. They will fall by the sword of their enemies before your eyes. I will hand all Judah over to the king of Babylon,[^20-4] and he will carry them into exile to Babylon or strike them down with the sword.

**5** I will hand over to their enemies all the wealth of this city, all the fruit of its labor, all its valuables and all the treasures of the kings of Judah. They will plunder them, seize them and carry them off to Babylon.

**6** And you, Pashhur, and everyone who lives in your house will go into captivity. You will go to Babylon; there you will die, and there you will be buried, you and all your friends to whom you have prophesied lies."

**7** You deceived me,[^20-5] LORD, and I was deceived; you overpowered me, and you prevailed. I have become a laughingstock all day long; everyone mocks me.

**8** For whenever I speak, I cry out; I shout, "Violence and destruction!" For the word of the LORD has brought me insult and scorn all day long.

**9** If I say, "I will not mention him or speak any more in his name," then it is in my heart like a burning fire, shut up in my bones. I am worn out holding it in, and I cannot.

**10** For I hear many whispering, "Terror on every side! Denounce him! Let us denounce him!" All my close friends[^20-6] are watching for me to stumble: "Perhaps he will be deceived, and then we will prevail over him and take our revenge on him."

**11** But the LORD is with me like a mighty warrior. So my persecutors will stumble and not prevail. They will be utterly put to shame, for they will not succeed. Their disgrace will never be forgotten.

**12** LORD of Armies,[^20-7] you who test the righteous, who see the heart and mind,[^20-8] let me see your vengeance on them, for to you I have committed my cause.

**13** Sing to the LORD! Praise the LORD! For he has rescued the life of the needy from the hand of evildoers.

**14** Cursed be the day I was born![^20-9] May the day my mother gave birth to me not be blessed!

**15** Cursed be the man who brought the news to my father, "A son is born to you, a boy!" and made him very glad.

**16** May that man be like the cities that the LORD overthrew without relenting.[^20-10] May he hear a cry in the morning and a battle shout at noon,

**17** because he did not kill me in the womb, so that my mother would have been my grave, her womb pregnant forever.

**18** Why did I ever come out of the womb to see trouble and sorrow, and to end my days in shame?

[^20-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles. "The house of the LORD" is the temple. Pashhur's office was to keep order in the temple (compare 29:26).
[^20-2]: Hebrew *mahpekhet*, from a root meaning "to turn", perhaps a frame that held the body twisted in a painful position. Also in verse 3.
[^20-3]: Hebrew *Magor-missaviv*, the phrase Jeremiah uses in 6:25 and in verse 10.
[^20-4]: This is the first time Babylon is named in the book.
[^20-5]: Or "You enticed me". Hebrew *pittitani*, a verb used of seducing a young woman (Exodus 22:15; 22:16 in most English Bibles) and of luring someone into a trap (1 Kings 22:20–22). It is used again in verse 10. Verses 7–18 are the last of Jeremiah's personal laments (see 11:18).
[^20-6]: Literally "Every man of my peace".
[^20-7]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. This verse repeats 11:20 with small differences.
[^20-8]: Literally "the kidneys and the heart". In Hebrew thought the kidneys were the seat of the emotions and the heart of thought and will.
[^20-9]: Compare Job 3:1–19, which curses the day of birth in similar words.
[^20-10]: Sodom and Gomorrah (Genesis 19:24–25).

## Chapter 21

*Status: draft*

**1** The word that came to Jeremiah from the LORD[^21-1] when King Zedekiah sent to him Pashhur son of Malchiah[^21-2] and the priest Zephaniah son of Maaseiah, saying,

**2** "Please inquire of the LORD for us, because Nebuchadnezzar[^21-3] king of Babylon is making war against us. Perhaps the LORD will act for us in keeping with all his wonderful deeds, and make him withdraw from us."

**3** Jeremiah said to them, "Say this to Zedekiah:

**4** 'This is what the LORD, the God of Israel, says: I am going to turn back the weapons of war in your hands, with which you are fighting the king of Babylon and the Babylonians[^21-4] who are besieging you outside the wall, and I will gather them into the middle of this city.

**5** I myself will fight against you with an outstretched hand and a strong arm, in anger, in fury and in great wrath.

**6** I will strike down the inhabitants of this city, both human beings and animals; they will die of a great plague.

**7** After that, declares the LORD, I will hand over Zedekiah king of Judah, his servants and the people in this city who survive the plague, the sword and the famine, to Nebuchadnezzar king of Babylon, to their enemies and to those who seek their lives. He will strike them down with the edge of the sword; he will not spare them, or have pity or compassion.'"

**8** And to this people you are to say: This is what the LORD says: I am setting before you the way of life and the way of death.[^21-5]

**9** Whoever stays in this city will die by the sword, famine or plague. But whoever goes out and surrenders to the Babylonians who are besieging you will live; he will escape with his life.[^21-6]

**10** For I have set my face against this city for harm and not for good, declares the LORD. It will be handed over to the king of Babylon, and he will burn it with fire.

**11** And to the royal house of Judah: Hear the word of the LORD,

**12** house of David. This is what the LORD says: Do justice every morning, and rescue the one who has been robbed from the hand of the oppressor, or my wrath will break out like fire and burn with no one to put it out, because of the evil of your deeds.[^21-7]

**13** Look, I am against you, you who are enthroned above the valley,[^21-8] rock of the plain, declares the LORD, you who say, "Who can come down against us? Who can enter our dwellings?"

**14** I will punish you according to the fruit of your deeds, declares the LORD. I will kindle a fire in her forest,[^21-9] and it will consume everything around her.

[^21-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles. The events of this chapter took place during the Babylonian siege of Jerusalem, 588–587 BC.
[^21-2]: Not the Pashhur of 20:1–6. He appears again in 38:1. Zephaniah appears in 29:25–29; 37:3; 52:24.
[^21-3]: Hebrew *Nevukhadre'tsar*, a spelling closer to the Babylonian name *Nabu-kudurri-usur*, used often in Jeremiah and Ezekiel. Elsewhere the name is usually spelled *Nevukhadnetsar*, Nebuchadnezzar. He was king of Babylon from 605 to 562 BC.
[^21-4]: Hebrew *Kasdim*, traditionally "Chaldeans": the people of southern Mesopotamia whose kings then ruled Babylon. Also in verse 9.
[^21-5]: Compare Deuteronomy 30:15, 19.
[^21-6]: Literally "his life will be to him as plunder", that is, the only thing he takes away will be his life (38:2; 39:18; 45:5).
[^21-7]: The Hebrew text is written "their deeds" but read "your deeds".
[^21-8]: Literally "you who dwell in the valley", Jerusalem, set on its hill above the valleys (compare 2 Samuel 5:6). *You* is feminine, addressed to the city.
[^21-9]: Perhaps the royal palace, built with so much cedar that part of it was called the House of the Forest of Lebanon (1 Kings 7:2; Jeremiah 22:6–7, 23).

## Chapter 22

*Status: draft*

**1** This is what the LORD[^22-1] says: Go down to the palace of the king of Judah and speak this word there.

**2** Say: Hear the word of the LORD, king of Judah, you who sit on David's throne, you and your servants and your people who come in through these gates.

**3** This is what the LORD says: Do justice and righteousness. Rescue the one who has been robbed from the hand of the oppressor. Do not wrong or mistreat the foreigner, the fatherless or the widow, and do not shed innocent blood in this place.

**4** For if you truly carry out this word, then kings who sit on David's throne will come in through the gates of this palace, riding in chariots and on horses, each with his servants[^22-2] and his people.

**5** But if you do not listen to these words, I swear by myself, declares the LORD, that this palace will become a ruin.

**6** For this is what the LORD says about the palace of the king of Judah: You are like Gilead to me, like the summit of Lebanon,[^22-3] yet I will surely make you a wilderness, cities where no one lives.

**7** I will set apart destroyers against you,[^22-4] each with his weapons, and they will cut down your choicest cedars and throw them into the fire.

**8** Many nations will pass by this city, and they will say to one another, "Why has the LORD done such a thing to this great city?"

**9** And they will answer, "Because they abandoned the covenant of the LORD their God, and worshiped other gods and served them."

**10** Do not weep for the dead,[^22-5] or mourn for him. Weep bitterly instead for the one who is going away, for he will never come back to see his native land.

**11** For this is what the LORD says about Shallum[^22-6] son of Josiah king of Judah, who became king in place of his father Josiah and who has gone away from this place: He will never come back here.

**12** He will die in the place where they have taken him into exile, and he will never see this land again.

**13** Woe to[^22-7] him who builds his house without righteousness and his upper rooms without justice, who makes his neighbor work for nothing and does not pay him his wages,

**14** who says, "I will build myself a spacious house with roomy upper rooms," who cuts out windows for it, panels it with cedar and paints it red.[^22-8]

**15** Does it make you a king, that you compete in cedar? Did your father not eat and drink, and do justice and righteousness? Then it went well with him.

**16** He defended the cause of the poor and needy; then it went well. Is that not what it means to know me? declares the LORD.

**17** But your eyes and your heart are set only on your dishonest gain, on shedding innocent blood, on oppression and extortion.

**18** Therefore this is what the LORD says about Jehoiakim son of Josiah king of Judah: They will not mourn for him, "Ah,[^22-9] my brother! Ah, sister!" They will not mourn for him, "Ah, master! Ah, his majesty!"

**19** He will be buried with the burial of a donkey, dragged off and thrown out beyond the gates of Jerusalem.[^22-10]

**20** Go up to Lebanon and cry out; raise your voice in Bashan; cry out from Abarim,[^22-11] for all your lovers are crushed.

**21** I spoke to you when you were at ease, but you said, "I will not listen." This has been your way from your youth: you have not listened to my voice.

**22** The wind will shepherd away all your shepherds,[^22-12] and your lovers will go into captivity. Then you will be ashamed and humiliated because of all your wickedness.

**23** You who live in Lebanon, nestled among the cedars,[^22-13] how pitiable you will be[^22-14] when pangs come on you, pain like that of a woman in labor!

**24** As surely as I live, declares the LORD, even if Coniah[^22-15] son of Jehoiakim king of Judah were the signet ring on my right hand, I would still pull you off it.

**25** I will hand you over to those who seek your life, to those you fear, to Nebuchadnezzar[^22-16] king of Babylon and to the Babylonians.[^22-17]

**26** I will hurl you and the mother who bore you into another country, where neither of you was born, and there you will die.

**27** They will never return to the land they long to return to.

**28** Is this man Coniah a despised, broken pot, a jar that no one wants? Why have he and his children been hurled out and thrown into a land they do not know?

**29** Land, land, land, hear the word of the LORD!

**30** This is what the LORD says: Record this man as childless,[^22-18] a man who will not prosper in his lifetime. For none of his descendants will prosper; none will sit on David's throne or rule again in Judah.

[^22-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^22-2]: The Hebrew text is written "his servant" but read "his servants".
[^22-3]: Gilead and Lebanon were famous for their forests. The palace was built with so much cedar that part of it was called the House of the Forest of Lebanon (1 Kings 7:2).
[^22-4]: Literally "I will consecrate destroyers against you", as soldiers were consecrated for a holy war (6:4).
[^22-5]: King Josiah, killed in battle in 609 BC (2 Kings 23:29–30). The one who is going away is his son Shallum (verse 11).
[^22-6]: Shallum was the personal name of Jehoahaz, who reigned three months in 609 BC before Pharaoh Neco took him to Egypt (2 Kings 23:30–34; 1 Chronicles 3:15).
[^22-7]: Hebrew *hoy*, a cry of mourning for the dead (verse 18; 1 Kings 13:30), used by the prophets to announce disaster. The king meant in verses 13–19 is Jehoiakim (verse 18), who reigned from 609 to 598 BC.
[^22-8]: Hebrew *shashar*, a red pigment, probably vermilion.
[^22-9]: Hebrew *hoy*, the cry of mourning translated "Woe to" in verse 13. The mourners address the dead as family and as lord.
[^22-10]: That is, his body will be thrown out unburied. 2 Kings 24:6 says only that he "slept with his ancestors".
[^22-11]: The mountains of Moab, east of the Dead Sea (Numbers 27:12). Lebanon in the north, Bashan in the northeast and Abarim in the southeast: Jerusalem, pictured as a woman, is to cry out from every height.
[^22-12]: A wordplay: *kol ro'ayikh tir'eh ruach*. Shepherds were rulers; the wind will drive them away as a shepherd drives a flock.
[^22-13]: Jerusalem, and especially its cedar-built palace (verse 6). The Hebrew text is written "I live … I am nested" but read "you live … you are nested". The written forms are probably an old spelling of "you" (compare 2:33).
[^22-14]: The Septuagint and the Vulgate read "how you will groan".
[^22-15]: A short form of Jeconiah (24:1), also called Jehoiachin (2 Kings 24:8–15). He reigned three months in 597 BC and was taken to Babylon with his mother Nehushta.
[^22-16]: Hebrew *Nevukhadre'tsar*: see 21:2.
[^22-17]: Hebrew *Kasdim*, traditionally "Chaldeans": the people of southern Mesopotamia whose kings then ruled Babylon.
[^22-18]: Hebrew *ariri*, "stripped, childless". Jehoiachin had sons (1 Chronicles 3:17–18), but the verse goes on to say that none of them would reign.

## Chapter 23

*Status: draft*

**1** Woe to the shepherds[^23-1] who destroy and scatter the sheep of my pasture! declares the LORD.[^23-2]

**2** Therefore this is what the LORD, the God of Israel, says about the shepherds who shepherd my people: You have scattered my flock and driven them away, and you have not cared for them. So I am going to deal with you[^23-3] for the evil of your deeds, declares the LORD.

**3** I myself will gather the remnant of my flock from all the lands where I have driven them, and I will bring them back to their pasture, and they will be fruitful and multiply.

**4** I will raise up shepherds over them who will shepherd them, and they will no longer be afraid or dismayed, and none will be missing, declares the LORD.

**5** Look, the days are coming, declares the LORD, when I will raise up for David a righteous Branch.[^23-4] He will reign as king and act wisely, and he will do justice and righteousness in the land.

**6** In his days Judah will be saved, and Israel will live in safety. And this is the name by which he will be called: The LORD Is Our Righteousness.[^23-5]

**7** Therefore, look, the days are coming, declares the LORD, when people will no longer say, "As surely as the LORD lives, who brought the Israelites up out of the land of Egypt,"[^23-6]

**8** but, "As surely as the LORD lives, who brought up and led the descendants of the house of Israel out of the land of the north and out of all the lands where I had driven them."[^23-7] Then they will live on their own land.

**9** Concerning the prophets: My heart is broken within me; all my bones tremble. I am like a drunk man, like a man overcome by wine, because of the LORD and because of his holy words.

**10** For the land is full of adulterers; because of the curse the land mourns, and the pastures of the wilderness are dried up. Their course is evil, and their might is not right.

**11** Both prophet and priest are godless; even in my house I have found their wickedness, declares the LORD.

**12** Therefore their way will be to them like slippery paths in the darkness; they will be driven on and fall there. For I will bring disaster on them, the year of their punishment, declares the LORD.

**13** Among the prophets of Samaria I saw something offensive: they prophesied by Baal and led my people Israel astray.

**14** But among the prophets of Jerusalem I have seen something horrible: they commit adultery and walk in lies. They strengthen the hands of evildoers, so that no one turns from his wickedness. All of them have become like Sodom to me, and its inhabitants like Gomorrah.

**15** Therefore this is what the LORD of Armies[^23-8] says about the prophets: I am going to feed them wormwood[^23-9] and make them drink poisoned water, for from the prophets of Jerusalem godlessness has spread throughout the land.

**16** This is what the LORD of Armies says: Do not listen to the words of the prophets who prophesy to you. They are filling you with empty hopes.[^23-10] They speak visions from their own minds, not from the mouth of the LORD.

**17** They keep saying to those who despise me,[^23-11] "The LORD has said, 'You will have peace.'" And to everyone who follows the stubbornness of his heart they say, "No disaster will come on you."

**18** But which of them has stood in the council of the LORD, to see and hear his word? Who has paid attention to his word[^23-12] and listened?

**19** Look, the storm of the LORD! Wrath has gone out, a whirling tempest; it will whirl down on the heads of the wicked.

**20** The anger of the LORD will not turn back until he has done and carried out the purposes of his heart. In the days to come you will understand it clearly.[^23-13]

**21** I did not send these prophets, yet they ran. I did not speak to them, yet they prophesied.

**22** But if they had stood in my council, they would have proclaimed my words to my people and turned them back from their evil way and from the evil of their deeds.

**23** Am I a God who is near, declares the LORD, and not a God far off?

**24** Can anyone hide in secret places so that I cannot see him? declares the LORD. Do I not fill heaven and earth? declares the LORD.

**25** I have heard what the prophets say who prophesy lies in my name: "I had a dream! I had a dream!"

**26** How long? Is there anything in the minds[^23-14] of the prophets who prophesy lies, the prophets of the deceit of their own minds?

**27** They plan to make my people forget my name by the dreams they tell one another, just as their ancestors forgot my name for Baal.

**28** Let the prophet who has a dream tell his dream, but let the one who has my word speak my word faithfully. What does straw have to do with grain? declares the LORD.

**29** Is not my word like fire, declares the LORD, and like a hammer that shatters rock?

**30** Therefore I am against the prophets, declares the LORD, who steal my words from one another.

**31** I am against the prophets, declares the LORD, who use their own tongues and declare, "He declares."[^23-15]

**32** I am against those who prophesy lying dreams, declares the LORD, who tell them and lead my people astray with their lies and their recklessness. I did not send them or command them, and they do this people no good at all, declares the LORD.

**33** When this people, or a prophet or a priest, asks you, "What is the burden[^23-16] of the LORD?" say to them, "What burden?[^23-17] I will cast you off, declares the LORD."

**34** And if a prophet or a priest or anyone else says, "The burden of the LORD," I will punish that man and his household.

**35** This is what each of you is to say to his neighbor and to his brother: "What has the LORD answered?" or "What has the LORD spoken?"

**36** But you must no longer mention "the burden of the LORD," for each man's own word will become his burden, and you twist the words of the living God, the LORD of Armies, our God.

**37** This is what you are to say to the prophet: "What has the LORD answered you?" or "What has the LORD spoken?"

**38** But if you say, "The burden of the LORD," then this is what the LORD says: Because you have used these words, "The burden of the LORD," though I sent word to you, "You must not say, 'The burden of the LORD,'"

**39** therefore I will surely forget you[^23-18] and cast you away from my presence, you and the city I gave to you and your ancestors.

**40** I will bring on you everlasting disgrace and everlasting shame that will never be forgotten.

[^23-1]: Hebrew *hoy*: see 22:13. The shepherds are the kings of Judah (22:22).
[^23-2]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^23-3]: A wordplay on *paqad*, "attend to, care for, punish": "you have not attended to them, so I will attend to you". In verse 4, *none will be missing* is from the same verb.
[^23-4]: Hebrew *tsemach*, "sprout, branch", a new shoot from the stump of David's family tree. It became a title for the promised king of David's line (33:15; Zechariah 3:8; 6:12), and later Jewish and Christian readers heard the Messiah here.
[^23-5]: Hebrew *YHWH tsidqenu*, perhaps a play on the name of Zedekiah, *Tsidqiyyahu*, "The LORD is my righteousness", the last king of Judah. Verses 5–6 are repeated, with differences, in 33:15–16.
[^23-6]: The Septuagint places verses 7–8 after verse 40. They repeat 16:14–15 with small differences.
[^23-7]: The Hebrew has "I", as though the LORD were speaking. 16:15 has "he".
[^23-8]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. Also in verses 16 and 36.
[^23-9]: Hebrew *la'anah*, a plant with a very bitter taste (9:14; 9:15 in most English Bibles).
[^23-10]: Hebrew *mahbilim*, from *hevel*, "breath, vapor" (2:5): "they make you empty".
[^23-11]: The same consonants can be read "to those who despise the word of the LORD", as the Septuagint reads.
[^23-12]: The Hebrew text is written "my word" but read "his word".
[^23-13]: Verses 19–20 are repeated, with small differences, in 30:23–24.
[^23-14]: Literally "in the heart". The Hebrew of this verse is difficult.
[^23-15]: Literally "and declare a declaration", using the word *ne'um* of the formula "declares the LORD" (see 1:8).
[^23-16]: Hebrew *massa*, a word that means both "oracle", a message from the LORD, and "burden", a load to be carried (17:21). In verses 33–40 Jeremiah plays on both senses, and "the burden of the LORD" seems to have become a mocking catchword for his prophecies.
[^23-17]: Hebrew *et-mah-massa*. The Septuagint and the Vulgate divide the consonants differently, *attem ha-massa*, "You are the burden".
[^23-18]: Hebrew *nashiti … nasho*, "I will surely forget". The Vulgate reads "I will lift you up", as though from *nasa*, "lift, carry", continuing the play on *massa*, "burden".

## Chapter 24

*Status: draft*

**1** The LORD[^24-1] showed me two baskets of figs set in front of the temple of the LORD. This was after Nebuchadnezzar[^24-2] king of Babylon had taken into exile from Jerusalem Jeconiah[^24-3] son of Jehoiakim king of Judah, the officials of Judah, the craftsmen and the metalworkers,[^24-4] and had brought them to Babylon.

**2** One basket had very good figs, like figs that ripen early, and the other basket had very bad figs, so bad they could not be eaten.

**3** The LORD said to me, "What do you see, Jeremiah?" I said, "Figs. The good figs are very good, and the bad ones are very bad, so bad they cannot be eaten."

**4** Then the word of the LORD came to me:

**5** "This is what the LORD, the God of Israel, says: Like these good figs, so I will regard as good the exiles of Judah, whom I have sent away from this place to the land of the Babylonians.[^24-5]

**6** I will set my eyes on them for good, and I will bring them back to this land. I will build them up and not tear them down; I will plant them and not uproot them.

**7** I will give them a heart to know me, that I am the LORD. They will be my people, and I will be their God, for they will return to me with all their heart.

**8** But like the bad figs, which are so bad they cannot be eaten, this is what the LORD says, so I will treat Zedekiah king of Judah, his officials, and the remnant of Jerusalem who remain in this land and those who live in the land of Egypt.

**9** I will make them a horror, a disaster, to all the kingdoms of the earth, a disgrace and a byword, a taunt and a curse, in all the places where I will drive them.

**10** I will send the sword, famine and plague against them until they are wiped out from the land I gave to them and their ancestors."

[^24-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^24-2]: Hebrew *Nevukhadre'tsar*: see 21:2.
[^24-3]: Also called Jehoiachin, and Coniah (22:24). He was taken to Babylon in 597 BC (2 Kings 24:10–16).
[^24-4]: Hebrew *masger*, perhaps "smith" or "locksmith" (2 Kings 24:14).
[^24-5]: Hebrew *Kasdim*, traditionally "Chaldeans": the people of southern Mesopotamia whose kings then ruled Babylon.

## Chapter 25

*Status: draft*

**1** The word that came to Jeremiah concerning all the people of Judah in the fourth year of Jehoiakim son of Josiah king of Judah, which was the first year of Nebuchadnezzar[^25-1] king of Babylon.

**2** Jeremiah the prophet spoke it to all the people of Judah and to all the inhabitants of Jerusalem:

**3** For twenty-three years, from the thirteenth year of Josiah son of Amon king of Judah until this day, the word of the LORD[^25-2] has come to me, and I have spoken to you again and again,[^25-3] but you have not listened.

**4** The LORD has sent you all his servants the prophets, sending them again and again, but you have not listened or paid any attention.

**5** They said, "Turn back, each of you, from your evil way and your evil deeds, and you will live[^25-4] in the land the LORD gave to you and your ancestors for all time.

**6** Do not follow other gods to serve them and worship them, and do not provoke me to anger with what your hands have made. Then I will not harm you."

**7** But you did not listen to me, declares the LORD, and so you provoked me to anger with what your hands have made, to your own harm.

**8** Therefore this is what the LORD of Armies[^25-5] says: Because you have not listened to my words,

**9** I am going to send for all the clans of the north, declares the LORD, and for my servant Nebuchadnezzar king of Babylon.[^25-6] I will bring them against this land and its inhabitants and against all these nations around it. I will destroy them completely[^25-7] and make them a horror, a thing to hiss at, and an everlasting ruin.

**10** I will banish from them the sound of joy and the sound of gladness, the voice of the bridegroom and the voice of the bride, the sound of the millstones and the light of the lamp.

**11** This whole land will become a ruin and a desolation, and these nations will serve the king of Babylon for seventy years.[^25-8]

**12** But when the seventy years are complete, I will punish the king of Babylon and that nation for their wrongdoing, declares the LORD, and the land of the Babylonians,[^25-9] and I will make it a desolation forever.

**13** I will bring on that land all the words I have spoken against it, all that is written in this book, which Jeremiah prophesied against all the nations.[^25-10]

**14** For many nations and great kings will make slaves of them too, and I will repay them according to their deeds and the work of their hands.

**15** For this is what the LORD, the God of Israel, said to me: Take from my hand this cup of the wine of wrath, and make all the nations to whom I send you drink it.

**16** They will drink and stagger and go mad because of the sword I am sending among them.

**17** So I took the cup from the LORD's hand and made all the nations to whom the LORD sent me drink it:

**18** Jerusalem and the cities of Judah, its kings and its officials, to make them a ruin, a horror, a thing to hiss at and a curse, as they are today;

**19** Pharaoh king of Egypt, his servants, his officials and all his people;

**20** all the mixed peoples;[^25-11] all the kings of the land of Uz;[^25-12] all the kings of the land of the Philistines: Ashkelon, Gaza, Ekron and what remains of Ashdod;

**21** Edom, Moab and the Ammonites;

**22** all the kings of Tyre, all the kings of Sidon, and the kings of the coastlands across the sea;

**23** Dedan, Tema, Buz[^25-13] and all who clip the hair on their temples;[^25-14]

**24** all the kings of Arabia and all the kings of the mixed peoples who live in the desert;[^25-15]

**25** all the kings of Zimri,[^25-16] all the kings of Elam and all the kings of Media;

**26** all the kings of the north, near and far, one after another; and all the kingdoms of the world on the face of the earth. And after them the king of Sheshach will drink.[^25-17]

**27** Then say to them: This is what the LORD of Armies, the God of Israel, says: Drink, get drunk and vomit; fall and rise no more, because of the sword I am sending among you.

**28** And if they refuse to take the cup from your hand and drink, say to them: This is what the LORD of Armies says: You must drink it!

**29** For look, I am beginning to bring disaster on the city that bears my name,[^25-18] and will you go unpunished? You will not go unpunished, for I am summoning a sword against all the inhabitants of the earth, declares the LORD of Armies.

**30** As for you, prophesy all these words against them, and say to them: The LORD roars from on high; from his holy dwelling he raises his voice. He roars mightily against his pasture; he shouts like those who tread grapes, against all who live on the earth.[^25-19]

**31** The uproar resounds to the ends of the earth, for the LORD has a case[^25-20] against the nations; he is entering into judgment with all humankind.[^25-21] The wicked he will hand over to the sword, declares the LORD.

**32** This is what the LORD of Armies says: Look, disaster is spreading from nation to nation; a great storm is being stirred up from the farthest parts of the earth.

**33** On that day those slain by the LORD will lie from one end of the earth to the other. They will not be mourned or gathered up or buried; they will be like dung on the surface of the ground.

**34** Wail, you shepherds, and cry out! Roll in the dust, you leaders of the flock![^25-22] For the days of your slaughter and your scattering have come, and you will fall like a precious vessel.

**35** There will be no escape for the shepherds, no way out for the leaders of the flock.

**36** Listen! The cry of the shepherds, the wailing of the leaders of the flock, for the LORD is destroying their pasture.

**37** The peaceful meadows are laid waste[^25-23] because of the fierce anger of the LORD.

**38** Like a lion he has left his lair, for their land has become a desolation because of the fury of the oppressor,[^25-24] and because of his fierce anger.

[^25-1]: Hebrew *Nevukhadre'tsar*: see 21:2. The year is 605 BC, when Nebuchadnezzar defeated the Egyptians at Carchemish (46:2) and became king of Babylon.
[^25-2]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^25-3]: Literally "rising early and speaking". Also in verse 4.
[^25-4]: A wordplay: *shuvu*, "turn back", and *u-shevu*, "and live".
[^25-5]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. Also in verses 27–29 and 32.
[^25-6]: The Septuagint does not have "and for my servant Nebuchadnezzar king of Babylon". In its text of verses 1–13 the enemy from the north is not named.
[^25-7]: Hebrew *charam*, to devote something to destruction, as an offering to God that no one may keep (Deuteronomy 7:2; Joshua 6:17).
[^25-8]: Compare 29:10; 2 Chronicles 36:21; Daniel 9:2. Babylon fell to the Persians in 539 BC, about seventy years after Nebuchadnezzar came to power.
[^25-9]: Hebrew *Kasdim*, traditionally "Chaldeans": the people of southern Mesopotamia whose kings then ruled Babylon.
[^25-10]: The Septuagint of Jeremiah is about one-eighth shorter than the Hebrew text, and it arranges the book differently. It ends this verse at "all that is written in this book", and uses the next words, "which Jeremiah prophesied against the nations", as the heading of the oracles against the nations, which in the Hebrew are chapters 46–51. They follow here, in a different order, and after them comes 25:15–38. Verse 14 is not in the Septuagint. From here on its chapter numbers differ from the Hebrew: Hebrew chapters 26–45 are Septuagint chapters 33–51. Hebrew fragments of Jeremiah found at Qumran (4QJer-b and 4QJer-d) show that a shorter Hebrew text, like the one the Septuagint translates, also existed.
[^25-11]: Hebrew *ha-erev*, "the mixture", perhaps foreigners living in Egypt (compare Exodus 12:38), or the desert tribes of verse 24.
[^25-12]: A region east or southeast of Israel, near Edom (Job 1:1; Lamentations 4:21).
[^25-13]: Peoples and oases of northern Arabia.
[^25-14]: Literally "all who are cut at the corners": see 9:25 (9:26 in most English Bibles).
[^25-15]: In Hebrew *arav*, "Arabia", and *ha-erev*, "the mixed peoples", are written with the same consonants.
[^25-16]: An unknown people.
[^25-17]: *Sheshach* is a code name for Babylon, made by the cipher called *atbash*, in which each letter of the alphabet is replaced by the letter in the same place counting from the end (the first letter by the last, the second by the next-to-last, and so on). So *Bavel* (the letters *b-b-l*) becomes *Sheshakh* (*sh-sh-k*). It is used again in 51:41, beside the name Babylon. The Septuagint does not have this sentence.
[^25-18]: Literally "over which my name is called": Jerusalem.
[^25-19]: Compare Amos 1:2; Joel 4:16 (3:16 in most English Bibles).
[^25-20]: Hebrew *riv*, to bring a case against someone, as in a court of law.
[^25-21]: Literally "with all flesh".
[^25-22]: Literally "you majestic ones of the flock". Also in verses 35 and 36. The shepherds and leaders are the rulers of the nations.
[^25-23]: Literally "are silenced".
[^25-24]: Literally "the burning of the oppressor". Some scholars read "the sword of the oppressor", as in 46:16 and 50:16, with a small change to the Hebrew.

## Chapter 26

*Status: draft*

**1** At the beginning of the reign of Jehoiakim son of Josiah king of Judah,[^26-1] this word came from the LORD:[^26-2]

**2** "This is what the LORD says: Stand in the court of the LORD's house and speak to all the people of the towns of Judah who come to worship in the LORD's house. Tell them all the words I command you to speak to them; do not leave out a word.

**3** Perhaps they will listen, and each of them will turn from his evil way. Then I will relent of the disaster I am planning to bring on them because of their evil deeds.

**4** Say to them: 'This is what the LORD says: If you do not listen to me and walk in my instruction,[^26-3] which I have set before you,

**5** and listen to the words of my servants the prophets, whom I send to you again and again,[^26-4] though you have not listened,

**6** then I will make this house like Shiloh,[^26-5] and I will make this city a curse for all the nations of the earth.'"

**7** The priests, the prophets and all the people heard Jeremiah speaking these words in the house of the LORD.

**8** When Jeremiah had finished speaking everything that the LORD had commanded him to speak to all the people, the priests, the prophets and all the people seized him and said, "You must die!

**9** Why have you prophesied in the name of the LORD, 'This house will be like Shiloh, and this city will be laid waste, with no one living in it'?" And all the people crowded around Jeremiah in the house of the LORD.

**10** When the officials of Judah heard these things, they came up from the king's palace to the house of the LORD and took their seats at the entrance of the New Gate of the LORD's house.

**11** Then the priests and the prophets said to the officials and to all the people, "This man deserves the death sentence, because he has prophesied against this city, as you have heard with your own ears."

**12** Then Jeremiah said to all the officials and to all the people, "The LORD sent me to prophesy against this house and this city all the words you have heard.

**13** So now make your ways and your deeds good, and listen to the voice of the LORD your God. Then the LORD will relent of the disaster he has pronounced against you.

**14** As for me, I am in your hands. Do with me whatever seems good and right to you.

**15** But know for certain that if you put me to death, you will bring innocent blood on yourselves, on this city and on its inhabitants, for in truth the LORD has sent me to you to speak all these words in your hearing."

**16** Then the officials and all the people said to the priests and the prophets, "This man does not deserve the death sentence, for he has spoken to us in the name of the LORD our God."

**17** Some of the elders of the land stood up and said to the whole assembly of the people,

**18** "Micah of Moresheth[^26-6] prophesied in the days of Hezekiah king of Judah. He said to all the people of Judah, 'This is what the LORD of Armies[^26-7] says: Zion will be plowed like a field, Jerusalem will become a heap of ruins, and the temple mount a wooded height.'[^26-8]

**19** Did Hezekiah king of Judah and all Judah put him to death? Did he not fear the LORD and seek the LORD's favor?[^26-9] And the LORD relented of the disaster he had pronounced against them. But we are about to bring a great disaster on ourselves!"

**20** There was also a man who prophesied in the name of the LORD, Uriah son of Shemaiah from Kiriath-jearim. He prophesied against this city and this land just as Jeremiah did.

**21** When King Jehoiakim and all his warriors and all the officials heard his words, the king sought to put him to death. But Uriah heard of it and was afraid, and he fled to Egypt.

**22** Then King Jehoiakim sent men to Egypt: Elnathan son of Achbor[^26-10] and some men with him.

**23** They brought Uriah out of Egypt and took him to King Jehoiakim, who struck him down with the sword and threw his body into the burial ground of the common people.

**24** But Ahikam son of Shaphan[^26-11] protected Jeremiah,[^26-12] so that he was not handed over to the people to be put to death.

[^26-1]: About 609–608 BC. This chapter tells what happened when Jeremiah gave the message of 7:1–15.
[^26-2]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles. "The LORD's house" and "this house" are the temple.
[^26-3]: Hebrew *torah*, "instruction, law".
[^26-4]: Literally "rising early and sending".
[^26-5]: See 7:12–14.
[^26-6]: The Hebrew text is written "Micaiah" but read "Micah". Moresheth was a town in the Shephelah of Judah (Micah 1:1, 14).
[^26-7]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel.
[^26-8]: Micah 3:12. *The temple mount* is literally "the mountain of the house".
[^26-9]: Literally "soften the face of the LORD".
[^26-10]: Probably the official of 36:12, 25, and perhaps the father of Nehushta, Jehoiachin's mother (2 Kings 24:8). Achbor was one of the men Josiah sent to Huldah (2 Kings 22:12–14).
[^26-11]: Ahikam was one of Josiah's officials (2 Kings 22:12). His son Gedaliah was later made governor of Judah (Jeremiah 39:14; 40:5).
[^26-12]: Literally "the hand of Ahikam son of Shaphan was with Jeremiah".

## Chapter 27

*Status: draft*

**1** At the beginning of the reign of Jehoiakim[^27-1] son of Josiah king of Judah, this word came to Jeremiah from the LORD:[^27-2]

**2** This is what the LORD said to me: "Make yourself straps and yoke bars, and put them on your neck.

**3** Then send them to the king of Edom, the king of Moab, the king of the Ammonites, the king of Tyre and the king of Sidon, by the envoys who have come to Jerusalem to Zedekiah king of Judah.

**4** Give them a message for their masters: 'This is what the LORD of Armies,[^27-3] the God of Israel, says: This is what you are to say to your masters:

**5** By my great power and my outstretched arm I made the earth, and the human beings and the animals on the face of the earth, and I give it to whomever I see fit.

**6** Now I have handed all these lands over to my servant Nebuchadnezzar king of Babylon.[^27-4] I have given him even the wild animals to serve him.

**7** All the nations will serve him and his son and his grandson, until the time comes for his own land too. Then many nations and great kings will make him their slave.[^27-5]

**8** But if any nation or kingdom will not serve Nebuchadnezzar king of Babylon or put its neck under the yoke of the king of Babylon, I will punish that nation with the sword, famine and plague, declares the LORD, until I have destroyed it by his hand.

**9** So do not listen to your prophets, your diviners, your dreamers,[^27-6] your soothsayers or your sorcerers, who keep telling you, "You will not serve the king of Babylon."

**10** For they are prophesying lies to you, so that you will be removed far from your land; I will drive you out, and you will perish.

**11** But the nation that puts its neck under the yoke of the king of Babylon and serves him, I will leave on its own land, declares the LORD, to farm it and live there.'"

**12** I spoke the same message to Zedekiah king of Judah: "Put your necks under the yoke of the king of Babylon; serve him and his people, and you will live.

**13** Why should you and your people die by the sword, famine and plague, as the LORD has spoken against any nation that will not serve the king of Babylon?

**14** Do not listen to the words of the prophets who say to you, 'You will not serve the king of Babylon,' for they are prophesying lies to you.

**15** I have not sent them, declares the LORD. They are prophesying falsely in my name, so that I will drive you out and you will perish, you and the prophets who prophesy to you."

**16** Then I spoke to the priests and to all this people: "This is what the LORD says: Do not listen to the words of your prophets who prophesy to you, 'Look, the vessels of the LORD's house will very soon be brought back from Babylon,'[^27-7] for they are prophesying lies to you.

**17** Do not listen to them. Serve the king of Babylon and live. Why should this city become a ruin?

**18** If they are prophets and if the word of the LORD is with them, let them plead with the LORD of Armies that the vessels still left in the house of the LORD, in the palace of the king of Judah and in Jerusalem may not go to Babylon.

**19** For this is what the LORD of Armies says about the pillars, the Sea,[^27-8] the stands and the rest of the vessels still left in this city,

**20** which Nebuchadnezzar king of Babylon did not take when he carried Jeconiah son of Jehoiakim king of Judah into exile from Jerusalem to Babylon, along with all the nobles of Judah and Jerusalem:

**21** this is what the LORD of Armies, the God of Israel, says about the vessels left in the house of the LORD, in the palace of the king of Judah and in Jerusalem:

**22** They will be taken to Babylon, and there they will stay until the day I attend to them, declares the LORD. Then I will bring them up and restore them to this place."[^27-9]

[^27-1]: The chapter concerns the reign of Zedekiah (verses 3 and 12; 28:1), about 594 BC. Some Hebrew manuscripts and the Syriac read "Zedekiah" here. The Septuagint does not have this verse.
[^27-2]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles. "The LORD's house" and "the house of the LORD" are the temple.
[^27-3]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. Also in verses 18, 19 and 21.
[^27-4]: In this chapter and the next the Hebrew spells the name *Nevukhadne'tsar*, Nebuchadnezzar, not *Nevukhadre'tsar* as in most of Jeremiah (21:2).
[^27-5]: The Septuagint does not have verse 7.
[^27-6]: Literally "your dreams".
[^27-7]: The temple vessels taken to Babylon with Jehoiachin in 597 BC (2 Kings 24:13).
[^27-8]: The great bronze basin in the temple court. The pillars, the Sea and the stands were bronze works made for Solomon's temple (1 Kings 7:15–39). Their fate is told in 2 Kings 25:13–17 and Jeremiah 52:17–23.
[^27-9]: The Septuagint text of verses 19–22 is much shorter, and it does not have the promise that the vessels will be brought back.

## Chapter 28

*Status: draft*

**1** In that same year, at the beginning of the reign of Zedekiah king of Judah, in the fifth month of the fourth year,[^28-1] the prophet Hananiah son of Azzur, from Gibeon,[^28-2] spoke to me in the house of the LORD[^28-3] in the presence of the priests and all the people:

**2** "This is what the LORD of Armies,[^28-4] the God of Israel, says: I have broken the yoke of the king of Babylon.

**3** Within two years[^28-5] I will bring back to this place all the vessels of the LORD's house that Nebuchadnezzar king of Babylon took from this place and carried to Babylon.

**4** I will also bring back to this place Jeconiah son of Jehoiakim king of Judah and all the exiles from Judah who went to Babylon, declares the LORD, for I will break the yoke of the king of Babylon."

**5** Then the prophet Jeremiah answered the prophet Hananiah in the presence of the priests and all the people who were standing in the house of the LORD.

**6** The prophet Jeremiah said, "Amen![^28-6] May the LORD do so! May the LORD fulfill the words you have prophesied, and bring back the vessels of the LORD's house and all the exiles from Babylon to this place.

**7** But listen now to this word that I speak in your hearing and in the hearing of all the people.

**8** The prophets who were before you and me from ancient times prophesied war, disaster and plague against many countries and great kingdoms.

**9** As for the prophet who prophesies peace, when the word of that prophet comes true, then it will be known that the LORD has truly sent him."[^28-7]

**10** Then the prophet Hananiah took the yoke bar from the neck of the prophet Jeremiah and broke it.

**11** And Hananiah said in the presence of all the people, "This is what the LORD says: In the same way I will break the yoke of Nebuchadnezzar king of Babylon from the neck of all the nations within two years." Then the prophet Jeremiah went on his way.

**12** After the prophet Hananiah had broken the yoke bar from the neck of the prophet Jeremiah, the word of the LORD came to Jeremiah:

**13** "Go and tell Hananiah: 'This is what the LORD says: You have broken wooden yoke bars, but you have made iron yoke bars in their place.

**14** For this is what the LORD of Armies, the God of Israel, says: I have put an iron yoke on the neck of all these nations, to serve Nebuchadnezzar king of Babylon, and they will serve him. I have given him even the wild animals.'"

**15** Then the prophet Jeremiah said to the prophet Hananiah, "Listen, Hananiah! The LORD has not sent you, and you have made this people trust in a lie.

**16** Therefore this is what the LORD says: I am going to send you off the face of the earth.[^28-8] This year you will die, because you have preached rebellion against the LORD."[^28-9]

**17** And the prophet Hananiah died that same year, in the seventh month.

[^28-1]: The fourth year of Zedekiah was 594–593 BC. The Septuagint reads only "In the fourth year of Zedekiah king of Judah, in the fifth month".
[^28-2]: A town of priests about 6 miles (10 km) northwest of Jerusalem (Joshua 21:17). The Septuagint calls him "Hananiah the false prophet".
[^28-3]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles. "The house of the LORD" and "the LORD's house" are the temple.
[^28-4]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. Also in verse 14.
[^28-5]: Literally "Within two years of days". Also in verse 11.
[^28-6]: Hebrew *amen*, "So be it".
[^28-7]: Compare Deuteronomy 18:21–22.
[^28-8]: A wordplay on *shalach*, "send": The LORD did not *send* Hananiah (verse 15), but he will *send him off* the earth.
[^28-9]: The words of Deuteronomy 13:6 (13:5 in most English Bibles), about the prophet who must die.

## Chapter 29

*Status: draft*

**1** These are the words of the letter that Jeremiah the prophet sent from Jerusalem to the surviving elders of the exiles,[^29-1] to the priests, to the prophets and to all the people whom Nebuchadnezzar had deported from Jerusalem to Babylon.

**2** This was after King Jeconiah,[^29-2] the queen mother,[^29-3] the court officials,[^29-4] the officials of Judah and Jerusalem, the craftsmen and the metalworkers[^29-5] had left Jerusalem.

**3** He sent it by Elasah son of Shaphan and Gemariah son of Hilkiah, whom Zedekiah king of Judah sent to Babylon, to Nebuchadnezzar king of Babylon. It said:

**4** This is what the LORD of Armies,[^29-6] the God of Israel, says to all the exiles whom I deported from Jerusalem to Babylon:

**5** Build houses and live in them; plant gardens and eat their produce.

**6** Take wives and have sons and daughters. Take wives for your sons and give your daughters to husbands, so that they may bear sons and daughters. Multiply there; do not decrease.

**7** Seek the well-being[^29-7] of the city where I have sent you into exile, and pray to the LORD for it, for in its well-being you will have well-being.

**8** For this is what the LORD of Armies, the God of Israel, says: Do not let your prophets who are among you and your diviners deceive you, and do not listen to the dreams that you dream.[^29-8]

**9** For they are prophesying lies to you in my name. I did not send them, declares the LORD.

**10** For this is what the LORD says: When seventy years are completed for Babylon,[^29-9] I will come to you,[^29-10] and I will fulfill for you my good promise to bring you back to this place.

**11** For I know the plans I have for you, declares the LORD, plans for well-being and not for disaster, to give you a future and a hope.[^29-11]

**12** Then you will call on me and come and pray to me, and I will listen to you.

**13** You will seek me and find me, when you search for me with all your heart.

**14** I will let myself be found by you, declares the LORD. I will restore your fortunes[^29-12] and gather you from all the nations and from all the places where I have driven you, declares the LORD, and I will bring you back to the place from which I sent you into exile.

**15** Because you have said, "The LORD has raised up prophets for us in Babylon,"[^29-13]

**16** this is what the LORD says about the king who sits on David's throne, and about all the people who live in this city, your relatives who did not go out with you into exile:[^29-14]

**17** This is what the LORD of Armies says: I am going to send against them the sword, famine and plague, and I will make them like rotten[^29-15] figs that are too bad to be eaten.

**18** I will pursue them with the sword, famine and plague, and I will make them a horror to all the kingdoms of the earth, and a curse, a horror,[^29-16] a thing to hiss at and a disgrace among all the nations where I have driven them,

**19** because they did not listen to my words, declares the LORD, which I sent to them through my servants the prophets, sending them again and again.[^29-17] But you did not listen, declares the LORD.

**20** So you, hear the word of the LORD, all you exiles whom I sent from Jerusalem to Babylon.

**21** This is what the LORD of Armies, the God of Israel, says about Ahab son of Kolaiah and about Zedekiah son of Maaseiah, who are prophesying lies to you in my name: I am going to give them into the hand of Nebuchadnezzar[^29-18] king of Babylon, and he will strike them down before your eyes.

**22** Because of them all the exiles of Judah who are in Babylon will use this curse:[^29-19] "May the LORD make you like Zedekiah and Ahab, whom the king of Babylon roasted in the fire,"

**23** because they have done an outrageous thing in Israel. They have committed adultery with their neighbors' wives, and they have spoken lies in my name, words I did not command them. I am the one who knows, and I am a witness, declares the LORD.

**24** To Shemaiah the Nehelamite[^29-20] you are to say:

**25** This is what the LORD of Armies, the God of Israel, says: Because you sent letters in your own name to all the people in Jerusalem, to Zephaniah son of Maaseiah the priest and to all the priests, saying,[^29-21]

**26** "The LORD has made you priest in place of Jehoiada the priest, to have overseers in the house of the LORD for every madman who prophesies, to put him in the stocks and the collar.[^29-22]

**27** So now, why have you not rebuked Jeremiah of Anathoth, who is prophesying to you?

**28** For he has sent word to us in Babylon, saying, 'It will be a long time. Build houses and live in them; plant gardens and eat their produce.'"

**29** Zephaniah the priest read this letter in the hearing of Jeremiah the prophet.

**30** Then the word of the LORD came to Jeremiah:

**31** Send to all the exiles: This is what the LORD says about Shemaiah the Nehelamite: Because Shemaiah has prophesied to you, though I did not send him, and has made you trust in a lie,

**32** therefore this is what the LORD says: I am going to punish Shemaiah the Nehelamite and his descendants. He will have no one left living among this people, and he will not see the good that I am going to do for my people, declares the LORD, for he has preached rebellion against the LORD.[^29-23]

[^29-1]: Literally "to the rest of the elders of the exile".
[^29-2]: That is, Jehoiachin, taken into exile with his court in 597 BC (2 Kings 24:8–16).
[^29-3]: Hebrew *gevirah*, "great lady", the king's mother, Nehushta (2 Kings 24:8, 15; Jeremiah 13:18).
[^29-4]: Hebrew *sarisim*, court officials. The word can also mean eunuchs.
[^29-5]: Hebrew *masger*, perhaps "smith" or "locksmith" (2 Kings 24:14).
[^29-6]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles. *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. Also in verses 8, 17, 21 and 25.
[^29-7]: Hebrew *shalom*, "peace, well-being", three times in this verse. Also in verse 11.
[^29-8]: Literally "your dreams that you cause to be dreamed". The Hebrew form is unusual.
[^29-9]: Compare 25:11–12. Daniel 9:2 and 2 Chronicles 36:21 refer back to this prophecy.
[^29-10]: Hebrew *paqad*, "visit, attend to". The same verb often means "punish" (verse 32).
[^29-11]: Literally "an outcome and a hope".
[^29-12]: Literally "turn your turning", an idiom for restoring what was lost. Or "bring back your captives".
[^29-13]: Verse 15 leads into verses 21–23, which deal with the prophets in Babylon. The Septuagint does not have verses 16–20.
[^29-14]: The king is Zedekiah, and the city Jerusalem. Verses 16–19 take up the picture of the figs in chapter 24.
[^29-15]: Hebrew *sho'arim*, a rare word, perhaps "split open" or "disgusting".
[^29-16]: Two different Hebrew words are translated "horror" in this verse, *za'avah* and *shammah*. Hissing or whistling was a sound of shock or scorn.
[^29-17]: Literally "rising early and sending".
[^29-18]: Hebrew *Nevukhadre'tsar*: see 21:2. Verses 1 and 3 have *Nevukhadne'tsar*, as in chapters 27–28.
[^29-19]: Literally "From them a curse will be taken by all the exiles of Judah". A wordplay: *qelalah*, "curse", sounds like *qalam*, "roasted them".
[^29-20]: Perhaps "from Nehelam", a place otherwise unknown. The name sounds like *chalam*, "to dream" (verse 8).
[^29-21]: Shemaiah's letter is quoted in verses 26–28. The sentence that begins with "Because" is not completed; the sentence against Shemaiah is given in verses 31–32.
[^29-22]: Hebrew *mahpekhet*, "stocks" (20:2), and *tsinoq*, a rare word, perhaps an iron collar.
[^29-23]: The same words are used of Hananiah in 28:16. Compare Deuteronomy 13:6 (13:5 in most English Bibles).

## Chapter 30

*Status: draft*

**1** The word that came to Jeremiah from the LORD:[^30-1]

**2** This is what the LORD, the God of Israel, says: Write in a scroll all the words I have spoken to you.

**3** For look, the days are coming, declares the LORD, when I will restore the fortunes[^30-2] of my people Israel and Judah, says the LORD. I will bring them back to the land I gave their ancestors, and they will take possession of it.

**4** These are the words the LORD spoke concerning Israel and Judah.

**5** For this is what the LORD says: We have heard a cry of terror, of dread and not of peace.

**6** Ask now, and see: can a male give birth? Why then do I see every man with his hands on his loins like a woman in labor? Why has every face turned deathly pale?

**7** Woe! For that day is great; there is none like it. It is a time of distress for Jacob, yet he will be saved out of it.

**8** On that day, declares the LORD of Armies,[^30-3] I will break his yoke from off your neck,[^30-4] and I will tear off your bonds. Foreigners will no longer make him their slave.

**9** Instead they will serve the LORD their God and David their king, whom I will raise up for them.[^30-5]

**10** As for you, do not be afraid, Jacob my servant, declares the LORD; do not be dismayed, Israel. For I am going to save you from far away, and your descendants from the land of their captivity. Jacob will return and be at peace and secure, and no one will make him afraid.[^30-6]

**11** For I am with you, declares the LORD, to save you. I will make a full end of all the nations among which I have scattered you, but of you I will not make a full end. I will discipline you with justice,[^30-7] and I will by no means leave you unpunished.

**12** For this is what the LORD says: Your injury is incurable;[^30-8] your wound is beyond healing.

**13** There is no one to plead your cause, no remedy for your sore, no new skin for you.[^30-9]

**14** All your lovers have forgotten you; they do not seek you. For I have struck you as an enemy strikes, with the punishment of a cruel one, because your guilt is great and your sins are many.

**15** Why do you cry out over your injury? Your pain is incurable. Because your guilt is great and your sins are many, I have done these things to you.

**16** Therefore all who devour you will be devoured, and all your foes, every one of them, will go into captivity. Those who plunder you will become plunder, and all who prey on you I will give up as prey.

**17** For I will restore you to health[^30-10] and heal you of your wounds, declares the LORD, because they have called you an outcast: "That is Zion; no one seeks her."

**18** This is what the LORD says: I am going to restore the fortunes of the tents of Jacob and have compassion on his dwellings. The city will be rebuilt on its mound,[^30-11] and the palace will stand in its rightful place.

**19** From them will come songs of thanksgiving and the sound of people celebrating. I will multiply them, and they will not decrease; I will bring them honor, and they will not be made small.

**20** His children will be as they were long ago, and his community will be established before me. I will punish all who oppress him.

**21** His leader[^30-12] will be one of their own, and his ruler will come out from among them. I will bring him near, and he will approach me, for who would otherwise dare to approach me?[^30-13] declares the LORD.

**22** So you will be my people, and I will be your God.

**23** Look, the storm of the LORD! Wrath has gone out, a sweeping[^30-14] storm. It will whirl down on the head of the wicked.[^30-15]

**24** The fierce anger of the LORD will not turn back until he has carried out and accomplished the purposes of his heart. In the days to come[^30-16] you will understand this.

[^30-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles. Chapters 30–33 are often called the Book of Consolation, because they promise the return of Israel and Judah from exile.
[^30-2]: Literally "turn the turning", an idiom for restoring what was lost. Or "bring back the captives". Also in verse 18.
[^30-3]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel.
[^30-4]: The yoke is that of the king of Babylon (27:8–11; 28:10–14). The Hebrew moves between "you" and "him", both meaning Jacob.
[^30-5]: That is, a king from David's line (23:5; Ezekiel 34:23–24; Hosea 3:5).
[^30-6]: Verses 10–11 are repeated with small differences in 46:27–28. The Septuagint does not have them here.
[^30-7]: Or "in due measure". Hebrew *mishpat*, "justice, judgment".
[^30-8]: Hebrew *shever*, "breaking, fracture". Also in verse 15. In verses 12–17 Zion is addressed as a woman (verse 17).
[^30-9]: The Hebrew of this verse is difficult. Literally "There is no one judging your judgment for a sore; remedies, new flesh, there are none for you".
[^30-10]: Literally "bring up new flesh for you".
[^30-11]: Hebrew *tel*, the mound formed by the ruins of earlier settlements.
[^30-12]: Literally "his mighty one".
[^30-13]: Literally "for who is he who would pledge his heart to approach me?" To come near to God without being called was to risk one's life (Numbers 17:28, which is 17:13 in most English Bibles).
[^30-14]: Hebrew *mitgorer*, a rare word, perhaps "sweeping" or "gathering". The same lines in 23:19 have *mitcholel*, "whirling".
[^30-15]: Verses 23–24 are nearly the same as 23:19–20.
[^30-16]: Literally "in the latter end of the days".

## Chapter 31

*Status: draft*

**1** At that time, declares the LORD,[^31-1] I will be the God of all the clans of Israel, and they will be my people.

**2** This is what the LORD says: The people who survived the sword found favor in the wilderness, when Israel went to find its rest.[^31-2]

**3** The LORD appeared to me[^31-3] from far away: I have loved you with an everlasting love; therefore I have drawn you with faithful love.[^31-4]

**4** Again I will build you, and you will be built, virgin Israel. Again you will take up your tambourines and go out in the dances of those who celebrate.

**5** Again you will plant vineyards on the hills of Samaria; the planters will plant and enjoy the fruit.[^31-5]

**6** For there will be a day when watchmen will call out on the hills of Ephraim, "Come, let us go up to Zion, to the LORD our God!"[^31-6]

**7** For this is what the LORD says: Sing with joy for Jacob; shout for the chief of the nations. Proclaim it, give praise and say, "Save your people, LORD, the remnant of Israel!"[^31-7]

**8** Look, I am going to bring them from the land of the north and gather them from the farthest parts of the earth. Among them will be the blind and the lame, the pregnant woman and the woman in labor together. A great company will return here.

**9** They will come with weeping, and with pleas for mercy I will lead them. I will lead them beside streams of water, on a level path where they will not stumble. For I am a father to Israel, and Ephraim is my firstborn.

**10** Hear the word of the LORD, you nations, and declare it in the coastlands far away. Say, "He who scattered Israel will gather him and watch over him as a shepherd watches over his flock."

**11** For the LORD has ransomed Jacob and redeemed him[^31-8] from the hand of one stronger than he.

**12** They will come and sing for joy on the heights of Zion, and they will be radiant[^31-9] over the goodness of the LORD: over the grain, the new wine and the olive oil, and over the young of the flock and the herd. Their life will be like a well-watered garden, and they will never languish again.

**13** Then young women will rejoice in the dance, and young men and old men together. I will turn their mourning into gladness; I will comfort them and give them joy in place of their sorrow.

**14** I will satisfy the priests with abundance,[^31-10] and my people will be filled with my goodness, declares the LORD.

**15** This is what the LORD says: A voice is heard in Ramah,[^31-11] lamentation and bitter weeping. Rachel is weeping for her children; she refuses to be comforted for her children, because they are no more.[^31-12]

**16** This is what the LORD says: Keep your voice from weeping and your eyes from tears, for your work will be rewarded, declares the LORD. They will return from the land of the enemy.

**17** There is hope for your future, declares the LORD. Your children will return to their own territory.

**18** I have surely heard Ephraim rocking in grief: "You disciplined me, and I was disciplined, like a calf not trained to the yoke. Bring me back, so that I may come back, for you are the LORD my God.

**19** For after I turned away, I repented;[^31-13] after I was made to understand, I struck my thigh.[^31-14] I was ashamed and humiliated, because I bore the disgrace of my youth."

**20** Is Ephraim my dear son, my delightful child? For whenever I speak against him, I still remember him. Therefore my heart yearns for him;[^31-15] I will surely have compassion on him, declares the LORD.

**21** Set up road markers for yourself; put up signposts.[^31-16] Set your mind on the highway, the road you traveled.[^31-17] Return, virgin Israel; return to these cities of yours.

**22** How long will you waver, faithless daughter? For the LORD has created something new on the earth: a woman will surround a man.[^31-18]

**23** This is what the LORD of Armies,[^31-19] the God of Israel, says: Once more they will use these words in the land of Judah and in its cities, when I restore their fortunes:[^31-20] "May the LORD bless you, home of righteousness, holy mountain!"

**24** Judah and all its cities will live there together, the farmers and those who move about with the flocks.

**25** For I will refresh the weary and satisfy all who languish.[^31-21]

**26** At this I woke up and looked, and my sleep had been sweet to me.[^31-22]

**27** Look, the days are coming, declares the LORD, when I will sow the house of Israel and the house of Judah with the seed of human beings and the seed of animals.

**28** Just as I watched over them to uproot and to tear down, to overthrow and to destroy and to bring disaster, so I will watch over them to build and to plant, declares the LORD.[^31-23]

**29** In those days they will no longer say, "The fathers have eaten sour grapes, and the children's teeth are set on edge."[^31-24]

**30** Instead, each will die for his own guilt. Everyone who eats the sour grapes, his own teeth will be set on edge.

**31** Look, the days are coming, declares the LORD, when I will make a new covenant with the house of Israel and with the house of Judah.[^31-25]

**32** It will not be like the covenant I made with their ancestors on the day I took them by the hand to bring them out of the land of Egypt, my covenant that they broke, though I was their husband,[^31-26] declares the LORD.

**33** For this is the covenant I will make with the house of Israel after those days, declares the LORD: I will put my law[^31-27] within them, and I will write it on their hearts. I will be their God, and they will be my people.

**34** No longer will each one teach his neighbor and each his brother, saying, "Know the LORD," for they will all know me, from the least of them to the greatest, declares the LORD. For I will forgive their wrongdoing, and I will remember their sin no more.

**35** This is what the LORD says, who gives the sun for light by day, and decrees the moon and the stars[^31-28] for light by night, who stirs up the sea so that its waves roar; the LORD of Armies is his name:[^31-29]

**36** If these decrees ever depart from before me, declares the LORD, then the descendants of Israel will also cease to be a nation before me for all time.

**37** This is what the LORD says: If the heavens above can be measured and the foundations of the earth below can be searched out, then I will also reject all the descendants of Israel for all that they have done, declares the LORD.

**38** Look, the days are coming,[^31-30] declares the LORD, when the city will be rebuilt for the LORD from the Tower of Hananel to the Corner Gate.[^31-31]

**39** The measuring line will go out again straight ahead to the hill of Gareb, and then turn to Goah.[^31-32]

**40** The whole valley of the corpses and the ashes,[^31-33] and all the terraces as far as the Wadi Kidron, to the corner of the Horse Gate toward the east, will be holy to the LORD. It will never again be uprooted or torn down.

[^31-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^31-2]: The Hebrew is difficult. Literally "going to give him rest, Israel". Or "when I went to give Israel rest". The wilderness journey after the exodus is the model for the return from exile.
[^31-3]: The speaker is Israel. Or "From long ago the LORD appeared to me".
[^31-4]: Hebrew *chesed*: loyal, faithful love. Or "therefore I have prolonged my faithful love to you".
[^31-5]: Literally "and treat it as common", that is, eat its fruit as ordinary food. The fruit of a new vineyard was not eaten for its first three years, and the fourth year's fruit was holy (Leviticus 19:23–25).
[^31-6]: Ephraim was the leading tribe of the northern kingdom, whose people had not worshiped at Jerusalem since the kingdom divided (1 Kings 12:26–33).
[^31-7]: The Septuagint reads "The LORD has saved his people".
[^31-8]: Hebrew *ga'al*, to act as a kinsman who buys back a relative or his property.
[^31-9]: Or "they will stream".
[^31-10]: Literally "I will drench the soul of the priests with fat", the rich portions of the sacrifices that went to the priests.
[^31-11]: A town about 5 miles (8 km) north of Jerusalem. Rachel, the mother of Joseph and Benjamin and so the ancestor of Ephraim, was buried in that region (1 Samuel 10:2). The exiles were gathered at Ramah before they were taken to Babylon (40:1).
[^31-12]: Literally "because he is not". Matthew 2:18 quotes this verse.
[^31-13]: Or "relented". Hebrew *shuvi*, "my turning", which can mean turning away or turning back (see 3:12).
[^31-14]: A gesture of grief or remorse (Ezekiel 21:17; 21:12 in most English Bibles).
[^31-15]: Literally "my insides groan for him".
[^31-16]: Hebrew *tamrurim*, the same word as "bitter" in verse 15, here probably "guideposts".
[^31-17]: The Hebrew text is written "I traveled" but read "you traveled". The written form may be an old spelling of "you traveled" (compare 2:20, 33).
[^31-18]: The meaning of this line is uncertain. The words for *woman* (*neqevah*) and *man* (*gever*) stress female and male. It may mean that the woman will protect the man, or that she will seek him out, reversing the usual order.
[^31-19]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. Also in verse 35.
[^31-20]: Literally "turn their turning", an idiom for restoring what was lost. Or "bring back their captives".
[^31-21]: Literally "For I will drench the weary soul, and every languishing soul I will fill".
[^31-22]: The speaker is probably the prophet, waking from a dream or vision in which he received the words of verses 2–25. The meaning is uncertain.
[^31-23]: See 1:10–12.
[^31-24]: A proverb also quoted in Ezekiel 18:2. The children suffer for what the fathers did.
[^31-25]: Verses 31–34 are quoted in Hebrews 8:8–12, following the Septuagint, and verses 33–34 again in Hebrews 10:16–17. At the Last Supper Jesus speaks of the new covenant in his blood (Luke 22:20; 1 Corinthians 11:25).
[^31-26]: Or "their master". Hebrew *ba'alti*: see 3:14. The Septuagint, quoted in Hebrews 8:9, reads "and I did not care for them".
[^31-27]: Hebrew *torah*, "instruction, law".
[^31-28]: Literally "the decrees of the moon and the stars".
[^31-29]: The second half of this verse is the same as Isaiah 51:15. The Septuagint has verse 37 before verses 35–36.
[^31-30]: The word "coming" is read but not written in the Hebrew text.
[^31-31]: The Tower of Hananel was at the northeast corner of Jerusalem (Nehemiah 3:1; 12:39), and the Corner Gate at the northwest (2 Kings 14:13).
[^31-32]: Gareb and Goah are otherwise unknown. They probably lay to the west and south of the city.
[^31-33]: Probably the Valley of Ben-hinnom, south of Jerusalem (7:31–32). The *ashes* are the fat-soaked ashes of sacrifices.

## Chapter 32

*Status: draft*

**1** The word that came to Jeremiah from the LORD[^32-1] in the tenth year of Zedekiah king of Judah, which was the eighteenth year of Nebuchadnezzar.[^32-2]

**2** At that time the army of the king of Babylon was besieging Jerusalem, and Jeremiah the prophet was confined in the courtyard of the guard,[^32-3] which was in the palace of the king of Judah.

**3** For Zedekiah king of Judah had confined him, saying, "Why do you prophesy, saying, 'This is what the LORD says: I am going to give this city into the hand of the king of Babylon, and he will capture it.

**4** Zedekiah king of Judah will not escape from the hand of the Babylonians,[^32-4] but he will certainly be given into the hand of the king of Babylon. He will speak with him face to face and see him eye to eye.[^32-5]

**5** He will take Zedekiah to Babylon, and he will remain there until I attend to him,[^32-6] declares the LORD. Though you fight against the Babylonians, you will not succeed'?"

**6** Jeremiah said: The word of the LORD came to me:

**7** "Hanamel son of Shallum your uncle is going to come to you and say, 'Buy my field in Anathoth, for the right of redemption is yours to buy it.'"[^32-7]

**8** Then Hanamel my cousin[^32-8] came to me in the courtyard of the guard, just as the LORD had said, and he said to me, "Please buy my field in Anathoth, in the land of Benjamin, for the right of possession and of redemption is yours. Buy it for yourself." Then I knew that this was the word of the LORD.

**9** So I bought the field in Anathoth from Hanamel my cousin, and I weighed out the money for him, seventeen shekels[^32-9] of silver.

**10** I signed the deed[^32-10] and sealed it, had witnesses attest it, and weighed the money on scales.

**11** Then I took the deed of purchase, the sealed copy containing the terms and conditions,[^32-11] and the open copy,

**12** and I gave the deed of purchase to Baruch son of Neriah son of Mahseiah in the presence of Hanamel my cousin,[^32-12] and of the witnesses who had signed the deed of purchase, and of all the Judeans[^32-13] who were sitting in the courtyard of the guard.

**13** In their presence I charged Baruch:

**14** "This is what the LORD of Armies,[^32-14] the God of Israel, says: Take these documents, this deed of purchase, both the sealed copy and this open copy, and put them in a clay jar, so that they will last for a long time.

**15** For this is what the LORD of Armies, the God of Israel, says: Houses and fields and vineyards will again be bought in this land."

**16** After I had given the deed of purchase to Baruch son of Neriah, I prayed to the LORD:

**17** "Ah, Lord GOD![^32-15] You made the heavens and the earth by your great power and your outstretched arm. Nothing is too hard for you.

**18** You show faithful love[^32-16] to thousands, but you repay the guilt of the fathers into the laps of their children after them.[^32-17] Great and mighty God, whose name is the LORD of Armies,

**19** great in counsel and mighty in deed, your eyes are open to all the ways of human beings, to give each one according to his ways and according to the fruit of his deeds.

**20** You performed signs and wonders in the land of Egypt, and to this day you have done so in Israel and among all humankind, and you have made a name for yourself, as it is today.

**21** You brought your people Israel out of the land of Egypt with signs and wonders, with a strong hand and an outstretched arm, and with great terror.

**22** You gave them this land, which you swore to their ancestors to give them, a land flowing with milk and honey.

**23** They came in and took possession of it, but they did not listen to your voice or walk in your law.[^32-18] They did nothing of all you commanded them to do, so you have brought all this disaster on them.

**24** Look, the siege ramps have reached the city to capture it. Because of the sword, famine and plague, the city has been given into the hand of the Babylonians who are fighting against it. What you said has happened, and now you see it.

**25** Yet you, Lord GOD, have said to me, 'Buy the field with money and call witnesses,' though the city has been given into the hand of the Babylonians."

**26** Then the word of the LORD came to Jeremiah:

**27** Look, I am the LORD, the God of all humankind.[^32-19] Is anything too hard for me?

**28** Therefore this is what the LORD says: I am going to give this city into the hand of the Babylonians and into the hand of Nebuchadnezzar king of Babylon, and he will capture it.

**29** The Babylonians who are fighting against this city will come and set this city on fire and burn it, with the houses on whose roofs they have burned incense[^32-20] to Baal and poured out drink offerings to other gods to provoke me to anger.

**30** For the people of Israel and the people of Judah have done nothing but evil in my eyes from their youth. The people of Israel have done nothing but provoke me to anger by the work of their hands, declares the LORD.

**31** This city has roused my anger and my wrath from the day they built it until this day, so that I must remove it from my sight,

**32** because of all the evil that the people of Israel and the people of Judah have done to provoke me to anger, they, their kings, their officials, their priests and their prophets, the people of Judah and the inhabitants of Jerusalem.

**33** They have turned their backs to me and not their faces. Though I taught them again and again,[^32-21] they would not listen and accept discipline.

**34** They set up their detestable idols in the house that bears my name,[^32-22] to defile it.

**35** They built the high places of Baal in the Valley of Ben-hinnom, to hand over their sons and their daughters to Molech,[^32-23] something I did not command them, nor did it enter my mind, that they should do this detestable thing and cause Judah to sin.

**36** Now therefore this is what the LORD, the God of Israel, says concerning this city, of which you say, "It has been given into the hand of the king of Babylon by sword, famine and plague":

**37** I am going to gather them from all the lands where I have driven them in my anger, my wrath and great fury. I will bring them back to this place and let them live in safety.

**38** They will be my people, and I will be their God.

**39** I will give them one heart and one way, so that they will fear me always, for their own good and the good of their children after them.

**40** I will make with them an everlasting covenant, that I will not turn away from them,[^32-24] but will do them good. I will put the fear of me in their hearts, so that they will not turn away from me.

**41** I will rejoice over them to do them good, and I will plant them in this land in faithfulness, with all my heart and with all my soul.

**42** For this is what the LORD says: Just as I have brought all this great disaster on this people, so I am going to bring on them all the good that I promise them.

**43** Fields will again be bought in this land of which you say, "It is a desolation, without human beings or animals; it has been given into the hand of the Babylonians."

**44** People will buy fields for money, sign deeds, seal them and call witnesses, in the land of Benjamin, in the places around Jerusalem, in the cities of Judah, in the cities of the hill country, in the cities of the Shephelah[^32-25] and in the cities of the Negev,[^32-26] for I will restore their fortunes,[^32-27] declares the LORD.

[^32-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^32-2]: In 588 or 587 BC, during the Babylonian siege of Jerusalem, about a year before the city fell (39:1–2; 52:4–6).
[^32-3]: Hebrew *chatsar ha-mattarah*, a court of the palace where prisoners were kept under guard (37:21; 38:13, 28).
[^32-4]: Hebrew *Kasdim*, traditionally "Chaldeans": the people of southern Mesopotamia whose kings then ruled Babylon. Also in verses 5, 24–25, 28–29 and 43.
[^32-5]: Literally "His mouth will speak with his mouth, and his eyes will see his eyes". The Hebrew text is written "his eye" but read "his eyes" the second time.
[^32-6]: Or "until I punish him". Hebrew *paqad*, "visit, attend to" (29:10).
[^32-7]: When a member of a family had to sell land, his nearest relative had the right and the duty to buy it, so that it stayed in the family (Leviticus 25:25; Ruth 4:1–6).
[^32-8]: Literally "my uncle's son". Also in verse 9.
[^32-9]: A shekel is about ⅖ ounce (11.5 grams), so seventeen shekels is about 7 ounces (200 grams). Literally "seven shekels and ten of silver".
[^32-10]: Literally "I wrote in the document".
[^32-11]: Literally "the command and the decrees". One copy of the deed was rolled up and sealed, to keep it safe from tampering; the other was left open, to be read.
[^32-12]: The Hebrew has "my uncle", probably short for "my uncle's son" (verses 8–9).
[^32-13]: Hebrew *ha-yehudim*, the people of Judah.
[^32-14]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. Also in verses 15 and 18.
[^32-15]: Hebrew *Adonai YHWH*, "my Lord YHWH". After "Lord", God's personal name is written GOD in capitals, as in most English Bibles. Also in verse 25.
[^32-16]: Hebrew *chesed*: loyal, faithful love.
[^32-17]: Literally "into the bosom of their sons after them". Compare Exodus 20:5–6; 34:6–7.
[^32-18]: Hebrew *torah*, "instruction, law". The Hebrew text is written "your laws" but read "your law".
[^32-19]: Literally "all flesh".
[^32-20]: Or "burned offerings". The Hebrew verb *qatar* means to make something go up in smoke.
[^32-21]: Literally "teaching them, rising early and teaching".
[^32-22]: Literally "over which my name is called", that is, which belongs to me (7:10).
[^32-23]: Literally "to make pass over to Molech", that is, to sacrifice them by burning (7:31; 2 Kings 23:10). Molech was a god to whom children were offered (Leviticus 18:21).
[^32-24]: Literally "that I will not turn back from after them".
[^32-25]: The low hills between the coastal plain and the hill country of Judah.
[^32-26]: The dry region in the south of Judah.
[^32-27]: Literally "turn their turning", an idiom for restoring what was lost. Or "bring back their captives".

## Chapter 33

*Status: draft*

**1** The word of the LORD[^33-1] came to Jeremiah a second time, while he was still confined in the courtyard of the guard:

**2** This is what the LORD says, who made it, the LORD who formed it to establish it, the LORD is his name:[^33-2]

**3** Call to me, and I will answer you and tell you great and hidden things[^33-3] that you have not known.

**4** For this is what the LORD, the God of Israel, says about the houses of this city and the houses of the kings of Judah that have been torn down to make defenses against the siege ramps and against the sword:[^33-4]

**5** They are coming to fight the Babylonians,[^33-5] only to fill these houses with the corpses of the people I have struck down in my anger and my wrath, for I have hidden my face from this city because of all their evil.

**6** Look, I am going to bring it new flesh and healing. I will heal them and reveal to them an abundance[^33-6] of peace and faithfulness.

**7** I will restore the fortunes[^33-7] of Judah and the fortunes of Israel, and I will rebuild them as they were at first.

**8** I will cleanse them from all the guilt of their sin against me, and I will forgive all the guilt of their sin and their rebellion against me.

**9** This city will be to me a name of joy, a praise and a glory before all the nations of the earth, who will hear of all the good I do for them. They will fear and tremble because of all the good and all the peace that I provide for it.

**10** This is what the LORD says: In this place, of which you say, "It is a ruin, without human beings or animals," in the cities of Judah and the streets of Jerusalem that are desolate, without human beings, without inhabitants and without animals, there will be heard again

**11** the sound of joy and the sound of gladness, the voice of the bridegroom and the voice of the bride,[^33-8] and the voices of those who say, "Give thanks to the LORD of Armies,[^33-9] for the LORD is good; his faithful love[^33-10] endures forever!" as they bring thank offerings to the house of the LORD. For I will restore the fortunes of the land as they were at first, says the LORD.

**12** This is what the LORD of Armies says: In this place that is a ruin, without human beings or animals, and in all its cities, there will again be pasture for shepherds resting their flocks.

**13** In the cities of the hill country, in the cities of the Shephelah and in the cities of the Negev,[^33-11] in the land of Benjamin, in the places around Jerusalem and in the cities of Judah, flocks will again pass under the hands of the one who counts them, says the LORD.

**14** Look, the days are coming, declares the LORD, when I will fulfill the good promise I made to the house of Israel and the house of Judah.[^33-12]

**15** In those days and at that time I will cause a righteous Branch[^33-13] to sprout for David, and he will do justice and righteousness in the land.

**16** In those days Judah will be saved, and Jerusalem will live in safety. This is the name by which she will be called: The LORD Is Our Righteousness.[^33-14]

**17** For this is what the LORD says: David will never lack a man to sit on the throne of the house of Israel,[^33-15]

**18** and the Levitical priests will never lack a man before me to offer burnt offerings, to burn grain offerings and to make sacrifices for all time.

**19** The word of the LORD came to Jeremiah:

**20** This is what the LORD says: If you can break my covenant with the day and my covenant with the night, so that day and night no longer come at their appointed time,

**21** then my covenant with David my servant can also be broken, so that he will have no son to reign on his throne, and my covenant with the Levitical priests, my ministers.

**22** As the host of heaven cannot be counted and the sand of the sea cannot be measured, so I will multiply the descendants of David my servant and the Levites who minister to me.

**23** The word of the LORD came to Jeremiah:

**24** Have you not seen what this people have been saying: "The two clans that the LORD chose, he has rejected"?[^33-16] So they despise my people, and no longer regard them as a nation.

**25** This is what the LORD says: If I have not established my covenant with day and night, and the decrees of heaven and earth,

**26** then I will also reject the descendants of Jacob and of David my servant, and will not choose rulers from his descendants over the descendants of Abraham, Isaac and Jacob. For I will restore their fortunes and have compassion on them.

[^33-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^33-2]: *It* is probably the earth. The Septuagint reads "who made the earth".
[^33-3]: Literally "fortified things", that is, things out of reach.
[^33-4]: The Hebrew of verses 4–5 is difficult. Houses were pulled down to strengthen the city walls during the siege (compare Isaiah 22:10).
[^33-5]: Hebrew *Kasdim*, traditionally "Chaldeans": the people of southern Mesopotamia whose kings then ruled Babylon.
[^33-6]: Hebrew *ateret*, a rare word, perhaps "abundance" or "riches".
[^33-7]: Literally "turn the turning", an idiom for restoring what was lost. Or "bring back the captives". Also in verses 11 and 26.
[^33-8]: The sounds that the LORD had said he would silence (7:34; 16:9; 25:10).
[^33-9]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. Also in verse 12.
[^33-10]: Hebrew *chesed*: loyal, faithful love. The words of thanksgiving are a refrain of the Psalms (Psalm 106:1; 136:1).
[^33-11]: The Shephelah is the low hills between the coastal plain and the hill country of Judah, and the Negev the dry region in the south of Judah.
[^33-12]: Verses 14–26 are not in the Septuagint. Verses 14–16 repeat, with some differences, 23:5–6.
[^33-13]: Hebrew *tsemach*, "sprout, branch", a title of a coming king of David's line (23:5; Zechariah 3:8; 6:12).
[^33-14]: Hebrew *YHWH tsidqenu*. In 23:6 this is the name of the king; here it is the name of Jerusalem. It may play on the name of King Zedekiah, Hebrew *Tsidqiyyahu*, "The LORD is my righteousness".
[^33-15]: Compare 2 Samuel 7:16 and 1 Kings 2:4.
[^33-16]: The two clans are probably Israel and Judah, or perhaps the families of David and of Levi (verses 17–22).

## Chapter 34

*Status: draft*

**1** The word that came to Jeremiah from the LORD,[^34-1] when Nebuchadnezzar king of Babylon and all his army, all the kingdoms of the earth under his rule and all the peoples were fighting against Jerusalem and all its cities:[^34-2]

**2** This is what the LORD, the God of Israel, says: Go and speak to Zedekiah king of Judah and say to him: This is what the LORD says: I am going to give this city into the hand of the king of Babylon, and he will burn it with fire.

**3** You will not escape from his hand, but you will certainly be captured and given into his hand. You will see the king of Babylon eye to eye, and he will speak with you face to face.[^34-3] And you will go to Babylon.

**4** Yet hear the word of the LORD, Zedekiah king of Judah. This is what the LORD says about you: You will not die by the sword.

**5** You will die in peace. As they burned spices for your ancestors, the former kings who were before you, so they will burn spices for you[^34-4] and mourn for you, "Ah, master!"[^34-5] For I myself have spoken the word, declares the LORD.

**6** Jeremiah the prophet spoke all these words to Zedekiah king of Judah in Jerusalem,

**7** while the army of the king of Babylon was fighting against Jerusalem and against all the cities of Judah that were left, against Lachish and against Azekah.[^34-6] For these were the only fortified cities left of the cities of Judah.

**8** The word that came to Jeremiah from the LORD after King Zedekiah had made a covenant with all the people in Jerusalem to proclaim liberty[^34-7] to them,

**9** that each should set free his Hebrew slaves, male and female, so that no one would keep a fellow Judean[^34-8] as a slave.

**10** All the officials and all the people who had entered into the covenant agreed that each would set free his male and female slaves and not keep them as slaves any longer. They obeyed and set them free.

**11** But afterward they turned around and took back the male and female slaves they had set free, and forced them to be slaves again.

**12** Then the word of the LORD came to Jeremiah from the LORD:

**13** This is what the LORD, the God of Israel, says: I made a covenant with your ancestors when I brought them out of the land of Egypt, out of the house of slavery. I said,

**14** "At the end of seven years each of you must set free his fellow Hebrew who has sold himself to you. He is to serve you six years, and then you must set him free from your service."[^34-9] But your ancestors did not listen to me or pay attention.[^34-10]

**15** Recently[^34-11] you yourselves turned back and did what is right in my eyes, each of you proclaiming liberty to his neighbor. You made a covenant before me in the house that bears my name.[^34-12]

**16** But then you turned back and profaned my name. Each of you took back his male and female slaves, whom you had set free to go where they wished,[^34-13] and you forced them to be your slaves again.

**17** Therefore this is what the LORD says: You have not listened to me and proclaimed liberty, each to his brother and each to his neighbor. So I am going to proclaim liberty for you, declares the LORD, liberty to the sword, to plague and to famine. I will make you an object of terror to all the kingdoms of the earth.

**18** As for the men who transgressed my covenant, who did not keep the terms of the covenant they made before me, I will make them like the calf they cut in two and passed between its pieces,[^34-14]

**19** the officials of Judah and the officials of Jerusalem, the court officials,[^34-15] the priests and all the people of the land[^34-16] who passed between the pieces of the calf.

**20** I will give them into the hand of their enemies and into the hand of those who seek their lives. Their corpses will be food for the birds of the sky and the animals of the earth.

**21** Zedekiah king of Judah and his officials I will give into the hand of their enemies and into the hand of those who seek their lives, into the hand of the army of the king of Babylon, which has withdrawn from you.[^34-17]

**22** I am going to give the command, declares the LORD, and I will bring them back to this city. They will fight against it, capture it and burn it with fire. I will make the cities of Judah a desolation, with no one living in them.

[^34-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^34-2]: In 588 BC, after the siege of Jerusalem had begun (39:1; 52:4).
[^34-3]: Literally "Your eyes will see the eyes of the king of Babylon, and his mouth will speak with your mouth".
[^34-4]: Literally "As the burnings for your fathers ... so they will burn for you". A fire of spices was burned in honor of a king at his burial (2 Chronicles 16:14; 21:19).
[^34-5]: Hebrew *hoy adon*, a cry of mourning for the dead (22:18).
[^34-6]: Fortified towns in the Shephelah, southwest of Jerusalem.
[^34-7]: Hebrew *deror*, "release, liberty", the word used for the release proclaimed in the year of Jubilee (Leviticus 25:10). Also in verses 15 and 17.
[^34-8]: Hebrew *yehudi*, "a Judean". Literally "a Judean, his brother".
[^34-9]: Deuteronomy 15:12; compare Exodus 21:2. "At the end of seven years" is the wording of Deuteronomy 15:1.
[^34-10]: Literally "did not incline their ear".
[^34-11]: Literally "Today".
[^34-12]: Literally "over which my name is called", that is, which belongs to me (7:10).
[^34-13]: Literally "free, to their soul".
[^34-14]: The Hebrew is abrupt. Literally "I will give the men who transgressed my covenant ... the calf that they cut in two". A covenant could be made by walking between the halves of a slaughtered animal, calling on oneself the same fate if one broke it (compare Genesis 15:9–17). The Hebrew for "make a covenant" is literally "cut a covenant".
[^34-15]: Hebrew *sarisim*, court officials. The word can also mean eunuchs.
[^34-16]: Hebrew *am ha-arets*, the landowning citizens of Judah.
[^34-17]: The Babylonians had lifted the siege for a time when an Egyptian army approached (37:5–11).

## Chapter 35

*Status: draft*

**1** The word that came to Jeremiah from the LORD[^35-1] in the days of Jehoiakim son of Josiah king of Judah:[^35-2]

**2** "Go to the house of the Rechabites[^35-3] and speak with them. Bring them to the house of the LORD, into one of the rooms, and give them wine to drink."

**3** So I took Jaazaniah son of Jeremiah son of Habazziniah, his brothers and all his sons, the whole house of the Rechabites.

**4** I brought them into the house of the LORD, into the room of the sons of Hanan son of Igdaliah, the man of God.[^35-4] It was next to the room of the officials, above the room of Maaseiah son of Shallum, the keeper of the threshold.[^35-5]

**5** Then I set before the men of the house of the Rechabites bowls full of wine, and cups, and I said to them, "Drink wine."

**6** But they said, "We will not drink wine, for Jonadab son of Rechab, our ancestor,[^35-6] commanded us, 'You must never drink wine, neither you nor your children.

**7** You must not build houses, sow seed or plant vineyards, or own any of these. Instead you must live in tents all your days, so that you may live a long time in the land where you are staying as foreigners.'

**8** We have obeyed the voice of Jonadab son of Rechab, our ancestor, in all that he commanded us. We have not drunk wine all our days, we, our wives, our sons or our daughters,

**9** and we have not built houses to live in. We have no vineyard or field or seed.

**10** We have lived in tents, and we have obeyed and done everything that Jonadab our ancestor commanded us.

**11** But when Nebuchadnezzar king of Babylon came up against the land, we said, 'Come, let us go into Jerusalem to escape the army of the Babylonians[^35-7] and the army of the Arameans.' So we are living in Jerusalem."

**12** Then the word of the LORD came to Jeremiah:

**13** "This is what the LORD of Armies,[^35-8] the God of Israel, says: Go and say to the people of Judah and the inhabitants of Jerusalem: 'Will you not accept discipline and listen to my words? declares the LORD.

**14** The words of Jonadab son of Rechab, who commanded his descendants not to drink wine, have been kept. They have not drunk wine to this day, because they have obeyed their ancestor's command. But I have spoken to you again and again,[^35-9] and you have not listened to me.

**15** I have sent you all my servants the prophets, sending them again and again, to say: Turn now, each of you, from his evil way, and make your deeds good. Do not follow other gods to serve them. Then you will live in the land I gave to you and your ancestors. But you did not pay attention or listen to me.[^35-10]

**16** The descendants of Jonadab son of Rechab have kept the command their ancestor gave them, but this people has not listened to me.

**17** Therefore this is what the LORD, the God of Armies, the God of Israel, says:[^35-11] I am going to bring on Judah and on all the inhabitants of Jerusalem all the disaster I have pronounced against them, because I spoke to them, but they did not listen, and I called to them, but they did not answer.'"

**18** To the house of the Rechabites Jeremiah said, "This is what the LORD of Armies, the God of Israel, says: Because you have obeyed the command of Jonadab your ancestor, and kept all his commands, and done everything he commanded you,

**19** therefore this is what the LORD of Armies, the God of Israel, says: Jonadab son of Rechab will never lack a man to stand before me for all time."[^35-12]

[^35-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles. "The house of the LORD" is the temple.
[^35-2]: Jehoiakim reigned from 609 to 598 BC. The events of this chapter probably took place near the end of his reign (verse 11; 2 Kings 24:1–2).
[^35-3]: A clan descended from Rechab, related to the Kenites (1 Chronicles 2:55). Their ancestor Jonadab had supported Jehu in wiping out the worship of Baal (2 Kings 10:15–27). The *rooms* were chambers in the buildings around the temple courts.
[^35-4]: That is, a prophet. *The sons of Hanan* may be his disciples.
[^35-5]: One of three senior officials of the temple who guarded its entrances (52:24; 2 Kings 25:18).
[^35-6]: Literally "our father". The Hebrew spells his name both *Yonadav* (Jonadab) and *Yehonadav* (Jehonadab, as in 2 Kings 10:15). Also in verses 8, 10, 14, 16, 18 and 19.
[^35-7]: Hebrew *Kasdim*, traditionally "Chaldeans": the people of southern Mesopotamia whose kings then ruled Babylon.
[^35-8]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. Also in verses 18–19.
[^35-9]: Literally "rising early and speaking". Also "rising early and sending" in verse 15.
[^35-10]: Literally "you did not incline your ear".
[^35-11]: Hebrew *YHWH Elohei tseva'ot*, traditionally "the LORD God of hosts".
[^35-12]: To *stand before* the LORD is to serve him, as priests and prophets did (15:19; 1 Kings 17:1).

## Chapter 36

*Status: draft*

**1** In the fourth year of Jehoiakim son of Josiah king of Judah,[^36-1] this word came to Jeremiah from the LORD:[^36-2]

**2** "Take a scroll[^36-3] and write on it all the words I have spoken to you concerning Israel and Judah and all the nations, from the day I first spoke to you, in the days of Josiah, until today.

**3** Perhaps when the house of Judah hears of all the disaster I intend to bring on them, each of them will turn from his evil way, and I will forgive their wrongdoing and their sin."

**4** So Jeremiah called Baruch son of Neriah, and Baruch wrote on a scroll at Jeremiah's dictation[^36-4] all the words of the LORD that he had spoken to him.

**5** Then Jeremiah instructed Baruch, "I am restricted;[^36-5] I cannot go into the house of the LORD.

**6** So you are to go, and on a fast day read the words of the LORD from the scroll you have written at my dictation, in the hearing of the people in the house of the LORD. Read them also in the hearing of all the people of Judah who come in from their cities.

**7** Perhaps their plea will come before the LORD,[^36-6] and each of them will turn from his evil way, for great is the anger and the wrath that the LORD has pronounced against this people."

**8** Baruch son of Neriah did everything Jeremiah the prophet commanded him, reading the words of the LORD from the scroll in the house of the LORD.

**9** In the fifth year of Jehoiakim son of Josiah king of Judah, in the ninth month,[^36-7] all the people in Jerusalem and all the people who had come from the cities of Judah to Jerusalem proclaimed a fast before the LORD.

**10** Then Baruch read from the scroll the words of Jeremiah in the house of the LORD, in the room of Gemariah son of Shaphan the secretary,[^36-8] in the upper courtyard at the entrance of the New Gate of the house of the LORD, in the hearing of all the people.

**11** When Micaiah son of Gemariah son of Shaphan heard all the words of the LORD from the scroll,

**12** he went down to the king's palace, into the secretary's room, and all the officials were sitting there: Elishama the secretary, Delaiah son of Shemaiah, Elnathan son of Achbor,[^36-9] Gemariah son of Shaphan, Zedekiah son of Hananiah and all the other officials.

**13** Micaiah told them all the words he had heard when Baruch read from the scroll in the hearing of the people.

**14** Then all the officials sent Jehudi son of Nethaniah son of Shelemiah son of Cushi to Baruch to say, "Take in your hand the scroll you read in the hearing of the people, and come." So Baruch son of Neriah took the scroll in his hand and came to them.

**15** They said to him, "Sit down, please, and read it to us." So Baruch read it to them.

**16** When they heard all the words, they turned to one another in fear, and they said to Baruch, "We must report all these words to the king."

**17** Then they asked Baruch, "Tell us, please, how did you write all these words at his dictation?"

**18** Baruch said to them, "He dictated all these words to me,[^36-10] and I wrote them in ink on the scroll."

**19** Then the officials said to Baruch, "Go and hide, you and Jeremiah, and do not let anyone know where you are."

**20** They went in to the king in the courtyard, after leaving the scroll in the room of Elishama the secretary, and they reported all the words in the hearing of the king.

**21** The king sent Jehudi to get the scroll, and he took it from the room of Elishama the secretary. Jehudi read it in the hearing of the king and of all the officials who stood beside the king.

**22** The king was sitting in the winter house, for it was the ninth month, with a fire burning in the brazier[^36-11] before him.

**23** Whenever Jehudi had read three or four columns,[^36-12] the king[^36-13] would cut them off with a scribe's knife and throw them into the fire in the brazier, until the whole scroll was consumed in the fire in the brazier.

**24** Yet neither the king nor any of his servants who heard all these words was afraid, and they did not tear their clothes.[^36-14]

**25** Even when Elnathan, Delaiah and Gemariah pleaded with the king not to burn the scroll, he would not listen to them.

**26** The king commanded Jerahmeel the king's son,[^36-15] Seraiah son of Azriel and Shelemiah son of Abdeel to arrest Baruch the scribe and Jeremiah the prophet. But the LORD had hidden them.

**27** After the king had burned the scroll with the words that Baruch had written at Jeremiah's dictation, the word of the LORD came to Jeremiah:

**28** "Take another scroll and write on it all the former words that were on the first scroll, which Jehoiakim king of Judah burned.

**29** And concerning Jehoiakim king of Judah you are to say: 'This is what the LORD says: You burned this scroll, saying: Why have you written on it that the king of Babylon will certainly come and destroy this land and wipe out from it both human beings and animals?

**30** Therefore this is what the LORD says about Jehoiakim king of Judah: He will have no one to sit on the throne of David, and his corpse will be thrown out to the heat by day and the frost by night.[^36-16]

**31** I will punish him and his descendants and his servants for their wrongdoing. I will bring on them, on the inhabitants of Jerusalem and on the people of Judah all the disaster I pronounced against them, but they did not listen.'"

**32** So Jeremiah took another scroll and gave it to Baruch son of Neriah the scribe, and he wrote on it at Jeremiah's dictation all the words of the scroll that Jehoiakim king of Judah had burned in the fire. And many similar words were added to them.

[^36-1]: In 605 BC, the year of the Babylonian victory at Carchemish (25:1; 46:2).
[^36-2]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles. "The house of the LORD" is the temple.
[^36-3]: Literally "a scroll of a book".
[^36-4]: Literally "from the mouth of Jeremiah". Also in verses 6, 17, 27 and 32.
[^36-5]: Hebrew *atsur*, "held back, shut in". The reason is not given; compare 20:1–2 and 26:7–24.
[^36-6]: Literally "their plea will fall before the LORD".
[^36-7]: In November or December 604 BC.
[^36-8]: Shaphan was the royal secretary under Josiah (2 Kings 22:3–14). Another of his sons, Ahikam, had protected Jeremiah (26:24).
[^36-9]: See 26:22.
[^36-10]: Literally "From his mouth he would call out to me all these words".
[^36-11]: Hebrew *ach*, a brazier or firepot. Also in verse 23. The ninth month fell in November–December, at the start of the cold, rainy season.
[^36-12]: Hebrew *delatot*, literally "doors", the columns of writing on a scroll.
[^36-13]: Literally "he".
[^36-14]: Compare 2 Kings 22:11, where Josiah, Jehoiakim's father, tears his clothes when he hears the words of the book of the law.
[^36-15]: Or "a prince of the royal family". The title may also have been used of a royal officer.
[^36-16]: Compare 22:18–19. Jehoiakim's son Jehoiachin reigned only three months before he was taken into exile (2 Kings 24:6–15).

## Chapter 37

*Status: draft*

**1** Zedekiah son of Josiah reigned as king in place of Coniah[^37-1] son of Jehoiakim; Nebuchadnezzar king of Babylon made him king in the land of Judah.

**2** But neither he nor his servants nor the people of the land listened to the words of the LORD[^37-2] that he spoke through Jeremiah the prophet.

**3** King Zedekiah sent Jehucal son of Shelemiah and Zephaniah son of Maaseiah the priest to Jeremiah the prophet to say, "Please pray to the LORD our God for us."

**4** Now Jeremiah was still coming and going among the people, for they had not yet put him in prison.

**5** Pharaoh's army had come out of Egypt,[^37-3] and when the Babylonians[^37-4] who were besieging Jerusalem heard the report about them, they withdrew from Jerusalem.

**6** Then the word of the LORD came to Jeremiah the prophet:

**7** "This is what the LORD, the God of Israel, says: This is what you are to say to the king of Judah, who sent you to me to inquire of me: 'Pharaoh's army, which has come out to help you, is going back to its own land, to Egypt.

**8** The Babylonians will come back and fight against this city. They will capture it and burn it with fire.

**9** This is what the LORD says: Do not deceive yourselves, saying: The Babylonians will surely go away from us. For they will not go away.

**10** Even if you were to strike down the whole army of the Babylonians who are fighting against you, and only wounded men were left among them, each in his tent, they would get up and burn this city with fire.'"

**11** When the army of the Babylonians had withdrawn from Jerusalem because of Pharaoh's army,

**12** Jeremiah set out from Jerusalem to go to the land of Benjamin, to receive his share of property there among the people.[^37-5]

**13** When he reached the Benjamin Gate, a captain of the guard named Irijah son of Shelemiah son of Hananiah was there, and he arrested Jeremiah the prophet, saying, "You are deserting to the Babylonians!"

**14** Jeremiah said, "That is a lie! I am not deserting to the Babylonians." But he would not listen to him. Irijah arrested Jeremiah and brought him to the officials.

**15** The officials were furious with Jeremiah. They beat him and put him in prison in the house of Jonathan the secretary, for they had made it into a prison.

**16** So Jeremiah was put into the cistern house, into the vaulted cells,[^37-6] and Jeremiah remained there many days.

**17** Then King Zedekiah sent for him and had him brought, and the king questioned him secretly in his palace. He said, "Is there any word from the LORD?" Jeremiah said, "There is." And he said, "You will be given into the hand of the king of Babylon."

**18** Then Jeremiah said to King Zedekiah, "What wrong have I done to you or your servants or this people, that you have put me in prison?

**19** Where are your prophets who prophesied to you, 'The king of Babylon will not come against you or against this land'?

**20** Now please listen, my lord the king. Let my plea come before you:[^37-7] do not send me back to the house of Jonathan the secretary, or I will die there."

**21** So King Zedekiah gave orders, and they committed Jeremiah to the courtyard of the guard.[^37-8] He was given a loaf of bread each day from the bakers' street, until all the bread in the city was gone. So Jeremiah remained in the courtyard of the guard.

[^37-1]: That is, Jehoiachin (22:24), taken into exile in 597 BC (2 Kings 24:12–17).
[^37-2]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^37-3]: Probably the army of Pharaoh Hophra (44:30), in 588 BC.
[^37-4]: Hebrew *Kasdim*, traditionally "Chaldeans": the people of southern Mesopotamia whose kings then ruled Babylon. Also in verses 8–11 and 13–14.
[^37-5]: The meaning of the Hebrew *lachaloq*, "to divide, to take a share", is uncertain here. It may concern a family inheritance in Anathoth (compare 32:6–15).
[^37-6]: Hebrew *beit ha-bor*, "the house of the pit" or "cistern", and *chanuyot*, a rare word, perhaps "vaults" or "cells".
[^37-7]: Literally "Let my plea fall before you".
[^37-8]: See 32:2.

## Chapter 38

*Status: draft*

**1** Shephatiah son of Mattan, Gedaliah son of Pashhur, Jucal son of Shelemiah and Pashhur son of Malchiah[^38-1] heard the words that Jeremiah was speaking to all the people:

**2** "This is what the LORD[^38-2] says: Whoever stays in this city will die by the sword, famine and plague, but whoever goes out to the Babylonians[^38-3] will live. He will escape with his life,[^38-4] and live.

**3** This is what the LORD says: This city will certainly be given into the hand of the army of the king of Babylon, and he will capture it."

**4** Then the officials said to the king, "This man must be put to death, for he is discouraging[^38-5] the soldiers who are left in this city, and all the people, by speaking such words to them. This man is not seeking the well-being of this people, but their harm."

**5** King Zedekiah said, "He is in your hands, for the king can do nothing against you."

**6** So they took Jeremiah and threw him into the cistern of Malchiah the king's son, which was in the courtyard of the guard. They let Jeremiah down by ropes. There was no water in the cistern, only mud, and Jeremiah sank into the mud.

**7** Ebed-melech the Cushite,[^38-6] an official[^38-7] in the king's palace, heard that they had put Jeremiah into the cistern. The king was sitting in the Benjamin Gate.

**8** Ebed-melech went out from the king's palace and spoke to the king:

**9** "My lord the king, these men have done evil in all they have done to Jeremiah the prophet. They have thrown him into the cistern, and he will die where he is of hunger, for there is no more bread in the city."

**10** Then the king commanded Ebed-melech the Cushite, "Take thirty men with you from here, and pull Jeremiah the prophet up out of the cistern before he dies."

**11** So Ebed-melech took the men with him and went into the king's palace, to a place under the storeroom.[^38-8] He took from there some worn-out rags and worn-out clothes, and let them down by ropes to Jeremiah in the cistern.

**12** Ebed-melech the Cushite said to Jeremiah, "Put these worn-out rags and clothes under your armpits, under the ropes." Jeremiah did so.

**13** Then they pulled Jeremiah up with the ropes and brought him out of the cistern. And Jeremiah remained in the courtyard of the guard.

**14** King Zedekiah sent and had Jeremiah the prophet brought to him at the third entrance of the house of the LORD. The king said to Jeremiah, "I am going to ask you something. Do not hide anything from me."

**15** Jeremiah said to Zedekiah, "If I tell you, will you not surely put me to death? And if I give you advice, you will not listen to me."

**16** But King Zedekiah swore an oath to Jeremiah in secret: "As surely as the LORD lives, who has given us this life,[^38-9] I will not put you to death or hand you over to these men who seek your life."

**17** Then Jeremiah said to Zedekiah, "This is what the LORD, the God of Armies,[^38-10] the God of Israel, says: If you surrender[^38-11] to the officials of the king of Babylon, your life will be spared and this city will not be burned with fire; you and your household will live.

**18** But if you do not surrender to the officials of the king of Babylon, this city will be given into the hand of the Babylonians, and they will burn it with fire, and you yourself will not escape from their hand."

**19** King Zedekiah said to Jeremiah, "I am afraid of the Judeans[^38-12] who have deserted to the Babylonians, that I may be handed over to them and they will mistreat me."

**20** Jeremiah said, "They will not hand you over. Please obey the voice of the LORD in what I am telling you, and it will go well with you, and your life will be spared.

**21** But if you refuse to surrender, this is what the LORD has shown me:

**22** All the women who are left in the palace of the king of Judah will be brought out to the officials of the king of Babylon, and they will say, 'Your trusted friends[^38-13] misled you and overcame you. Now that your feet are sunk in the mud, they have turned back.'

**23** All your wives and your children will be brought out to the Babylonians, and you yourself will not escape from their hand. You will be seized by the hand of the king of Babylon, and this city will be burned with fire."[^38-14]

**24** Then Zedekiah said to Jeremiah, "Let no one know about this conversation, and you will not die.

**25** If the officials hear that I have spoken with you, and they come to you and say to you, 'Tell us what you said to the king. Do not hide it from us, and we will not put you to death. And what did the king say to you?'

**26** then say to them, 'I was presenting my plea to the king not to send me back to the house of Jonathan to die there.'"

**27** All the officials did come to Jeremiah and question him, and he told them just what the king had commanded. So they said no more to him, for no one had heard the conversation.

**28** And Jeremiah remained in the courtyard of the guard until the day Jerusalem was captured. This is what happened when Jerusalem was captured:[^38-15]

[^38-1]: Jucal is the Jehucal of 37:3, and Pashhur son of Malchiah is the official of 21:1.
[^38-2]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles. "The house of the LORD" in verse 14 is the temple.
[^38-3]: Hebrew *Kasdim*, traditionally "Chaldeans": the people of southern Mesopotamia whose kings then ruled Babylon. Also in verses 18–19 and 23.
[^38-4]: Literally "his life will be to him as plunder" (21:9).
[^38-5]: Literally "weakening the hands of".
[^38-6]: The name means "servant of the king". A Cushite was a man from Cush, the land on the upper Nile, south of Egypt (13:23).
[^38-7]: Hebrew *saris*, a court official. The word can also mean a eunuch.
[^38-8]: Literally "under the treasury".
[^38-9]: Literally "who made for us this soul".
[^38-10]: Hebrew *YHWH Elohei tseva'ot*, traditionally "the LORD God of hosts". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel.
[^38-11]: Literally "go out". Also in verses 18 and 21.
[^38-12]: Hebrew *ha-yehudim*, the people of Judah.
[^38-13]: Literally "the men of your peace", your allies (compare Obadiah 7). The women's words sound like a lament, perhaps a mocking one. Jeremiah had sunk into the mud of the cistern (verse 6); now the king will sink.
[^38-14]: Literally "and you will burn this city with fire", that is, you will be the cause of its burning. The same consonants can be read "and this city will be burned with fire".
[^38-15]: The second half of this verse leads into 39:3, after the dates given in 39:1–2.

## Chapter 39

*Status: draft*

**1** In the ninth year of Zedekiah king of Judah, in the tenth month, Nebuchadnezzar king of Babylon came against Jerusalem with his whole army and besieged it.[^39-1]

**2** In the eleventh year of Zedekiah, in the fourth month, on the ninth day of the month,[^39-2] the city wall was broken through.

**3** Then all the officials of the king of Babylon came in and sat in the Middle Gate: Nergal-sharezer, Samgar-nebo, Sarsechim the Rab-saris, Nergal-sharezer the Rab-mag, and all the rest of the officials of the king of Babylon.[^39-3]

**4** When Zedekiah king of Judah and all the soldiers saw them, they fled.[^39-4] They went out of the city by night by way of the king's garden, through the gate between the two walls, and he went off in the direction of the Arabah.[^39-5]

**5** But the Babylonian[^39-6] army pursued them and overtook Zedekiah in the plains of Jericho. They captured him and brought him up to Nebuchadnezzar king of Babylon at Riblah in the land of Hamath,[^39-7] and he passed sentence on him.

**6** The king of Babylon slaughtered Zedekiah's sons at Riblah before his eyes, and the king of Babylon slaughtered all the nobles of Judah.

**7** Then he put out Zedekiah's eyes and bound him in bronze shackles to take him to Babylon.

**8** The Babylonians burned the king's palace and the houses of the people with fire,[^39-8] and they tore down the walls of Jerusalem.

**9** Nebuzaradan the commander of the guard[^39-9] deported to Babylon the rest of the people who were left in the city, the deserters who had gone over to him, and the rest of the people who were left.

**10** But Nebuzaradan the commander of the guard left in the land of Judah some of the poor people, who owned nothing, and at that time he gave them vineyards and fields.

**11** Now Nebuchadnezzar king of Babylon had given orders about Jeremiah through Nebuzaradan the commander of the guard:

**12** "Take him and look after him. Do him no harm, but do for him whatever he tells you."

**13** So Nebuzaradan the commander of the guard, Nebushazban[^39-10] the Rab-saris, Nergal-sharezer the Rab-mag and all the chief officers of the king of Babylon sent

**14** and had Jeremiah taken from the courtyard of the guard. They entrusted him to Gedaliah son of Ahikam son of Shaphan, to take him home. So he stayed among the people.[^39-11]

**15** While Jeremiah was still confined in the courtyard of the guard, the word of the LORD[^39-12] had come to him:

**16** "Go and say to Ebed-melech the Cushite: 'This is what the LORD of Armies,[^39-13] the God of Israel, says: I am going to bring my words against this city for harm and not for good, and they will take place before your eyes on that day.

**17** But I will rescue you on that day, declares the LORD, and you will not be given into the hand of the men you fear.

**18** For I will surely save you, and you will not fall by the sword. You will escape with your life,[^39-14] because you have trusted in me, declares the LORD.'"

[^39-1]: In January 588 BC. Verses 1–2 and 4–10 are also told, more fully, in 52:4–16 and 2 Kings 25:1–12.
[^39-2]: In July 587 or 586 BC.
[^39-3]: The names and titles are uncertain, and the Hebrew may be divided differently. *Nergal-sharezer* is the Babylonian name Nergal-shar-usur; a man of that name later became king of Babylon (560–556 BC). *Samgar* may be a Babylonian title, and *Sarsechim* a name. *Rab-saris* means "chief official" (2 Kings 18:17), and *Rab-mag* is another high title, of uncertain meaning. Verse 3 completes the sentence begun in 38:28.
[^39-4]: The Septuagint does not have verses 4–13.
[^39-5]: The Jordan Valley.
[^39-6]: Hebrew *Kasdim*, traditionally "Chaldeans": the people of southern Mesopotamia whose kings then ruled Babylon. Also in verse 8.
[^39-7]: Riblah was on the Orontes River in Syria, about 200 miles (320 km) north of Jerusalem, where Nebuchadnezzar had his headquarters.
[^39-8]: Literally "the house of the people". 52:13 and 2 Kings 25:9 read "and all the houses of Jerusalem".
[^39-9]: Hebrew *rav-tabbachim*, literally "chief of the butchers" or "chief of the cooks", a title of the commander of the royal bodyguard. Also in verses 10–11 and 13.
[^39-10]: In the Hebrew text one letter of this name is written small, a scribal mark.
[^39-11]: 40:1–6 tells of Jeremiah's release in a different way: he was taken in chains with the other captives as far as Ramah, where Nebuzaradan set him free.
[^39-12]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^39-13]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel.
[^39-14]: Literally "your life will be to you as plunder" (21:9).

## Chapter 40

*Status: draft*

**1** The word that came to Jeremiah from the LORD,[^40-1] after Nebuzaradan the commander of the guard[^40-2] had released him at Ramah. He had taken him there in chains, among all the exiles of Jerusalem and Judah who were being taken into exile to Babylon.[^40-3]

**2** The commander of the guard took Jeremiah and said to him, "The LORD your God pronounced this disaster against this place.

**3** Now the LORD has brought it about; he has done as he said. Because you people sinned against the LORD and did not obey his voice, this has happened to you.

**4** But now, look, today I am freeing you from the chains on your hands. If you wish to come with me to Babylon, come, and I will look after you. But if you do not wish to come with me to Babylon, then don't. See, the whole land is before you; go wherever you think good and right."

**5** When Jeremiah still had not turned to go, he said,[^40-4] "Go back to Gedaliah son of Ahikam son of Shaphan, whom the king of Babylon has appointed over the cities of Judah, and stay with him among the people, or go wherever you think right." Then the commander of the guard gave him provisions and a gift, and let him go.

**6** So Jeremiah went to Gedaliah son of Ahikam at Mizpah[^40-5] and stayed with him among the people who were left in the land.

**7** All the commanders of the armed forces who were in the open country, they and their men, heard that the king of Babylon had appointed Gedaliah son of Ahikam over the land, and that he had put in his charge men, women and children, those of the poorest of the land who had not been deported to Babylon.[^40-6]

**8** So they came to Gedaliah at Mizpah: Ishmael son of Nethaniah, Johanan and Jonathan the sons of Kareah, Seraiah son of Tanhumeth, the sons of Ephai[^40-7] the Netophathite, and Jezaniah son of the Maacathite, they and their men.

**9** Gedaliah son of Ahikam son of Shaphan swore an oath to them and their men, and he said, "Do not be afraid to serve the Babylonians.[^40-8] Live in the land and serve the king of Babylon, and it will go well with you.

**10** As for me, I will stay at Mizpah to represent you before the Babylonians who come to us.[^40-9] But you, gather wine, summer fruit and oil, store them in your jars, and live in the towns you have taken over."

**11** Likewise all the Judeans[^40-10] who were in Moab, among the Ammonites, in Edom and in all the other lands heard that the king of Babylon had left a remnant in Judah, and that he had appointed Gedaliah son of Ahikam son of Shaphan over them.

**12** Then all the Judeans returned from all the places where they had been scattered and came to the land of Judah, to Gedaliah at Mizpah. And they gathered wine and summer fruit in great abundance.

**13** Johanan son of Kareah and all the commanders of the armed forces who were in the open country came to Gedaliah at Mizpah

**14** and said to him, "Do you know that Baalis king of the Ammonites has sent Ishmael son of Nethaniah to take your life?" But Gedaliah son of Ahikam did not believe them.

**15** Then Johanan son of Kareah said to Gedaliah in secret at Mizpah, "Let me go and kill Ishmael son of Nethaniah, and no one will know. Why should he take your life, so that all the Judeans who have gathered around you would be scattered and the remnant of Judah would perish?"

**16** But Gedaliah son of Ahikam said to Johanan son of Kareah, "Do not do this thing, for what you are saying about Ishmael is a lie."

[^40-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles. No word of the LORD to Jeremiah follows at once. The heading may introduce the whole account of chapters 40–44, in which such a word comes in 42:7.
[^40-2]: Hebrew *rav-tabbachim*, literally "chief of the butchers" or "chief of the cooks", a title of the commander of the royal bodyguard. Also in verses 2 and 5.
[^40-3]: Ramah was about 5 miles (8 km) north of Jerusalem (31:15). Compare 39:11–14.
[^40-4]: The Hebrew of this sentence is difficult. Literally "And he still would not turn back, 'And turn back to Gedaliah …'". "He said" is supplied.
[^40-5]: A town about 8 miles (13 km) north of Jerusalem, where the Babylonians now set their governor.
[^40-6]: Verses 7–9 are also told, more briefly, in 2 Kings 25:22–24, and 40:7–41:18 is summarized in 2 Kings 25:22–26.
[^40-7]: 2 Kings 25:23 has "Johanan son of Kareah", "Seraiah son of Tanhumeth the Netophathite" and "Jaazaniah son of the Maacathite". Netophah was a town near Bethlehem.
[^40-8]: Hebrew *Kasdim*, traditionally "Chaldeans": the people of southern Mesopotamia whose kings then ruled Babylon. Also in verse 10. 2 Kings 25:24 reads "Do not be afraid of the Babylonian officials".
[^40-9]: Literally "to stand before the Babylonians who come to us".
[^40-10]: Hebrew *ha-yehudim*, the people of Judah. Also in verses 12 and 15.

## Chapter 41

*Status: draft*

**1** In the seventh month,[^41-1] Ishmael son of Nethaniah son of Elishama, who was of royal descent and one of the king's chief officers,[^41-2] came with ten men to Gedaliah son of Ahikam at Mizpah. As they were eating a meal together there at Mizpah,

**2** Ishmael son of Nethaniah and the ten men who were with him got up and struck down Gedaliah son of Ahikam son of Shaphan with the sword and killed him, the man the king of Babylon had appointed over the land.

**3** Ishmael also struck down all the Judeans[^41-3] who were with Gedaliah at Mizpah, and the Babylonians[^41-4] who were there, the soldiers.

**4** On the day after Gedaliah was killed, before anyone knew of it,

**5** eighty men came from Shechem, from Shiloh and from Samaria, with their beards shaved off, their clothes torn and their bodies gashed,[^41-5] bringing grain offerings and frankincense to present at the house of the LORD.[^41-6]

**6** Ishmael son of Nethaniah went out from Mizpah to meet them, weeping as he went. When he met them, he said to them, "Come to Gedaliah son of Ahikam."

**7** But when they came into the city, Ishmael son of Nethaniah and the men who were with him slaughtered them and threw them into a cistern.[^41-7]

**8** But there were ten men among them who said to Ishmael, "Do not kill us, for we have stores of wheat and barley, oil and honey hidden in the field." So he held back and did not kill them with their companions.

**9** Now the cistern into which Ishmael threw all the corpses of the men he had struck down because of Gedaliah[^41-8] was the one King Asa had made for fear of Baasha king of Israel.[^41-9] Ishmael son of Nethaniah filled it with the slain.

**10** Then Ishmael took captive all the rest of the people who were in Mizpah, the king's daughters and all the people who were left at Mizpah, whom Nebuzaradan the commander of the guard[^41-10] had put in the charge of Gedaliah son of Ahikam. Ishmael son of Nethaniah took them captive and set out to cross over to the Ammonites.

**11** When Johanan son of Kareah and all the commanders of the armed forces who were with him heard of all the evil Ishmael son of Nethaniah had done,

**12** they took all their men and went to fight against Ishmael son of Nethaniah. They found him by the great pool[^41-11] in Gibeon.

**13** When all the people who were with Ishmael saw Johanan son of Kareah and all the commanders of the armed forces who were with him, they were glad.

**14** All the people Ishmael had taken captive from Mizpah turned around and went back to Johanan son of Kareah.

**15** But Ishmael son of Nethaniah escaped from Johanan with eight men and went to the Ammonites.

**16** Then Johanan son of Kareah and all the commanders of the armed forces who were with him took all the rest of the people from Mizpah whom he had recovered from Ishmael son of Nethaniah, after Ishmael had struck down Gedaliah son of Ahikam: the men who were soldiers, the women, the children and the court officials[^41-12] whom he had brought back from Gibeon.

**17** They went and stayed at Geruth-chimham,[^41-13] near Bethlehem, intending to go on into Egypt

**18** to escape the Babylonians. They were afraid of them, because Ishmael son of Nethaniah had struck down Gedaliah son of Ahikam, whom the king of Babylon had appointed over the land.

[^41-1]: The seventh month fell in September–October. The year is not given; it may have been the year Jerusalem fell (39:2; 52:12). After the exile a fast was kept in the seventh month, probably in memory of Gedaliah's murder (Zechariah 7:5; 8:19). Verses 1–3 are told more briefly in 2 Kings 25:25.
[^41-2]: The words "and one of the king's chief officers" are not in 2 Kings 25:25.
[^41-3]: Hebrew *ha-yehudim*, the people of Judah.
[^41-4]: Hebrew *Kasdim*, traditionally "Chaldeans": the people of southern Mesopotamia whose kings then ruled Babylon. Also in verse 18.
[^41-5]: Signs of mourning (16:6; 48:37), probably for the destruction of the temple.
[^41-6]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles. "The house of the LORD" is the temple, now in ruins.
[^41-7]: Literally "slaughtered them into the midst of the cistern".
[^41-8]: Literally "by the hand of Gedaliah". The Septuagint reads "was a great cistern".
[^41-9]: King Asa of Judah fortified Mizpah against Baasha of Israel (1 Kings 15:22).
[^41-10]: Hebrew *rav-tabbachim*, literally "chief of the butchers" or "chief of the cooks", a title of the commander of the royal bodyguard.
[^41-11]: Literally "the great waters" (compare 2 Samuel 2:13).
[^41-12]: Hebrew *sarisim*, court officials. The word can also mean eunuchs.
[^41-13]: Perhaps "the lodging place of Chimham". Chimham may be the son of Barzillai to whom David showed kindness (2 Samuel 19:38–41; 19:37–40 in most English Bibles).

## Chapter 42

*Status: draft*

**1** Then all the commanders of the armed forces, with Johanan son of Kareah and Jezaniah son of Hoshaiah,[^42-1] and all the people from the least to the greatest, came near

**2** and said to Jeremiah the prophet, "Please let our plea come before you,[^42-2] and pray to the LORD[^42-3] your God for us, for all this remnant. For we are only a few left out of many, as your own eyes can see.

**3** Pray that the LORD your God will tell us the way we should go and the thing we should do."

**4** Jeremiah the prophet said to them, "I have heard you. I will pray to the LORD your God as you ask, and whatever the LORD answers you I will tell you. I will keep nothing back from you."

**5** Then they said to Jeremiah, "May the LORD be a true and faithful witness against us if we do not do everything the LORD your God sends you to tell us.

**6** Whether it is good or bad, we will obey the voice of the LORD our God, to whom we are sending you, so that it may go well with us when we obey the voice of the LORD our God."

**7** At the end of ten days the word of the LORD came to Jeremiah.

**8** He called Johanan son of Kareah and all the commanders of the armed forces who were with him, and all the people from the least to the greatest,

**9** and said to them, "This is what the LORD, the God of Israel, to whom you sent me to present your plea before him, says:

**10** If you will stay in this land, I will build you up and not tear you down; I will plant you and not uproot you,[^42-4] for I relent[^42-5] of the disaster I have brought on you.

**11** Do not be afraid of the king of Babylon, whom you now fear. Do not be afraid of him, declares the LORD, for I am with you to save you and to rescue you from his hand.

**12** I will show you compassion, so that he will have compassion on you and let you return to your own land.

**13** But if you say, 'We will not stay in this land,' and so disobey the voice of the LORD your God,

**14** and say, 'No, we will go to the land of Egypt, where we will not see war or hear the sound of the ram's horn or be hungry for bread, and there we will live,'

**15** then hear the word of the LORD, remnant of Judah. This is what the LORD of Armies,[^42-6] the God of Israel, says: If you are determined to go to Egypt, and you go to live there,[^42-7]

**16** then the sword you fear will overtake you there in the land of Egypt, and the famine you dread will follow close after you there in Egypt, and there you will die.

**17** All the men who are determined to go to Egypt to live there will die by the sword, famine and plague. Not one of them will survive or escape the disaster I am going to bring on them.

**18** For this is what the LORD of Armies, the God of Israel, says: As my anger and my wrath were poured out on the inhabitants of Jerusalem, so my wrath will be poured out on you when you go to Egypt. You will become a curse, a horror, a curse and a disgrace,[^42-8] and you will never see this place again.

**19** The LORD has spoken to you, remnant of Judah: Do not go to Egypt. Know for certain that I have warned you today

**20** that you have gone astray at the cost of your lives.[^42-9] For you sent me to the LORD your God, saying, 'Pray for us to the LORD our God, and tell us whatever the LORD our God says, and we will do it.'

**21** So I have told you today, but you have not obeyed the voice of the LORD your God in anything he has sent me to tell you.

**22** Now know for certain that you will die by the sword, famine and plague in the place where you want to go to live."

[^42-1]: Perhaps the same man as Azariah son of Hoshaiah in 43:2.
[^42-2]: Literally "Please let our plea fall before you".
[^42-3]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^42-4]: See 1:10.
[^42-5]: Or "I am grieved". Hebrew *nicham*.
[^42-6]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. Also in verse 18.
[^42-7]: Hebrew *gur*, to live somewhere as a resident foreigner. Also in verses 17 and 22.
[^42-8]: Two different Hebrew words are translated "curse" in this verse, *alah* and *qelalah*.
[^42-9]: Or "you have deceived yourselves". Literally "you have erred in your souls".

## Chapter 43

*Status: draft*

**1** When Jeremiah had finished speaking to all the people all the words of the LORD[^43-1] their God, all these words that the LORD their God had sent him to tell them,

**2** Azariah son of Hoshaiah, Johanan son of Kareah and all the arrogant men said to Jeremiah, "You are telling a lie! The LORD our God has not sent you to say, 'Do not go to Egypt to live there.'

**3** Baruch son of Neriah is inciting you against us, to hand us over to the Babylonians,[^43-2] so that they will kill us or take us into exile in Babylon."

**4** So Johanan son of Kareah, all the commanders of the armed forces and all the people did not obey the voice of the LORD to stay in the land of Judah.

**5** Instead, Johanan son of Kareah and all the commanders of the armed forces took the whole remnant of Judah, who had come back to live in the land of Judah from all the nations where they had been scattered:

**6** the men, the women, the children, the king's daughters and everyone whom Nebuzaradan the commander of the guard[^43-3] had left with Gedaliah son of Ahikam son of Shaphan, and also Jeremiah the prophet and Baruch son of Neriah.

**7** They came into the land of Egypt, for they did not obey the voice of the LORD, and they went as far as Tahpanhes.[^43-4]

**8** Then the word of the LORD came to Jeremiah in Tahpanhes:

**9** "Take some large stones in your hands and bury them in the mortar of the brick pavement[^43-5] at the entrance of Pharaoh's palace[^43-6] in Tahpanhes, while the men of Judah watch.

**10** Then say to them: 'This is what the LORD of Armies,[^43-7] the God of Israel, says: I am going to send for my servant Nebuchadnezzar king of Babylon, and I will set his throne over these stones I have buried, and he will spread his canopy[^43-8] over them.

**11** He will come and strike the land of Egypt, giving over to death those destined for death, to captivity those destined for captivity, and to the sword those destined for the sword.[^43-9]

**12** I will set fire to the temples of the gods of Egypt, and he will burn them and carry their gods away captive. He will wrap himself in the land of Egypt as a shepherd wraps himself in his cloak,[^43-10] and he will go away from there in peace.

**13** He will smash the sacred pillars of Beth-shemesh[^43-11] in the land of Egypt, and he will burn the temples of the gods of Egypt with fire.'"

[^43-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^43-2]: Hebrew *Kasdim*, traditionally "Chaldeans": the people of southern Mesopotamia whose kings then ruled Babylon.
[^43-3]: Hebrew *rav-tabbachim*, literally "chief of the butchers" or "chief of the cooks", a title of the commander of the royal bodyguard.
[^43-4]: A fortress city in the eastern Nile delta (2:16).
[^43-5]: The meaning of the Hebrew words *melet*, perhaps "mortar" or "clay", and *malben*, perhaps "brickwork" or "brick terrace", is uncertain.
[^43-6]: Literally "Pharaoh's house", perhaps a royal residence or government building.
[^43-7]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel.
[^43-8]: Hebrew *shafrir*, a rare word, perhaps a royal canopy or carpet.
[^43-9]: Compare 15:2. Nebuchadnezzar campaigned against Egypt in 568–567 BC.
[^43-10]: Or "He will pick the land of Egypt clean as a shepherd picks lice from his cloak". The meaning of the verb *atah* is uncertain here.
[^43-11]: "House of the Sun", that is, Heliopolis (Egyptian *On*), the city of the sun god, near modern Cairo. Its *pillars* were probably obelisks.

## Chapter 44

*Status: draft*

**1** The word that came to Jeremiah concerning all the Judeans[^44-1] living in the land of Egypt, those living at Migdol, at Tahpanhes, at Memphis and in the land of Pathros:[^44-2]

**2** This is what the LORD of Armies,[^44-3] the God of Israel, says: You have seen all the disaster I brought on Jerusalem and on all the cities of Judah. Look, today they are a ruin, with no one living in them,

**3** because of the evil they did to provoke me to anger, by going to burn incense[^44-4] and to serve other gods that they had not known, neither they, nor you, nor your ancestors.

**4** I sent you all my servants the prophets again and again,[^44-5] saying, "Do not do this detestable thing that I hate!"

**5** But they did not listen or pay attention;[^44-6] they did not turn from their evil and stop burning incense to other gods.

**6** So my wrath and my anger were poured out and burned in the cities of Judah and in the streets of Jerusalem, and they became a ruin and a desolation, as they are today.

**7** And now this is what the LORD, the God of Armies,[^44-7] the God of Israel, says: Why are you doing such great harm to yourselves, cutting off from Judah man and woman, child and infant, so that you leave yourselves no remnant?

**8** Why do you provoke me to anger with the works of your hands, burning incense to other gods in the land of Egypt where you have come to live, so that you will be cut off and become a curse and a disgrace among all the nations of the earth?

**9** Have you forgotten the evil deeds of your ancestors, the evil deeds of the kings of Judah and the evil deeds of their wives,[^44-8] your own evil deeds and the evil deeds of your wives, which they committed in the land of Judah and in the streets of Jerusalem?

**10** To this day they have not humbled themselves,[^44-9] nor have they shown fear or walked in my law[^44-10] and my decrees that I set before you and your ancestors.

**11** Therefore this is what the LORD of Armies, the God of Israel, says: I am going to set my face against you for harm, to cut off all Judah.

**12** I will take the remnant of Judah who set their faces to go to the land of Egypt to live there, and they will all come to an end. In the land of Egypt they will fall; by the sword and by famine they will come to an end. From the least to the greatest they will die by the sword and by famine. They will become a curse, a horror, a curse and a disgrace.[^44-11]

**13** I will punish those who live in the land of Egypt as I punished Jerusalem, with the sword, famine and plague.

**14** None of the remnant of Judah who have come to live in the land of Egypt will escape or survive to return to the land of Judah, where they long[^44-12] to return to live. For none will return except a few fugitives.

**15** Then all the men who knew that their wives were burning incense to other gods, and all the women who stood by, a great assembly, and all the people who lived in the land of Egypt, in Pathros, answered Jeremiah:

**16** "As for the word you have spoken to us in the name of the LORD, we will not listen to you.

**17** Instead we will certainly do everything we have vowed:[^44-13] we will burn incense to the Queen of Heaven[^44-14] and pour out drink offerings to her, as we did, we and our ancestors, our kings and our officials, in the cities of Judah and in the streets of Jerusalem. For then we had plenty of food, and we were well off and saw no disaster.

**18** But since we stopped burning incense to the Queen of Heaven and pouring out drink offerings to her, we have lacked everything, and we have been consumed by the sword and by famine.

**19** And when we burned incense to the Queen of Heaven and poured out drink offerings to her, was it without our husbands' consent[^44-15] that we made cakes for her bearing her image,[^44-16] and poured out drink offerings to her?"

**20** Then Jeremiah said to all the people, to the men and the women and all the people who had given him this answer,

**21** "As for the incense you burned in the cities of Judah and in the streets of Jerusalem, you and your ancestors, your kings, your officials and the people of the land,[^44-17] did not the LORD remember it? Did it not come into his mind?

**22** The LORD could no longer bear your evil deeds and the detestable things you did. So your land became a ruin, a horror and a curse, without inhabitant, as it is today.

**23** It is because you burned incense and sinned against the LORD, and did not obey the voice of the LORD or walk in his law, his decrees and his statutes,[^44-18] that this disaster has come upon you, as it is today."

**24** Then Jeremiah said to all the people and to all the women, "Hear the word of the LORD, all you people of Judah who are in the land of Egypt.

**25** This is what the LORD of Armies, the God of Israel, says: You and your wives[^44-19] have spoken with your mouths and fulfilled it with your hands, saying, 'We will certainly carry out the vows we have made, to burn incense to the Queen of Heaven and pour out drink offerings to her.' Go ahead then, keep your vows! Carry out your vows!

**26** Therefore hear the word of the LORD, all you people of Judah who live in the land of Egypt: I have sworn by my great name, says the LORD, that my name will never again be invoked by any man of Judah in all the land of Egypt, saying, 'As surely as the Lord GOD[^44-20] lives.'

**27** I am watching over them[^44-21] for harm and not for good. All the people of Judah who are in the land of Egypt will come to an end by the sword and by famine until they are all gone.

**28** Those who escape the sword will return from the land of Egypt to the land of Judah, few in number. Then the whole remnant of Judah who came to the land of Egypt to live there will know whose word will stand, mine or theirs.

**29** This will be the sign to you, declares the LORD, that I will punish you in this place, so that you will know that my words against you will surely stand for harm:

**30** This is what the LORD says: I am going to give Pharaoh Hophra king of Egypt into the hand of his enemies, into the hand of those who seek his life, just as I gave Zedekiah king of Judah into the hand of Nebuchadnezzar king of Babylon, his enemy who sought his life."[^44-22]

[^44-1]: Hebrew *ha-yehudim*, the people of Judah.
[^44-2]: Migdol and Tahpanhes were in the eastern Nile delta; Memphis (Hebrew *Noph*) was the old capital of Lower Egypt (2:16). Pathros is Upper Egypt, the Nile valley to the south.
[^44-3]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles. *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. Also in verses 11 and 25.
[^44-4]: Or "burn offerings". The Hebrew verb *qatar* means to make something go up in smoke. Also in verses 5, 8, 15, 17–19, 21, 23 and 25.
[^44-5]: Literally "rising early and sending".
[^44-6]: Literally "did not incline their ear".
[^44-7]: Hebrew *YHWH Elohei tseva'ot*, traditionally "the LORD God of hosts".
[^44-8]: Literally "his wives".
[^44-9]: Literally "they have not been crushed".
[^44-10]: Hebrew *torah*, "instruction, law". Also in verse 23.
[^44-11]: Two different Hebrew words are translated "curse" in this verse, *alah* and *qelalah* (42:18).
[^44-12]: Literally "lift up their soul".
[^44-13]: Literally "every word that has gone out of our mouth".
[^44-14]: See 7:18.
[^44-15]: Literally "without our men". A vow made by a wife stood only if her husband did not overrule it (Numbers 30:7–16, which is 30:6–15 in most English Bibles). The women speak in this verse.
[^44-16]: Hebrew *kavvanim*, a word used only here and in 7:18, a kind of cake. The meaning of the words "bearing her image" is uncertain.
[^44-17]: Hebrew *am ha-arets*, the landowning citizens of Judah.
[^44-18]: Hebrew *edot*, traditionally "testimonies": the solemn terms of the covenant.
[^44-19]: In the Hebrew the verbs that follow are feminine: the women are addressed.
[^44-20]: Hebrew *Adonai YHWH*, "my Lord YHWH". After "Lord", God's personal name is written GOD in capitals, as in most English Bibles.
[^44-21]: Hebrew *shoqed*, the word used in 1:12.
[^44-22]: Hophra (Egyptian Wahibre, Greek Apries) ruled Egypt from 589 to 570 BC. He was overthrown by his general Amasis, and later killed.

## Chapter 45

*Status: draft*

**1** The word that Jeremiah the prophet spoke to Baruch son of Neriah, when he wrote these words in a scroll at Jeremiah's dictation,[^45-1] in the fourth year of Jehoiakim son of Josiah king of Judah:[^45-2]

**2** This is what the LORD,[^45-3] the God of Israel, says to you, Baruch:

**3** You said, "Woe is me! For the LORD has added sorrow to my pain. I am worn out with my groaning, and I find no rest."

**4** This is what you are to say to him:[^45-4] This is what the LORD says: What I have built I am tearing down, and what I have planted I am uprooting, the whole land.[^45-5]

**5** And you, are you seeking great things for yourself? Do not seek them. For I am going to bring disaster on all humankind,[^45-6] declares the LORD, but I will let you escape with your life[^45-7] wherever you go.

[^45-1]: Literally "from the mouth of Jeremiah".
[^45-2]: In 605 BC, the year Baruch wrote the scroll described in 36:1–8.
[^45-3]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^45-4]: The LORD now speaks to Jeremiah, telling him what to say to Baruch.
[^45-5]: Literally "and the whole land, it". See 1:10.
[^45-6]: Literally "all flesh".
[^45-7]: Literally "I will give you your life as plunder" (21:9).

## Chapter 46

*Status: draft*

**1** The word of the LORD[^46-1] that came to Jeremiah the prophet concerning the nations.[^46-2]

**2** Concerning Egypt. About the army of Pharaoh Neco king of Egypt, which was by the Euphrates River at Carchemish, and which Nebuchadnezzar king of Babylon defeated in the fourth year of Jehoiakim son of Josiah king of Judah:[^46-3]

**3** Prepare shield and buckler,[^46-4] and advance to battle!

**4** Harness the horses; mount, you horsemen![^46-5] Take your positions with helmets on! Polish the spears; put on your armor!

**5** Why do I see them terrified, falling back? Their warriors are beaten down; they flee headlong and do not look back. Terror on every side![^46-6] declares the LORD.

**6** The swift cannot flee, nor the warrior escape. In the north, by the Euphrates River, they stumble and fall.

**7** Who is this, rising like the Nile,[^46-7] like rivers whose waters surge?

**8** Egypt rises like the Nile, like rivers whose waters surge. He says, "I will rise and cover the earth; I will destroy cities and those who live in them."

**9** Go up, you horses! Drive furiously, you chariots! Let the warriors go out: Cush and Put, who carry the shield, and the Ludim, who draw the bow.[^46-8]

**10** That day belongs to the Lord GOD of Armies,[^46-9] a day of vengeance, to avenge himself on his foes. The sword will devour and be satisfied, and drink its fill of their blood. For the Lord GOD of Armies holds a sacrifice in the land of the north, by the Euphrates River.

**11** Go up to Gilead and get balm,[^46-10] virgin Daughter Egypt! In vain you have used many medicines;[^46-11] there is no healing for you.

**12** The nations have heard of your shame; your cry fills the earth. For warrior has stumbled against warrior; both have fallen together.

**13** The word that the LORD spoke to Jeremiah the prophet about the coming of Nebuchadnezzar king of Babylon to strike the land of Egypt:[^46-12]

**14** Declare it in Egypt, proclaim it in Migdol, proclaim it in Memphis and in Tahpanhes.[^46-13] Say: Take your stand and get ready, for the sword devours those around you.

**15** Why has your mighty one been swept away?[^46-14] He did not stand, because the LORD drove him down.

**16** He made many stumble; they fell, each against the other. They said, "Get up, let us go back to our own people and to the land of our birth, away from the sword of the oppressor."[^46-15]

**17** There they cried out, "Pharaoh king of Egypt is only a noise; he has let the appointed time pass by."[^46-16]

**18** As surely as I live, declares the King, whose name is the LORD of Armies, one will come like Tabor among the mountains, and like Carmel by the sea.[^46-17]

**19** Pack your bags for exile, you who live there, Daughter Egypt, for Memphis will become a desolation, burned[^46-18] and empty of inhabitants.

**20** Egypt is a beautiful heifer, but a gadfly[^46-19] from the north has come, has come!

**21** Even her hired soldiers in her midst are like fattened calves. They too have turned and fled together; they did not stand. For the day of their calamity has come upon them, the time of their punishment.

**22** Her sound is like a snake slithering away,[^46-20] for they march on in force; they come against her with axes, like those who cut down trees.

**23** They will cut down her forest, declares the LORD, though it cannot be searched through,[^46-21] for they are more numerous than locusts; they cannot be counted.

**24** Daughter Egypt is put to shame; she is given into the hand of the people of the north.

**25** The LORD of Armies, the God of Israel, says: I am going to punish Amon of Thebes,[^46-22] and Pharaoh and Egypt, her gods and her kings, Pharaoh and those who trust in him.

**26** I will give them into the hand of those who seek their lives, into the hand of Nebuchadnezzar king of Babylon and his servants. But afterward Egypt will be inhabited as in days of old, declares the LORD.

**27** As for you, do not be afraid, Jacob my servant; do not be dismayed, Israel. For I am going to save you from far away, and your descendants from the land of their captivity. Jacob will return and be at peace and secure, and no one will make him afraid.[^46-23]

**28** As for you, do not be afraid, Jacob my servant, declares the LORD, for I am with you. I will make a full end of all the nations where I have driven you, but of you I will not make a full end. I will discipline you with justice,[^46-24] and I will by no means leave you unpunished.

[^46-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^46-2]: Verse 1 is the heading of the oracles against the nations in chapters 46–51. In the Septuagint they come after 25:13 (see the note there), and in a different order: Elam (49:34–39), Egypt (46), Babylon (50–51), the Philistines (47), Edom (49:7–22), Ammon (49:1–6), Kedar (49:28–33), Damascus (49:23–27) and Moab (48).
[^46-3]: In 605 BC. Carchemish was on the upper Euphrates, on the present border of Turkey and Syria. Four years earlier Neco had killed King Josiah at Megiddo (2 Kings 23:29).
[^46-4]: Hebrew *magen*, a small round shield, and *tsinnah*, a large shield that covered the whole body.
[^46-5]: Or "mount the stallions".
[^46-6]: Hebrew *magor missaviv*: see 6:25.
[^46-7]: Hebrew *ye'or*, the Nile, which rose in flood each year. Also in verse 8.
[^46-8]: Literally "who grasp, who bend the bow". Cush was the land south of Egypt, and Put was probably Libya. The Ludim may be Lydians from Asia Minor. All served in Egypt's army.
[^46-9]: Hebrew *Adonai YHWH tseva'ot*, "my Lord YHWH of Armies". *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. *The LORD of Armies* is also in verses 18 and 25.
[^46-10]: See 8:22.
[^46-11]: The Hebrew text is written "I have used many medicines" but read "you have used many medicines". The written form may be an old spelling of "you have used" (compare 2:20, 33).
[^46-12]: Compare 43:8–13.
[^46-13]: See 44:1.
[^46-14]: Hebrew *abbirekha*, "your mighty one", a word also used of a bull. The Septuagint divides the letters differently and reads "Why has Apis fled? Your chosen calf did not stand." Apis was the sacred bull worshiped at Memphis.
[^46-15]: Or "the cruel sword". Hebrew *ha-yonah*, perhaps "the oppressor" (25:38; 50:16).
[^46-16]: Or, with the same consonants, "Call Pharaoh king of Egypt by the name 'Big Noise, who let the appointed time pass by'." The Hebrew *sha'on*, "noise, uproar", may mock a royal title.
[^46-17]: Mount Tabor rises alone above the plain of Jezreel, and Mount Carmel above the Mediterranean coast. The one who comes is the king of Babylon.
[^46-18]: Or "laid waste".
[^46-19]: Hebrew *qerets*, a rare word, perhaps "gadfly" or "horsefly".
[^46-20]: Literally "Her sound goes like a snake". Egypt hisses and slips away as the enemy advances.
[^46-21]: Or "though it is impenetrable".
[^46-22]: Amon was the chief god of Thebes (Hebrew *No*), the great city of Upper Egypt.
[^46-23]: Verses 27–28 repeat 30:10–11 with small differences.
[^46-24]: Or "in due measure". Hebrew *mishpat*, "justice, judgment".

## Chapter 47

*Status: draft*

**1** The word of the LORD[^47-1] that came to Jeremiah the prophet concerning the Philistines, before Pharaoh struck Gaza.[^47-2]

**2** This is what the LORD says: Look, waters are rising from the north; they will become an overflowing torrent. They will overflow the land and everything in it, the city and those who live in it. People will cry out, and all who live in the land will wail.

**3** At the sound of the stamping hooves of his stallions, at the rumble of his chariots and the clatter of their wheels, fathers will not turn back for their children, because their hands hang limp.[^47-3]

**4** For the day is coming to destroy all the Philistines, to cut off from Tyre and Sidon every helper who survives. For the LORD is destroying the Philistines, the remnant of the coastland of Caphtor.[^47-4]

**5** Baldness has come upon Gaza;[^47-5] Ashkelon is silenced. Remnant of their valley,[^47-6] how long will you gash yourself?

**6** Ah,[^47-7] sword of the LORD! How long until you are quiet? Go back into your sheath; rest and be still.

**7** How can it be quiet,[^47-8] when the LORD has given it a command? Against Ashkelon and against the seacoast, there he has appointed it.

[^47-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^47-2]: The occasion is not known. Gaza, Ashkelon and the other Philistine cities lay on the coastal plain southwest of Judah.
[^47-3]: Literally "because of the slackness of hands".
[^47-4]: Caphtor is probably Crete, from which the Philistines had come (Amos 9:7; Deuteronomy 2:23). Hebrew *i*, "coastland, island".
[^47-5]: The head was shaved in mourning (16:6; 48:37).
[^47-6]: Hebrew *imqam*, "their valley", perhaps the coastal plain. The Septuagint reads "the remnant of the Anakim", the giants of old who had lived in the Philistine cities (Joshua 11:22).
[^47-7]: Hebrew *hoy*, translated "Woe to" in 22:13, here a cry of lament.
[^47-8]: Literally "How can you be quiet".

## Chapter 48

*Status: draft*

**1** Concerning Moab. This is what the LORD of Armies,[^48-1] the God of Israel, says: Woe to Nebo,[^48-2] for it is devastated! Kiriathaim is put to shame and captured; the stronghold[^48-3] is put to shame and shattered.

**2** Moab's renown is no more. In Heshbon they have planned disaster against her:[^48-4] "Come, let us cut her off from being a nation." You too, Madmen, will be silenced; the sword will pursue you.

**3** Listen! A cry from Horonaim: "Devastation and great destruction!"

**4** Moab is shattered; her little ones raise a cry.[^48-5]

**5** For on the ascent of Luhith they go up weeping bitterly;[^48-6] for on the descent to Horonaim they have heard the anguished cry of destruction.

**6** Flee! Save your lives! Be like a juniper[^48-7] in the wilderness.

**7** Because you trusted in your works and your treasures, you too will be captured. Chemosh[^48-8] will go into exile, together with his priests and his officials.

**8** The destroyer will come against every city, and no city will escape. The valley will perish, and the plateau[^48-9] will be destroyed, as the LORD has said.

**9** Give wings to Moab,[^48-10] for she will surely fly away. Her cities will become a desolation, with no one living in them.

**10** Cursed is anyone who does the work of the LORD carelessly; cursed is anyone who keeps his sword from bloodshed!

**11** Moab has been at ease from his youth, settled like wine on its dregs. He has not been poured from jar to jar; he has not gone into exile. So his flavor has stayed in him, and his aroma has not changed.[^48-11]

**12** Therefore, look, the days are coming, declares the LORD, when I will send him pourers,[^48-12] and they will pour him out. They will empty his jars and smash his jugs.

**13** Then Moab will be ashamed of Chemosh, as the house of Israel was ashamed of Bethel, in which they trusted.[^48-13]

**14** How can you say, "We are warriors, mighty men for battle"?

**15** Moab is devastated, and his cities have been invaded;[^48-14] the best of his young men have gone down to the slaughter, declares the King, whose name is the LORD of Armies.

**16** Moab's calamity is near at hand; his disaster is coming quickly.

**17** Mourn for him, all you who are around him, all who know his name. Say, "How the mighty scepter is broken, the glorious staff!"

**18** Come down from your glory and sit on the parched ground, you who live there, Daughter Dibon,[^48-15] for the destroyer of Moab has come up against you; he has ruined your strongholds.

**19** Stand by the road and watch, you who live in Aroer. Ask the man who flees and the woman who escapes; say, "What has happened?"

**20** Moab is put to shame, for it is shattered. Wail and cry out! Proclaim by the Arnon[^48-16] that Moab is devastated.

**21** Judgment has come to the land of the plateau: to Holon, to Jahzah and to Mephaath,

**22** to Dibon, to Nebo and to Beth-diblathaim,

**23** to Kiriathaim, to Beth-gamul and to Beth-meon,

**24** to Kerioth and to Bozrah,[^48-17] and to all the cities of the land of Moab, far and near.

**25** The horn of Moab is cut off, and his arm is broken,[^48-18] declares the LORD.

**26** Make him drunk, for he has made himself great against the LORD. Let Moab wallow in his vomit, and let him also become a laughingstock.

**27** Was not Israel a laughingstock to you? Was he caught among thieves, that whenever you spoke of him you shook your head?

**28** Leave the cities and live among the rocks, you who live in Moab! Be like a dove that nests on the sides of the mouth of a gorge.

**29** We have heard of the pride of Moab, how very proud he is: his loftiness, his pride, his arrogance and his haughty heart.[^48-19]

**30** I know his insolence, declares the LORD, but it is empty; his boasts accomplish nothing.[^48-20]

**31** Therefore I wail for Moab; for all Moab I cry out; for the men of Kir-heres[^48-21] one moans.

**32** More than the weeping for Jazer I weep for you, vine of Sibmah! Your tendrils crossed over the sea; they reached as far as the sea of Jazer.[^48-22] On your summer fruit and on your grape harvest the destroyer has fallen.

**33** Joy and gladness have been taken away from the orchard[^48-23] and from the land of Moab. I have stopped the wine from the winepresses; no one treads them with shouts of joy. The shouting is no shout of joy.[^48-24]

**34** From the outcry at Heshbon as far as Elealeh, as far as Jahaz they raise their voice, from Zoar to Horonaim and Eglath-shelishiyah.[^48-25] For even the waters of Nimrim have become desolate.

**35** I will put an end in Moab, declares the LORD, to those who offer sacrifices on the high place and burn incense[^48-26] to their gods.

**36** Therefore my heart moans for Moab like a flute; my heart moans like a flute for the men of Kir-heres. Therefore the wealth they gained has perished.[^48-27]

**37** For every head is shaved bald and every beard cut off; on every hand are gashes, and around the waist is sackcloth.

**38** On all the roofs of Moab and in its squares there is nothing but mourning, for I have broken Moab like a jar that no one wants, declares the LORD.

**39** How it is shattered! How they wail! How Moab has turned his back in shame! Moab has become a laughingstock and an object of terror to all those around him.

**40** For this is what the LORD says: Look, one swoops down like an eagle and spreads his wings over Moab.[^48-28]

**41** Kerioth is captured,[^48-29] and the strongholds are seized. On that day the hearts of Moab's warriors will be like the heart of a woman in labor.

**42** Moab will be destroyed and be a people no more, because he made himself great against the LORD.

**43** Terror, pit and trap are before you, you who live in Moab, declares the LORD.[^48-30]

**44** Whoever flees from the terror will fall into the pit, and whoever climbs out of the pit will be caught in the trap. For I will bring upon her, upon Moab, the year of their punishment, declares the LORD.

**45** In the shadow of Heshbon the fugitives stand without strength. For fire has gone out from Heshbon, and a flame from the midst of Sihon.[^48-31] It has devoured the forehead of Moab and the skulls of the boasters.[^48-32]

**46** Woe to you, Moab! The people of Chemosh have perished, for your sons have been taken into captivity, and your daughters into exile.

**47** Yet I will restore the fortunes[^48-33] of Moab in the days to come,[^48-34] declares the LORD. Thus far the judgment on Moab.

[^48-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles. *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. Also in verse 15. Much of this chapter has lines in common with Isaiah 15–16.
[^48-2]: The places named in this chapter are towns of Moab, east of the Dead Sea. Nebo is the town, not the mountain (Numbers 32:38).
[^48-3]: Hebrew *ha-misgav*, "the high stronghold", perhaps a place name, Misgab.
[^48-4]: Two wordplays: *Cheshbon*, "Heshbon", and *chashvu*, "they have planned"; *Madmen* and *tiddommi*, "you will be silenced".
[^48-5]: The Septuagint reads "they raise a cry to Zoar" (compare Isaiah 15:5).
[^48-6]: Literally "with weeping goes up weeping". Compare Isaiah 15:5.
[^48-7]: Hebrew *aro'er*, perhaps a desert shrub (compare 17:6), or the town of Aroer (verse 19).
[^48-8]: The god of Moab (Numbers 21:29; 1 Kings 11:7).
[^48-9]: Hebrew *ha-mishor*, the high tableland of Moab. Also in verse 21.
[^48-10]: The meaning of the Hebrew *tsits* is uncertain here. It may mean "wings", "a flower" or "salt".
[^48-11]: Wine was left to settle on its sediment and then poured off into other jars to clear it.
[^48-12]: Hebrew *tso'im*, "those who tip", men who tilt jars to pour them out.
[^48-13]: Bethel was where Jeroboam set up a golden calf for Israel to worship (1 Kings 12:28–29). Or the god Bethel, who was worshiped in the region.
[^48-14]: The Hebrew is difficult. Literally "and her cities he has gone up".
[^48-15]: Dibon was a chief city of Moab, north of the Arnon.
[^48-16]: The deep gorge of the Arnon cuts through Moab to the Dead Sea.
[^48-17]: A town in Moab, not the Bozrah of Edom (49:13).
[^48-18]: Pictures of strength.
[^48-19]: Verses 29–38 have many lines in common with Isaiah 16:6–11 and 15:2–7.
[^48-20]: The Hebrew is difficult. Literally "and not right; his empty talk, not right they have done".
[^48-21]: Called Kir-hareseth in Isaiah 16:7, a chief fortress of Moab. Also in verse 36.
[^48-22]: Isaiah 16:8 reads "they reached as far as Jazer". The *sea* is probably the Dead Sea.
[^48-23]: Hebrew *karmel*, "orchard, garden land" (2:7).
[^48-24]: Literally "the shout is not a shout". The cry of the grape treaders has become the battle cry of the enemy (25:30; 51:14).
[^48-25]: Or "the third Eglath". Compare Isaiah 15:4–6.
[^48-26]: Or "burn offerings". The Hebrew verb *qatar* means to make something go up in smoke.
[^48-27]: Literally "the abundance he made has perished" (Isaiah 15:7). Flutes were played at funerals.
[^48-28]: Verses 40–41 are nearly the same as 49:22, which is said of Edom.
[^48-29]: Or "The towns are captured". Hebrew *qeriyyot*, "towns", is also the name of Kerioth (verse 24).
[^48-30]: A wordplay: *pachad*, "terror", *pachat*, "pit", and *pach*, "trap". Verses 43–44 are nearly the same as Isaiah 24:17–18.
[^48-31]: Verses 45–46 draw on the ancient song in Numbers 21:28–29 and on Numbers 24:17. Sihon was the Amorite king whose capital was Heshbon (Numbers 21:26).
[^48-32]: Literally "the sons of tumult". Numbers 24:17 has "the sons of Sheth".
[^48-33]: Literally "turn the turning", an idiom for restoring what was lost. Or "bring back the captives".
[^48-34]: Literally "in the latter end of the days".

## Chapter 49

*Status: draft*

**1** Concerning the Ammonites. This is what the LORD[^49-1] says: Has Israel no sons? Has he no heir? Why then has Milcom[^49-2] taken possession of Gad, and why do his people live in its cities?

**2** Therefore, look, the days are coming, declares the LORD, when I will make the battle cry heard against Rabbah of the Ammonites.[^49-3] It will become a desolate mound, and its villages[^49-4] will be burned with fire. Then Israel will take possession of those who took possession of him, says the LORD.

**3** Wail, Heshbon, for Ai is devastated![^49-5] Cry out, daughters of Rabbah! Put on sackcloth and mourn; run back and forth among the walls,[^49-6] for Milcom will go into exile, together with his priests and his officials.

**4** Why do you boast of your valleys, your valley overflowing,[^49-7] faithless daughter, who trusted in her treasures, saying, "Who will come against me?"

**5** I am going to bring terror on you, declares the Lord GOD of Armies,[^49-8] from all who are around you. You will be driven away, each one headlong, with no one to gather the fugitives.

**6** But afterward I will restore the fortunes[^49-9] of the Ammonites, declares the LORD.

**7** Concerning Edom. This is what the LORD of Armies says: Is there no longer wisdom in Teman?[^49-10] Has counsel perished from the prudent? Has their wisdom gone bad?

**8** Flee, turn back, hide deep down,[^49-11] you who live in Dedan! For I will bring disaster on Esau, the time when I punish him.

**9** If grape pickers came to you, they would leave no gleanings. If thieves came by night, they would destroy all they wanted.[^49-12]

**10** But I have stripped Esau bare; I have uncovered his hiding places, and he cannot hide himself. His offspring are destroyed, his brothers and his neighbors, and he is no more.

**11** Leave your orphans; I will keep them alive. Let your widows trust in me.

**12** For this is what the LORD says: If those who did not deserve to drink the cup must drink it,[^49-13] will you go unpunished? You will not go unpunished, for you will surely drink it.

**13** For I have sworn by myself, declares the LORD, that Bozrah[^49-14] will become a horror, a disgrace, a ruin and a curse, and all her cities will be ruins forever.

**14** I have heard a report from the LORD; an envoy has been sent among the nations: "Gather together and come against her; rise up for battle!"

**15** For look, I will make you small among the nations, despised among human beings.

**16** The terror you inspire[^49-15] and the pride of your heart have deceived you, you who live in the clefts of the rock,[^49-16] who hold the height of the hill. Though you build your nest as high as the eagle's, from there I will bring you down, declares the LORD.

**17** Edom will become a horror; everyone who passes by it will be appalled and hiss at all its wounds.

**18** As when Sodom and Gomorrah and their neighbors were overthrown, says the LORD, no one will live there; no human being will stay in it.[^49-17]

**19** Look, like a lion coming up from the thickets of the Jordan[^49-18] to a pasture that is always green,[^49-19] I will suddenly chase them from it, and I will appoint over it whoever is chosen.[^49-20] For who is like me? Who can summon me? What shepherd can stand before me?

**20** Therefore hear the plan that the LORD has made against Edom, and the purposes he has formed against the inhabitants of Teman: Surely the little ones of the flock will be dragged away; surely their pasture will be made desolate because of them.

**21** At the sound of their fall the earth quakes; their cry is heard at the Red Sea.[^49-21]

**22** Look, like an eagle he will rise and swoop down and spread his wings over Bozrah. On that day the hearts of Edom's warriors will be like the heart of a woman in labor.

**23** Concerning Damascus. Hamath and Arpad[^49-22] are put to shame, for they have heard bad news. They melt in fear; there is anxiety like the sea,[^49-23] which cannot be calm.

**24** Damascus has grown weak; she has turned to flee, and panic has seized her. Distress and pangs have gripped her like a woman in labor.

**25** How is it that the city of praise has not been abandoned, the town of my joy?[^49-24]

**26** Therefore her young men will fall in her squares, and all her soldiers will be silenced on that day, declares the LORD of Armies.[^49-25]

**27** I will set fire to the wall of Damascus, and it will consume the fortresses of Ben-hadad.[^49-26]

**28** Concerning Kedar and the kingdoms of Hazor, which Nebuchadnezzar king of Babylon struck down.[^49-27] This is what the LORD says: Rise up, go up against Kedar, and destroy the people of the east.

**29** Their tents and their flocks will be taken, their tent curtains and all their goods; their camels will be carried off from them. People will shout to them, "Terror on every side!"

**30** Flee, wander far away, hide deep down, you who live in Hazor, declares the LORD. For Nebuchadnezzar king of Babylon has made a plan against you; he has formed a purpose against you.[^49-28]

**31** Rise up, go up against a nation at ease, that lives in security, declares the LORD, that has no gates or bars; they live alone.

**32** Their camels will become plunder, and their great herds spoil. I will scatter to every wind those who clip the hair at their temples,[^49-29] and I will bring disaster on them from every side, declares the LORD.

**33** Hazor will become a haunt of jackals, a desolation forever. No one will live there; no human being will stay in it.

**34** The word of the LORD that came to Jeremiah the prophet concerning Elam,[^49-30] at the beginning of the reign of Zedekiah king of Judah:

**35** This is what the LORD of Armies says: I am going to break the bow of Elam, the mainstay of their might.[^49-31]

**36** I will bring against Elam the four winds from the four ends of the heavens, and I will scatter them to all these winds. There will be no nation to which the outcasts of Elam[^49-32] will not come.

**37** I will shatter Elam before their enemies, before those who seek their lives. I will bring disaster on them, my fierce anger, declares the LORD. I will send the sword after them until I have made an end of them.

**38** I will set my throne in Elam and destroy from there its king and officials, declares the LORD.

**39** But in the days to come[^49-33] I will restore the fortunes of Elam, declares the LORD.

[^49-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^49-2]: The Hebrew is pointed *malkam*, "their king". The same consonants can be read *Milkom*, Milcom, the god of the Ammonites (1 Kings 11:5, 33), as the Septuagint reads. Also in verse 3, where Milcom goes into exile with his priests, as Chemosh does in 48:7.
[^49-3]: The Ammonite capital, modern Amman.
[^49-4]: Literally "its daughters".
[^49-5]: This Ai, in Ammon, is not the town near Bethel. Heshbon lay near the border of Ammon and Moab (48:2).
[^49-6]: Hebrew *gederot*, "walls" or "sheepfolds". The meaning of the line is uncertain.
[^49-7]: Literally "your valley flows".
[^49-8]: Hebrew *Adonai YHWH tseva'ot*, "my Lord YHWH of Armies". *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. *The LORD of Armies* is also in verses 7, 26 and 35.
[^49-9]: Literally "turn the turning", an idiom for restoring what was lost. Or "bring back the captives". Also in verse 39.
[^49-10]: A region or town of Edom, known for its wise men (Job 2:11). Verses 7–22 have many lines in common with Obadiah 1–9.
[^49-11]: Literally "go deep to dwell", that is, hide in caves. Also in verse 30. Dedan was an Arabian people southeast of Edom (25:23).
[^49-12]: Or, as questions, as in Obadiah 5: "would they not leave gleanings? … would they not destroy only what they wanted?"
[^49-13]: The cup of the LORD's wrath (25:15–29).
[^49-14]: A chief city of Edom (Isaiah 34:6; Amos 1:12). Also in verse 22.
[^49-15]: Hebrew *tiflatstekha*, a rare word, perhaps "the horror you cause".
[^49-16]: Hebrew *sela*, "rock", perhaps also the Edomite stronghold Sela (2 Kings 14:7).
[^49-17]: Repeated in 50:40.
[^49-18]: Literally "the pride of the Jordan" (12:5). Verses 19–21 are repeated, of Babylon, in 50:44–46.
[^49-19]: Hebrew *neveh etan*, "an enduring pasture".
[^49-20]: The Hebrew of this sentence is difficult. Literally "for I will in a moment make him run from it, and who is chosen I will appoint over it".
[^49-21]: Hebrew *yam suf*, "Sea of Reeds", here probably the Gulf of Aqaba, south of Edom.
[^49-22]: Cities of northern Syria (Isaiah 10:9).
[^49-23]: Literally "in the sea, anxiety".
[^49-24]: The meaning is uncertain. Literally "How is it not abandoned". Perhaps the citizens lament that they did not leave the city in time.
[^49-25]: Verse 26 is repeated in 50:30.
[^49-26]: The name of several kings of Damascus (1 Kings 15:18; 2 Kings 13:3). Compare Amos 1:4.
[^49-27]: Kedar was a people of the Arabian desert (2:10). This Hazor is not the city in Galilee but probably a group of Arab settlements. Nebuchadnezzar campaigned against the Arabs in 599–598 BC.
[^49-28]: The Hebrew text is written "against them" but read "against you".
[^49-29]: See 9:25 (9:26 in most English Bibles).
[^49-30]: Elam lay east of Babylonia, in what is now southwestern Iran. Zedekiah began to reign in 597 BC.
[^49-31]: Literally "the first of their might". The Elamites were famous archers (Isaiah 22:6).
[^49-32]: The Hebrew text is written *olam*, "forever", but read *Elam*.
[^49-33]: Literally "in the latter end of the days".

## Chapter 50

*Status: draft*

**1** The word that the LORD[^50-1] spoke concerning Babylon, concerning the land of the Babylonians,[^50-2] through Jeremiah the prophet:

**2** Declare it among the nations and proclaim it; raise a signal flag and proclaim it; hide nothing. Say: Babylon is captured; Bel is put to shame; Marduk is shattered.[^50-3] Her images are put to shame; her idols[^50-4] are shattered.

**3** For a nation from the north has come up against her; it will make her land a desolation, and no one will live in it. Both human beings and animals have fled; they are gone.

**4** In those days and at that time, declares the LORD, the people of Israel will come, they and the people of Judah together. They will come weeping as they go, and they will seek the LORD their God.

**5** They will ask the way to Zion, with their faces turned toward it: "Come, let us join ourselves to the LORD[^50-5] in an everlasting covenant that will never be forgotten."

**6** My people have been lost sheep; their shepherds have led them astray, making them roam on the mountains.[^50-6] They have wandered from mountain to hill; they have forgotten their resting place.

**7** All who found them have devoured them, and their foes have said, "We are not guilty, because they sinned against the LORD, their true pasture,[^50-7] the LORD, the hope of their ancestors."

**8** Flee from the midst of Babylon; go out[^50-8] from the land of the Babylonians, and be like male goats that go before the flock.

**9** For look, I am stirring up and bringing against Babylon an assembly of great nations from the land of the north. They will draw up their lines against her; from there she will be captured. Their arrows are like those of a skilled warrior who does not return empty-handed.

**10** Babylonia[^50-9] will become plunder; all who plunder her will be satisfied, declares the LORD.

**11** Though you rejoice, though you exult, you who plunder my inheritance, though you frisk about like a heifer threshing grain[^50-10] and neigh like stallions,

**12** your mother will be greatly ashamed; she who bore you will be disgraced. Look, she will be the least of the nations, a wilderness, a dry land and a desert.

**13** Because of the wrath of the LORD she will not be inhabited, but will be completely desolate. Everyone who passes by Babylon will be appalled and hiss at all her wounds.

**14** Draw up your lines around Babylon, all you who bend the bow! Shoot at her; spare no arrows, for she has sinned against the LORD.

**15** Raise the battle cry against her on every side! She has surrendered;[^50-11] her towers[^50-12] have fallen; her walls are torn down. For this is the vengeance of the LORD. Take vengeance on her; do to her as she has done.

**16** Cut off from Babylon the sower and the one who wields the sickle at harvest time. Because of the sword of the oppressor,[^50-13] they will each turn back to their own people; they will each flee to their own land.

**17** Israel is a scattered sheep, chased away by lions. First the king of Assyria devoured him, and now at the last Nebuchadnezzar king of Babylon has gnawed his bones.[^50-14]

**18** Therefore this is what the LORD of Armies,[^50-15] the God of Israel, says: I am going to punish the king of Babylon and his land, as I punished the king of Assyria.

**19** I will bring Israel back to his pasture, and he will graze on Carmel and in Bashan, and his appetite will be satisfied on the hills of Ephraim and in Gilead.

**20** In those days and at that time, declares the LORD, search will be made for Israel's guilt, but there will be none, and for Judah's sins, but none will be found, for I will forgive those I leave as a remnant.

**21** Go up against the land of Merathaim, against it, and against the inhabitants of Pekod.[^50-16] Put them to the sword and devote them to destruction,[^50-17] declares the LORD; do all that I have commanded you.

**22** The noise of battle is in the land, and great destruction!

**23** How the hammer of the whole earth is cut down and broken! How Babylon has become a horror among the nations!

**24** I set a trap for you, Babylon, and you were caught before you knew it. You were found and seized, because you challenged the LORD.

**25** The LORD has opened his armory and brought out the weapons of his wrath, for the Lord GOD of Armies[^50-18] has work to do in the land of the Babylonians.

**26** Come against her from every side;[^50-19] open her granaries; pile her up like heaps of grain and devote her to destruction. Let her have no remnant left.

**27** Put all her young bulls to the sword;[^50-20] let them go down to the slaughter. Woe to them, for their day has come, the time of their punishment.

**28** Listen! Fugitives and refugees from the land of Babylon are declaring in Zion the vengeance of the LORD our God, vengeance for his temple.

**29** Summon archers[^50-21] against Babylon, all who bend the bow. Camp all around her; let none of hers escape.[^50-22] Repay her for her deeds; do to her just as she has done. For she has defied the LORD, the Holy One of Israel.

**30** Therefore her young men will fall in her squares, and all her soldiers will be silenced on that day, declares the LORD.[^50-23]

**31** Look, I am against you, Arrogant One,[^50-24] declares the Lord GOD of Armies, for your day has come, the time when I will punish you.

**32** The Arrogant One will stumble and fall, with no one to raise him up. I will set fire to his cities, and it will consume everything around him.

**33** This is what the LORD of Armies says: The people of Israel are oppressed, and the people of Judah with them. All who took them captive hold them fast; they refuse to let them go.

**34** But their Redeemer[^50-25] is strong; the LORD of Armies is his name. He will surely plead their cause, so that he may give rest to the earth, but unrest to the inhabitants of Babylon.[^50-26]

**35** A sword against the Babylonians, declares the LORD, and against the inhabitants of Babylon, against her officials and against her wise men!

**36** A sword against her false prophets,[^50-27] and they will become fools! A sword against her warriors, and they will be shattered!

**37** A sword against his horses and his chariots, and against all the foreign troops[^50-28] in her midst, and they will become like women! A sword against her treasures, and they will be plundered!

**38** A drought[^50-29] on her waters, and they will dry up! For it is a land of idols, and they go mad over their terrifying images.

**39** Therefore desert creatures will live there with hyenas,[^50-30] and ostriches will live in her. She will never again be inhabited or lived in from generation to generation.

**40** As when God overthrew Sodom and Gomorrah and their neighbors, declares the LORD, no one will live there; no human being will stay in it.[^50-31]

**41** Look, a people is coming from the north; a great nation and many kings are being stirred up from the farthest parts of the earth.[^50-32]

**42** They grasp bow and javelin; they are cruel and show no mercy. Their sound is like the roaring sea; they ride on horses, drawn up like warriors for battle against you, Daughter Babylon.

**43** The king of Babylon has heard the report of them, and his hands hang limp. Anguish has gripped him, pain like that of a woman in labor.

**44** Look, like a lion coming up from the thickets of the Jordan[^50-33] to a pasture that is always green, I will suddenly chase them from it, and I will appoint over it whoever is chosen. For who is like me? Who can summon me? What shepherd can stand before me?

**45** Therefore hear the plan that the LORD has made against Babylon, and the purposes he has formed against the land of the Babylonians: Surely the little ones of the flock will be dragged away; surely the pasture will be made desolate because of them.

**46** At the sound of Babylon's capture the earth quakes, and a cry is heard among the nations.

[^50-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles. Chapters 50–51 are the last and longest of the oracles against the nations.
[^50-2]: Hebrew *Kasdim*, traditionally "Chaldeans": the people of southern Mesopotamia whose kings then ruled Babylon. Also in verses 8, 10, 25, 35 and 45.
[^50-3]: Hebrew *Merodakh*. Marduk was the chief god of Babylon, and *Bel*, "lord", was his title.
[^50-4]: Hebrew *gillulim*, a scornful word for idols, perhaps "dung pellets".
[^50-5]: Literally "Come, and they will join themselves to the LORD".
[^50-6]: The Hebrew text is written "faithless mountains" but read "they made them roam on the mountains".
[^50-7]: Literally "the pasture of righteousness" (31:23).
[^50-8]: The Hebrew text is written "they will go out" but read "go out".
[^50-9]: Hebrew *Kasdim*, here meaning the land.
[^50-10]: The same consonants can be read "like a heifer in the grass", as the Septuagint reads.
[^50-11]: Literally "She has given her hand".
[^50-12]: Hebrew *ashyot*, a rare word, perhaps "towers" or "foundations".
[^50-13]: Or "the cruel sword". Hebrew *ha-yonah*, perhaps "the oppressor" (46:16).
[^50-14]: Literally "has broken his bones". Assyria destroyed the northern kingdom of Israel in 722 BC (2 Kings 17:6), and Babylon took Judah into exile.
[^50-15]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. Also in verses 25, 31, 33 and 34.
[^50-16]: Two wordplays. *Merathaim*, "double rebellion", sounds like *mat marrati*, a Babylonian name for the region at the head of the Persian Gulf. *Pekod*, "punishment", was an Aramean people in eastern Babylonia (Ezekiel 23:23).
[^50-17]: Literally "Put to the sword and devote to destruction after them". Hebrew *charam*: see 25:9. Also in verse 26.
[^50-18]: Hebrew *Adonai YHWH tseva'ot*, "my Lord YHWH of Armies". Also in verse 31.
[^50-19]: Literally "from the end".
[^50-20]: Her *young bulls* are her warriors (compare 46:21).
[^50-21]: Hebrew *rabbim*, "many", here probably "archers" (compare Job 16:13).
[^50-22]: The words "of hers" are read but not written in the Hebrew text.
[^50-23]: Verse 30 repeats 49:26, there said of Damascus.
[^50-24]: Hebrew *zadon*, "arrogance", used as a name for Babylon. Also in verse 32.
[^50-25]: Hebrew *go'el*, a kinsman who buys back a relative or his property (31:11).
[^50-26]: A wordplay: *hirgia*, "give rest", and *hirgiz*, "make tremble".
[^50-27]: Hebrew *baddim*, "empty talkers", probably her diviners (compare Isaiah 44:25).
[^50-28]: Hebrew *ha-erev*, "the mixture" (25:20), here probably foreign soldiers.
[^50-29]: Hebrew *chorev*, "drought", a play on *cherev*, "sword", in verses 35–37.
[^50-30]: The meaning of the Hebrew words *tsiyyim* and *iyyim* is uncertain. Compare Isaiah 13:21–22; 34:14.
[^50-31]: Verse 40 repeats 49:18, there said of Edom.
[^50-32]: Verses 41–43 repeat 6:22–24, there said of Jerusalem.
[^50-33]: Literally "the pride of the Jordan". Verses 44–46 repeat 49:19–21, there said of Edom.

## Chapter 51

*Status: draft*

**1** This is what the LORD[^51-1] says: I am going to stir up a destroying wind[^51-2] against Babylon and against the people who live in Leb-kamai.[^51-3]

**2** I will send foreigners to Babylon, and they will winnow her[^51-4] and empty her land, for they will come against her from every side on the day of disaster.

**3** Against the archer let the archer bend his bow, and against the one who stands up in his armor.[^51-5] Do not spare her young men; devote her whole army to destruction.[^51-6]

**4** They will fall slain in the land of the Babylonians,[^51-7] pierced through in her streets.

**5** For Israel and Judah have not been widowed by their God, by the LORD of Armies,[^51-8] though their land is full of guilt against the Holy One of Israel.[^51-9]

**6** Flee from the midst of Babylon! Save your lives, each of you! Do not be destroyed[^51-10] because of her guilt. For this is the time of the LORD's vengeance; he is repaying her what she deserves.

**7** Babylon was a golden cup in the LORD's hand, making the whole earth drunk. The nations drank her wine; therefore the nations have gone mad.[^51-11]

**8** Suddenly Babylon has fallen and is shattered.[^51-12] Wail for her! Get balm for her pain; perhaps she can be healed.

**9** "We tried to heal Babylon, but she could not be healed. Leave her, and let us each go to our own land, for her judgment reaches to the heavens and rises as high as the clouds.[^51-13]

**10** The LORD has brought our vindication to light.[^51-14] Come, let us tell in Zion the work of the LORD our God."

**11** Sharpen the arrows! Fill the quivers![^51-15] The LORD has stirred up the spirit of the kings of the Medes,[^51-16] because his purpose is to destroy Babylon. For this is the vengeance of the LORD, vengeance for his temple.

**12** Raise a signal flag against the walls of Babylon! Strengthen the watch; post the watchmen; prepare the ambushes! For the LORD has both planned and done what he spoke concerning the inhabitants of Babylon.

**13** You who live by many waters, rich in treasures, your end has come, the measure of your life is cut off.[^51-17]

**14** The LORD of Armies has sworn by himself: Surely I will fill you with people like a swarm of locusts, and they will raise the shout of victory[^51-18] over you.

**15** He made the earth by his power; he established the world by his wisdom, and by his understanding he stretched out the heavens.[^51-19]

**16** When he thunders,[^51-20] there is a roar of waters in the heavens; he makes the clouds rise from the ends of the earth. He makes lightning for the rain, and brings out the wind from his storehouses.

**17** Every human being is stupid and without knowledge; every goldsmith is put to shame by his idol. For his cast images are a lie; there is no breath in them.

**18** They are worthless, a work of mockery. At the time of their punishment they will perish.

**19** The Portion of Jacob is not like these, for he is the maker of all things, and of the tribe that is his inheritance.[^51-21] The LORD of Armies is his name.

**20** You are my war club, my weapon for battle:[^51-22] with you I shatter nations; with you I destroy kingdoms;

**21** with you I shatter the horse and its rider; with you I shatter the chariot and its driver;

**22** with you I shatter man and woman; with you I shatter the old and the young; with you I shatter the young man and the young woman;

**23** with you I shatter the shepherd and his flock; with you I shatter the farmer and his team; with you I shatter governors and deputies.[^51-23]

**24** I will repay Babylon and all the inhabitants of Babylonia[^51-24] for all the evil they have done in Zion before your eyes, declares the LORD.

**25** Look, I am against you, destroying mountain, declares the LORD, you who destroy the whole earth. I will stretch out my hand against you, roll you down from the cliffs and make you a burned-out mountain.

**26** No stone will be taken from you for a cornerstone, nor any stone for a foundation, for you will be desolate forever, declares the LORD.

**27** Raise a signal flag in the land! Blow the ram's horn among the nations! Prepare the nations for war against her;[^51-25] summon against her the kingdoms of Ararat, Minni and Ashkenaz.[^51-26] Appoint a commander[^51-27] against her; bring up horses like bristling locusts.[^51-28]

**28** Prepare the nations for war against her, the kings of the Medes, their governors and all their deputies, and every land under their rule.

**29** The earth quakes and writhes, for the LORD's purposes against Babylon stand: to make the land of Babylon a desolation, with no one living in it.

**30** Babylon's warriors have stopped fighting; they stay in their strongholds. Their strength has failed; they have become like women. Her dwellings are set on fire; the bars of her gates are broken.

**31** Runner runs to meet runner, and messenger to meet messenger, to tell the king of Babylon that his city has been captured from end to end,

**32** the fords have been seized, the marshes[^51-29] set on fire, and the soldiers are terrified.

**33** For this is what the LORD of Armies, the God of Israel, says: Daughter Babylon is like a threshing floor at the time it is trodden; in a little while the time of her harvest will come.

**34** "Nebuchadnezzar king of Babylon has devoured me;[^51-30] he has crushed me; he has set me down like an empty jar. He has swallowed me like a sea monster;[^51-31] he has filled his belly with my delicacies and rinsed me out."[^51-32]

**35** "May the violence done to me and to my flesh[^51-33] be on Babylon," the people of Zion will say. "May my blood be on the inhabitants of Babylonia," Jerusalem will say.

**36** Therefore this is what the LORD says: I am going to plead your cause and take vengeance for you. I will dry up her sea[^51-34] and make her spring run dry.

**37** Babylon will become a heap of ruins, a haunt of jackals, a horror and a thing to hiss at, with no one living there.

**38** They roar together like young lions; they growl like lion cubs.

**39** While they are heated, I will set out a feast for them and make them drunk, so that they celebrate, then sleep a perpetual sleep and never wake, declares the LORD.

**40** I will bring them down like lambs to the slaughter, like rams with male goats.

**41** How Sheshach[^51-35] is captured, the praise of the whole earth seized! How Babylon has become a horror among the nations!

**42** The sea has risen over Babylon; she is covered with its roaring waves.

**43** Her cities have become a desolation, a dry land and a desert, a land where no one lives, through which no human being passes.

**44** I will punish Bel[^51-36] in Babylon and make him spit out what he has swallowed.[^51-37] The nations will no longer stream to him. Even the wall of Babylon has fallen.

**45** Go out from her midst, my people! Save your lives, each of you, from the fierce anger of the LORD![^51-38]

**46** Do not lose heart or be afraid at the rumors heard in the land, when one rumor comes this year and another the next, with violence in the land and ruler against ruler.

**47** Therefore, look, the days are coming when I will punish the idols of Babylon. Her whole land will be put to shame, and all her slain will fall in her midst.

**48** Then heaven and earth and all that is in them will shout for joy over Babylon, for the destroyers will come against her from the north, declares the LORD.

**49** Babylon must fall because of the slain of Israel, as the slain of all the earth have fallen because of Babylon.

**50** You who have escaped the sword, go! Do not stand still! Remember the LORD from far away, and let Jerusalem come to your mind.

**51** "We are ashamed, for we have heard insults; disgrace has covered our faces, for foreigners have entered the holy places of the LORD's house."[^51-39]

**52** Therefore, look, the days are coming, declares the LORD, when I will punish her idols, and throughout her land the wounded will groan.

**53** Though Babylon should climb to the heavens, and though she should fortify her lofty stronghold, destroyers will come against her from me, declares the LORD.

**54** Listen! A cry from Babylon, the sound of great destruction from the land of the Babylonians!

**55** For the LORD is destroying Babylon and silencing her great noise. Their waves roar like many waters; the sound of their voice resounds.

**56** For a destroyer has come against her, against Babylon. Her warriors are captured; their bows are shattered. For the LORD is a God of retribution; he will surely repay.

**57** I will make her officials and her wise men drunk, her governors, her deputies and her warriors; they will sleep a perpetual sleep and never wake, declares the King, whose name is the LORD of Armies.

**58** This is what the LORD of Armies says: The thick wall of Babylon[^51-40] will be leveled to the ground, and her high gates set on fire. The peoples exhaust themselves for nothing; the nations wear themselves out only for the fire.[^51-41]

**59** This is the command that Jeremiah the prophet gave to Seraiah son of Neriah son of Mahseiah, when he went with Zedekiah king of Judah to Babylon in the fourth year of his reign.[^51-42] Seraiah was the quartermaster.[^51-43]

**60** Jeremiah had written on one scroll all the disaster that would come on Babylon, all these words that are written concerning Babylon.

**61** Jeremiah said to Seraiah, "When you come to Babylon, see that you read all these words aloud.

**62** Then say, 'LORD, you have said concerning this place that you will cut it off, so that no one will live in it, neither human beings nor animals, for it will be desolate forever.'

**63** When you finish reading this scroll, tie a stone to it and throw it into the middle of the Euphrates.

**64** Then say, 'So will Babylon sink and never rise again, because of the disaster I am going to bring on her. And they will grow weary.'"[^51-44] Thus far the words of Jeremiah.

[^51-1]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^51-2]: Or "the spirit of a destroyer". Hebrew *ruach*, "wind, spirit".
[^51-3]: *Leb-kamai*, "the heart of those who rise against me", is a code name for *Kasdim*, Chaldea, made by the cipher *atbash* (see 25:26), in which each letter is replaced by the letter in the same place counting from the end of the alphabet. So *k-s-d-y* becomes *l-b-q-m-y*. The Septuagint reads "the Chaldeans".
[^51-4]: A wordplay: *zarim*, "foreigners", and *zeruha*, "they will winnow her". The same consonants can be read *zorim*, "winnowers".
[^51-5]: The Hebrew of these lines is difficult. Some scholars read *al*, "Let not the archer bend his bow, and let him not stand up in his armor", with a small change to the Hebrew.
[^51-6]: Hebrew *charam*: see 25:9.
[^51-7]: Hebrew *Kasdim*, traditionally "Chaldeans": the people of southern Mesopotamia whose kings then ruled Babylon. Also in verses 24, 35 and 54.
[^51-8]: *The LORD of Armies* (Hebrew *YHWH tseva'ot*) is traditionally "the LORD of hosts" or "the LORD Almighty". *Tseva'ot* means armies: the heavenly hosts and the armies of Israel. Also in verses 14, 19, 33, 57 and 58.
[^51-9]: *Their land* may be the land of Israel and Judah, or the land of the Babylonians.
[^51-10]: Or "Do not be silenced".
[^51-11]: Compare 25:15–29. Revelation 17:2–4 and 18:3 take up this picture.
[^51-12]: Compare Isaiah 21:9 and Revelation 14:8; 18:2.
[^51-13]: The speakers in verses 9–10 are probably the foreigners living in Babylon, and then the exiles of Judah.
[^51-14]: Literally "has brought out our righteousnesses".
[^51-15]: Hebrew *shelatim*, perhaps "quivers" or "shields".
[^51-16]: The Medes, from what is now northwestern Iran, joined the Persians under Cyrus, who took Babylon in 539 BC. Also in verse 28.
[^51-17]: The Hebrew is difficult. Literally "the cubit of your cutting off", perhaps the length of your life, like cloth cut from the loom (Isaiah 38:12).
[^51-18]: Hebrew *hedad*, the shout of grape treaders (25:30; 48:33).
[^51-19]: Verses 15–19 repeat 10:12–16.
[^51-20]: Literally "At the sound of his giving".
[^51-21]: Literally "and the tribe of his inheritance". 10:16 reads "and Israel is the tribe of his inheritance".
[^51-22]: *You* may be Babylon, the LORD's instrument until now, or the conqueror who is coming against her. The verb *naphats*, "shatter", is repeated nine times in verses 20–23.
[^51-23]: Hebrew *pachot* and *seganim*, titles of officials in the Babylonian and Persian empires. Also in verses 28 and 57.
[^51-24]: Hebrew *Kasdim*, here meaning the land. Also in verse 35.
[^51-25]: Literally "Consecrate nations against her", from the religious rites that opened a campaign (6:4). Also in verse 28.
[^51-26]: Ararat (Urartu), Minni (the Mannaeans) and Ashkenaz (probably the Scythians) were peoples of the mountains north of Mesopotamia.
[^51-27]: Hebrew *tifsar*, a word borrowed from the Babylonian language, "official".
[^51-28]: Hebrew *yeleq samar*, perhaps locusts at a stage when their wings are still sheathed.
[^51-29]: Hebrew *agammim*, "reed marshes", perhaps the reed thickets or defenses along the river.
[^51-30]: The Hebrew text is written "us" throughout this verse but read "me". Jerusalem speaks in verses 34–35.
[^51-31]: Hebrew *tannin*, a sea monster or dragon.
[^51-32]: Or "spewed me out".
[^51-33]: Literally "my violence and my flesh".
[^51-34]: Her *sea* may be the Euphrates with its canals.
[^51-35]: *Sheshach* is a code name for Babylon made by the cipher *atbash*: see 25:26 and verse 1.
[^51-36]: A title of Marduk, the chief god of Babylon (50:2).
[^51-37]: The Septuagint does not have the rest of verse 44, or verses 45–48 and the first half of verse 49.
[^51-38]: Compare Revelation 18:4.
[^51-39]: The exiles answer in this verse.
[^51-40]: Literally "the walls of Babylon, the broad".
[^51-41]: Habakkuk 2:13 has nearly the same words.
[^51-42]: In 594–593 BC. Seraiah was the brother of Baruch son of Neriah (32:12).
[^51-43]: Hebrew *sar menuchah*, "officer of the resting place", perhaps the officer in charge of the stopping places on the journey.
[^51-44]: These words repeat the end of verse 58. They seem to have been copied here to mark where the words of Jeremiah end.

## Chapter 52

*Status: draft*

**1** Zedekiah was twenty-one years old when he became king,[^52-1] and he reigned eleven years in Jerusalem. His mother's name was Hamutal[^52-2] daughter of Jeremiah, from Libnah.

**2** He did what was evil in the eyes of the LORD,[^52-3] just as Jehoiakim had done.[^52-4]

**3** For it was because of the LORD's anger that all this happened to Jerusalem and Judah, until he cast them out of his presence. And Zedekiah rebelled against the king of Babylon.

**4** So in the ninth year of his reign, in the tenth month, on the tenth day of the month,[^52-5] Nebuchadnezzar king of Babylon came against Jerusalem with his whole army. They camped against it, and they built siege works all around it.

**5** The city was under siege until the eleventh year of King Zedekiah.

**6** In the fourth month, on the ninth day of the month,[^52-6] the famine in the city was so severe that there was no food for the people of the land.

**7** Then the city wall was broken through, and all the soldiers fled and went out of the city by night by way of the gate between the two walls, near the king's garden, though the Babylonians[^52-7] were all around the city. They went off in the direction of the Arabah.[^52-8]

**8** But the Babylonian army pursued the king and overtook Zedekiah in the plains of Jericho, and all his army was scattered from him.

**9** They captured the king and brought him up to the king of Babylon at Riblah in the land of Hamath,[^52-9] and he passed sentence on him.

**10** The king of Babylon slaughtered Zedekiah's sons before his eyes, and he also slaughtered all the officials of Judah at Riblah.[^52-10]

**11** Then he put out Zedekiah's eyes and bound him in bronze shackles, and the king of Babylon brought him to Babylon and put him in prison[^52-11] until the day of his death.

**12** In the fifth month, on the tenth day of the month,[^52-12] which was the nineteenth year of King Nebuchadnezzar king of Babylon, Nebuzaradan the commander of the guard,[^52-13] who served the king of Babylon,[^52-14] came to Jerusalem.

**13** He burned the house of the LORD,[^52-15] the king's palace and all the houses of Jerusalem. Every great house he burned with fire.

**14** The whole Babylonian army that was with the commander of the guard tore down all the walls around Jerusalem.

**15** Nebuzaradan the commander of the guard deported some of the poorest of the people,[^52-16] the rest of the people who were left in the city, the deserters who had gone over to the king of Babylon, and the rest of the craftsmen.[^52-17]

**16** But Nebuzaradan the commander of the guard left some of the poorest people of the land to work the vineyards and the fields.

**17** The Babylonians broke up the bronze pillars that belonged to the house of the LORD, and the stands and the bronze Sea that were in the house of the LORD, and they carried all the bronze to Babylon.

**18** They also took away the pots, the shovels, the wick trimmers, the sprinkling bowls, the dishes and all the bronze articles used in the temple service.

**19** The commander of the guard took away the basins, the firepans, the sprinkling bowls, the pots, the lampstands, the dishes and the bowls for drink offerings,[^52-18] whatever was made of gold and whatever was made of silver.

**20** As for the two pillars, the one Sea, and the twelve bronze bulls that were under the stands,[^52-19] which King Solomon had made for the house of the LORD, the bronze of all these articles was beyond weighing.

**21** As for the pillars, each pillar was eighteen cubits[^52-20] high, and a cord of twelve cubits went around it. It was four fingers thick,[^52-21] and hollow.

**22** The bronze capital on top of it was five cubits high,[^52-22] with a network and pomegranates all around the capital, all of bronze. The second pillar, with its pomegranates, was the same.

**23** There were ninety-six pomegranates on the sides;[^52-23] all the pomegranates around the network numbered a hundred.

**24** The commander of the guard took Seraiah the chief priest, Zephaniah the second priest and the three doorkeepers.[^52-24]

**25** From the city he took an official who was in charge of the soldiers, and seven of the king's advisers[^52-25] who were found in the city, the secretary of the commander of the army,[^52-26] who mustered the people of the land, and sixty men of the people of the land who were found in the city.

**26** Nebuzaradan the commander of the guard took them and brought them to the king of Babylon at Riblah.

**27** The king of Babylon struck them down and put them to death at Riblah in the land of Hamath. So Judah went into exile from its land.

**28** These are the people whom Nebuchadnezzar deported:[^52-27] in the seventh year, 3,023 Judeans;[^52-28]

**29** in the eighteenth year of Nebuchadnezzar, 832 people from Jerusalem;[^52-29]

**30** in the twenty-third year of Nebuchadnezzar, Nebuzaradan the commander of the guard deported 745 Judeans.[^52-30] In all there were 4,600 people.

**31** In the thirty-seventh year of the exile of Jehoiachin king of Judah, in the twelfth month, on the twenty-fifth day of the month,[^52-31] Evil-merodach[^52-32] king of Babylon, in the year he became king, showed favor to Jehoiachin king of Judah and brought him out of prison.[^52-33]

**32** He spoke kindly to him and gave him a seat above the seats of the other kings who were with him in Babylon.

**33** So Jehoiachin took off his prison clothes, and for the rest of his life he regularly ate at the king's table.

**34** As for his allowance, a regular allowance was given him by the king of Babylon, a portion for each day, until the day of his death, for as long as he lived.[^52-34]

[^52-1]: This chapter is also found, with small differences, in 2 Kings 24:18–25:30, except for verses 28–30, which only Jeremiah has. Verses 4–16 are also told, more briefly, in 39:1–10. The differences that change the sense are given in the notes.
[^52-2]: Her father is not Jeremiah the prophet.
[^52-3]: *LORD*: God's personal name, Hebrew YHWH, written "the LORD" in capitals as in most English Bibles.
[^52-4]: The Septuagint does not have verses 2–3.
[^52-5]: In January 588 BC.
[^52-6]: In July 587 or 586 BC. 2 Kings 25:3 does not have "In the fourth month".
[^52-7]: Hebrew *Kasdim*, traditionally "Chaldeans": the people of southern Mesopotamia whose kings then ruled Babylon. Also in verses 8, 14 and 17.
[^52-8]: The Jordan Valley. 2 Kings 25:4 has no verb for the soldiers, and reads "he went off", meaning the king.
[^52-9]: Riblah was on the Orontes River in Syria, where Nebuchadnezzar had his headquarters. 2 Kings 25:6 does not have "in the land of Hamath", and reads "they passed sentence on him".
[^52-10]: 2 Kings 25:7 does not mention the killing of the officials.
[^52-11]: Literally "the house of the punishments". 2 Kings 25:7 does not mention his imprisonment or his death.
[^52-12]: In the summer of 587 or 586 BC. 2 Kings 25:8 reads "on the seventh day of the month".
[^52-13]: Hebrew *rav-tabbachim*, literally "chief of the butchers" or "chief of the cooks", a title of the commander of the royal bodyguard. Also in verses 14–16, 19, 24, 26 and 30.
[^52-14]: Literally "who stood before the king of Babylon". 2 Kings 25:8 reads "an officer of the king of Babylon".
[^52-15]: "The house of the LORD" is the temple.
[^52-16]: These words are not in 2 Kings 25:11, and they seem to conflict with verse 16. The Septuagint does not have verse 15.
[^52-17]: Hebrew *ha-amon*, perhaps "the craftsmen". 2 Kings 25:11 reads *he-hamon*, "the population".
[^52-18]: 2 Kings 25:15 names only the firepans and the sprinkling bowls.
[^52-19]: 2 Kings 25:16 does not mention the bulls. According to 1 Kings 7:25 the twelve bulls stood under the Sea, not under the stands, and King Ahaz had already taken the Sea down from them (2 Kings 16:17).
[^52-20]: A cubit was about 18 inches (45 cm). Eighteen cubits was about 27 feet (8.1 meters), and twelve cubits about 18 feet (5.4 meters). Verses 21–23 are not in 2 Kings 25, which gives only the height of the pillars and their capitals. Compare 1 Kings 7:15–22.
[^52-21]: About 3 inches (7.5 cm).
[^52-22]: About 7½ feet (2.3 meters), as in 1 Kings 7:16. 2 Kings 25:17 reads "three cubits".
[^52-23]: Hebrew *ruchah*, "toward the wind", perhaps "on the outside" or "exposed to view". The meaning is uncertain.
[^52-24]: Literally "the keepers of the threshold".
[^52-25]: Literally "of those who saw the king's face". 2 Kings 25:19 reads "five".
[^52-26]: Or "the secretary, the commander of the army".
[^52-27]: Verses 28–30 are found only here, and the Septuagint does not have them.
[^52-28]: In 597 BC. 2 Kings 24:12 dates this deportation to Nebuchadnezzar's eighth year, and 2 Kings 24:14–16 gives larger numbers. Hebrew *yehudim*, the people of Judah. Also in verse 30.
[^52-29]: In 587 or 586 BC, when Jerusalem fell. Verse 12 calls that year Nebuchadnezzar's nineteenth.
[^52-30]: In 582 or 581 BC. This deportation is not mentioned anywhere else.
[^52-31]: In 561 BC. 2 Kings 25:27 reads "on the twenty-seventh day of the month".
[^52-32]: Amel-Marduk, son of Nebuchadnezzar, king of Babylon from 562 to 560 BC.
[^52-33]: Literally "lifted up the head of Jehoiachin king of Judah, and brought him out of the prison house" (compare Genesis 40:13, 20). 2 Kings 25:27 does not have "and brought him out".
[^52-34]: Literally "all the days of his life". 2 Kings 25:30 reads "by the king", and does not have "until the day of his death".
