The Open Plain English Translation: each book as Markdown, with its notes.

The Open Plain English Translation (draft), CC BY 4.0, https://bibledata.org. Source texts: the Unicode/XML Leningrad Codex (UXLC 2.6) and the SBL Greek New Testament (CC BY 4.0).
